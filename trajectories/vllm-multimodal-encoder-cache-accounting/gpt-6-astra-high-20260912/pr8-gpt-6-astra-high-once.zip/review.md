vllm-multimodal-encoder-cache-accounting v1.2.8

Original reward 1; the original scorer also returned 1 in the restored final environment. All eight cache challenge groups and five capacity cases passed. The boundary is real encoder accounting, scheduling and cache write/read state on CPU; full model serving is outside scope.

The existing task-review records apply to the exact published task. The original rollout review is recorded in review/review-record.json; the later targeted recheck did not repeat full trajectory reading. Raw scoring and replay artifacts are retained; original scores are unchanged.
