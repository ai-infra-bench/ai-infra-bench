vllm-multimodal-encoder-cache-accounting v1.2.8: GPT-6-Astra/high, reward 1.

trajectory.json: ATIF; jobs/: native trajectory and original verifier artifacts; api-trajectory.jsonl: decoded API capture. final-state/: captured source archive, diff and inventory; review.md and review/: diagnosis and replay evidence.

run-identity.json links the task files in this PR; MANIFEST.json verifies ZIP contents. Credentials are redacted in publication copies. Rootfs, runtime binaries and raw SQLite remain local.
