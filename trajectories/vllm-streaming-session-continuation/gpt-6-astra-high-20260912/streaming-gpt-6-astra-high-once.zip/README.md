vllm-streaming-session-continuation v1.2.2: GPT-6-Astra/high, reward 1.

trajectory.json: ATIF; jobs/: native trajectory and original verifier artifacts; api-trajectory.jsonl: decoded API capture. final-state/: final source archive, diff and inventory; review.md and review/: diagnosis and replay evidence.

run-identity.json links the published task hashes; MANIFEST.json verifies this ZIP. Task files and qualification evidence live in the same PR under tasks/. Credentials are redacted in publication copies. Rootfs, runtime binaries and raw SQLite remain local.
