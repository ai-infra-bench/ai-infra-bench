vllm-int8-per-token-group-quantization v1.2.5: GPT-6-Astra/high, reward 0.

trajectory.json: ATIF; jobs/: native trajectory and original verifier artifacts; api-trajectory.jsonl: decoded API capture. final-state/: captured source archive, diff and inventory; review.md and review/: diagnosis and replay evidence.

run-identity.json links the task files in this PR; MANIFEST.json verifies ZIP contents. Credentials are redacted in publication copies. Rootfs, runtime binaries and raw SQLite remain local.
