vllm-int8-per-token-group-quantization v1.2.5

Original reward 0: the candidate adds int8_min <= 0 and rejects legal positive ranges such as [1,100]. Independent GPU challenges reproduce this with both the delivered native extension and the original Harbor-rebuilt extension. Dispatch/accuracy, empty-input and tiny-FP32 challenge groups pass. Formal performance was not run because correctness failed; the diagnostic replay is not a second full Harbor score.

The existing task-review records apply to the exact published task. The original rollout review is recorded in review/review-record.json; the later targeted recheck did not repeat full trajectory reading. Raw scoring and replay artifacts are retained; original scores are unchanged.
