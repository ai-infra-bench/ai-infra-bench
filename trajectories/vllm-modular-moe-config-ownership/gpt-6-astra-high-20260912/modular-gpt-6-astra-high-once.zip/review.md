vllm-modular-moe-config-ownership v1.2.7

One GPT-6-Astra/high attempt: original reward 0; both final-environment replays also received 0. No Harbor exception.

The candidate gives stale explicit configuration priority over the active layer. Required gather/reduce-scatter is omitted; an independent three-rank case receives 4 expert input rows instead of 13. The grader correctly rejects it.

Real ownership/factory/prepare/expert/finalize decisions and single-GPU Triton numerics; transport and external FlashInfer arithmetic use documented substitutes.

Task-review passed for the published task hashes. Qualification results are in the task's validation/e2e-evidence.json. Review records and independent replay inputs, observations and logs are under review/. Native/ATIF consistency and captured final-source hashes were verified.
