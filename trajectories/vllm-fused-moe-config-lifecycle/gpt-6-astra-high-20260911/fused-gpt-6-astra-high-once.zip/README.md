vllm-fused-moe-config-lifecycle v1.2.6: one GPT-6-Astra/high attempt, reward 1, no Harbor exception.

trajectory.json: ATIF; jobs/: native traces, final source and original verifier artifacts; api-trajectory.jsonl: decoded API capture. review.md and review/ contain the review and diagnostic evidence.

run-identity.json records tested and published task hashes; MANIFEST.json verifies this ZIP. Full rootfs, raw SQLite and authentication state are excluded. Original execution records are unchanged.
