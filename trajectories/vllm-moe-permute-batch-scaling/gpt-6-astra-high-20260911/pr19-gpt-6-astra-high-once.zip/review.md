vllm-moe-permute-batch-scaling v1.3.2

One GPT-6-Astra/high attempt: original reward 1, no Harbor exception. The recorded rollout and final candidate were reviewed; no blocking task or candidate defect was found.

Fourteen independent correctness cases, including 2049 experts, and one performance case passed. Review tested the original installed native library and the verifier-rebuilt library separately. Formal replay reward was 1: rebuilt-library latency 122.163 us and scaling ratio 2.731, against limits 250 us and 3.5. The original formal values were 122.532 us and 2.690; these are distinct from agent-reported timings. The candidate uses a tiled scan and supports expert counts spanning multiple tiles.

Evidence: [capture audit](review/capture-audit.json), [final audit](review/final-audit.json), [replay record](review/replay-record.json), [diagnostic logs](review/replay-evidence.tar.gz) and [skill revision](review/skill-provenance.json). Prior qualification was reused after input-hash checks.

Replays used restored snapshots on A100 with read-only tests and no external network. Original CPU/memory cgroup limits were not imposed, so replay wall times are not equivalent end-to-end measurements. Pre-existing tool-output truncation cannot be recovered, and no immutable model backend revision was returned.
