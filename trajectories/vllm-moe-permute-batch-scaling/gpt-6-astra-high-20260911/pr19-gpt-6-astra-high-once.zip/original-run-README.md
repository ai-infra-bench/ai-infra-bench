Task: pr19
Model: gpt-6-astra; effort: high; CLIProxyAPI 7.2.157.
One independent Harbor model attempt. Raw reward: 1.0.
Contains native/ATIF/HTTP+SSE trajectories, scoring evidence, repository source archive and complete repository inventory.
Full pre-verifier rootfs snapshot and original SQLite remain in the local campaign directory; rootfs excluded from this shareable ZIP because it includes runtime authentication state.
