vllm-moe-permute-batch-scaling v1.3.2

One GPT-6-Astra / high Harbor attempt, reward 1, no Harbor exception.
trajectory.json: browsable ATIF; jobs/: native Codex trajectory, final repository source and verifier logs; api-trajectory.jsonl: HTTP/SSE capture.
review.md and review/: completed rollout review and independent replay evidence for this same attempt.
run-identity.json records tested task hashes; MANIFEST.json covers archive contents. Original run manifests and packaging.json preserve packaging provenance.
Full rootfs and raw SQLite remain local; runtime authentication state is excluded.
