# PR #63：四次 Codex GPT-6 medium 轨迹复核

结论：四份答案均有真实的生产代码修复，原始 reward=1 得到了完整最终状态重放和独立补测的支持。没有在已审查材料中发现 reward hack，也没有复现“候选实现存在任务范围内缺陷、但 verifier 仍放行”的假阳性。任务可以保留；现有 verifier 存在覆盖空白，不能将 4/4 解释为它已覆盖所有缺陷。

本轮采用用户要求的轨迹与最终产物审查、A100 离线重放和差分诊断；没有再次调用模型，没有修改 task 或评分 verifier。64 项新增诊断中，44 项针对核心路径，20 项属于扩展探索，均不直接改变正式评分。

## 固定输入与证据范围

- task：`vllm-multimodal-merge-memory`，版本 1.3.2，32 项正式检查。
- task revision：`5a8b78f293f48ad6d317164beaa152857f588618`。
- vLLM Base：`36d7f19897843c9cbdb701ba88d0f2c29954fe44`。
- image：`ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0`。
- image ID：`sha256:9b8b0bfbce07832a29b5831c05726ca795f00eface39d678b9a9aea20646d51b`。
- 原始有效批次：`codex-gpt6-medium-r03`；Codex CLI 0.153.4、Harbor 0.22.0；原生轨迹记录模型 `gpt-6-astra`，reasoning effort `medium`。不可变模型版本未记录。
- 审查了四份完整 ATIF 中的行动、工具输入输出、最终 tracked patch 和新增测试；保留并核对原生 session。对完整仓库归档进行离线还原，包括 `.git`、未跟踪文件、忽略文件、`.venv` 和原生资产，并比较 Base 文件清单。不是仅应用可见 patch 后测试。
- 每个重放容器一张 A100，4 CPU、16 GiB RAM、1 GiB shm，禁用网络。候选诊断以 agent 身份执行；正式评分继续采用可信测试挂载及既有监督机制。
- 文件清单的非 `.git` 文件数依次为 4976、4975、4972、4973。除生产修改、新增测试外，差异为正常 uv 虚拟环境脚手架及 Python/pytest 缓存；未发现修改或新增原生二进制载荷。轨迹中的安装尝试未成功替换系统依赖。

## 每次尝试

下表时间为原始有效 trial 的 total / agent / verifier 秒数；agent 时间含基础设施重试及捕获。Agent Step 只统计 ATIF `source=agent`；工具数为顶层编排调用数，不是内部 shell 子命令数。文件及行数统计最终 tracked 和 untracked 文本差异。

| Trial 后缀 | GPU | 原始评分 | 完整重放 | 新增诊断 | 时间（秒） | Agent Step / 工具 | 文件 / 增删行 |
|---|---:|---|---|---|---|---|---|
| BnWSbdd | 0 | 32/32，reward 1 | 32/32，reward 1 | 58/58 + 6/6 | 718.6 / 643.6 / 47.7 | 19 / 18 | 2 / +170 −23 |
| iBKe4DE | 1 | 32/32，reward 1 | 32/32，reward 1 | 58/58 + 6/6 | 755.3 / 679.4 / 48.7 | 29 / 28 | 3 / +187 −26 |
| Qt4qny2 | 2 | 32/32，reward 1 | 32/32，reward 1 | 58/58 + 6/6 | 828.7 / 753.9 / 48.0 | 27 / 26 | 2 / +183 −25 |
| kzaY4Pk | 3 | 32/32，reward 1 | 32/32，reward 1 | 58/58 + 6/6 | 704.7 / 628.1 / 49.1 | 20 / 19 | 2 / +181 −24 |

四次正式重放均完成全部 32 个 checkpoint，child_status=0，errors 为空，无失败或跳过。新增 6 项为独立诊断，因此该阶段 result.json 的 reward=null 不表示失败，也不是一次新评分。

四份都修改 `vllm/model_executor/models/utils.py` 并新增一份真实测试；GPU1 另修改 `interfaces.py` 的空输入处理。

- **GPU0**：递归遍历二维 source view，在 mask 原设备求位置，再搬运小索引，按约 1 MiB 切块转换 dtype 和写回；提前验证行数和宽度。轨迹自测最终 81 项（含 4 项已有 utility 测试），还实际检查 profiler 的显存与传输。
- **GPU1**：递归 view、1024 行切块和分段索引搬运。轨迹中发现 CPU 目标配 CUDA mask 的非阻塞 D2H 竞争，修正为 CPU 目标采用阻塞搬运，自测 39 项通过。这个反向设备扩展不作为其他答案的额外扣分要求。
- **GPU2**：连续源走 flatten view 快路，非连续源递归二维 view；使用 pinned 索引异步搬运、小块转换及 `index_put_`。最终 53 项自测（含 4 项已有测试）。首次初始化的等待经隔离显示也出现在单独 dtype 转换；预热后的独立 pending-event 探针通过，不能将首次初始化时间直接当成算法同步缺陷。
- **GPU3**：按 1024 token 的 mask 段处理，跨 source leaf 填充，使用 pinned 索引及 `index_copy_`。自测 46 项（含 4 项已有测试），最后 pinned 索引调整又通过 3 项 CUDA 定向测试。

这些修改消除了合并阶段的大中间张量，而不是硬编码评分结果或绕过生产入口。未观察到读取外部答案、篡改奖励、跳过可信评分入口的行动。

## 独立检查：现有 verifier 的覆盖空白是否藏着错误

| 行为 / 合同依据 | 原 verifier 的空白 | 本轮输入和独立期望 | 四份结果 |
|---|---|---|---|
| 顺序、dtype、原地修改、非占位行保留；明确要求 | 未系统覆盖非连续源/目标及跨叶片切块 | 6144×37，三种 dtype、两种 mask 设备、strided/nested/rank4 源；CPU 独立展开后比较，检查目标外围存储 | 全通过 |
| 重复调用不遗留状态；明确要求 | 原测试重复相同 mask/source | 连续更换 mask、源值、数量；正常零行 tensor 与非空调用交替 | 全通过 |
| 数量不匹配必须给有用错误；明确要求 | 原计数错误主要是很小的行数 | 1023/1024、1025/1024、3072/3073、3073/3072，tensor/nested 源与两种 mask；检查异常及实际/期望数量 | 全通过 |
| CPU mask 不等 GPU；明确要求 | sync-debug 和显式 synchronize 拦截不是全部异步行为证明 | 在 default/nondefault stream 上放置未完成 GPU 工作和后续 source 更新；要求函数返回时 event 未完成，完成后数据正确 | 全通过 |
| 降低临时 GPU 内存；明确要求 | 现有尺寸有限，4×阈值只是回归上界 | 32768×2048 fp16 目标（128 MiB）、非连续 fp32 源；三次调用测峰值及残留 | 全通过 |
| 实际 Qwen 调用可用；题面业务路径 | 原检查主要是共享接口 | 真正调用 Qwen3-VL `embed_input_ids`，DeepStack 开/关、两种 mask，三次更换数据；独立计算 text/main/deepstack 期望 | 全通过 |

第一组 58 项：36 项语义组合、2 项嵌套空容器探索、16 项边界计数、2 项 pending-event、2 项大输入内存。第二组 6 项：4 项 Qwen/DeepStack、2 项正常零行 tensor 交替调用。36 项中有 18 项使用三维目标；加上 2 项嵌套空容器，总计 20 项扩展探索，和 44 项核心诊断明确分开。

大输入诊断实测额外峰值（CPU mask / CUDA mask）：GPU0 为 136 / 136 KiB，GPU1 为 8.5 / 136 KiB，GPU2 为 136 / 136 KiB，GPU3 为 20 / 256.5 KiB。每种条件连续三次，残留 allocated bytes 均为 0。这些是该固定形状的结果，不代表所有形状的内存上界，也不代表整个推理服务不会 OOM。

pending-event 探针均先预热，再让 GPU 排队执行实际 source 更新。四份实现返回时间约 0.11–0.40 ms，返回时事件仍未完成。另在干净容器中用 Oracle 做正例，并在同一实现尾部故意添加 `torch.cuda.synchronize()` 做负例：两种 stream 的正例均通过，两个负例均被拒绝，负例等待约 457 ms。因此没有依赖单纯 wall-clock 阈值或仅检查源码字符串。

## 差分对照及适用范围

Oracle 和已有 alternative 都重放正式 32/32。Oracle 在第一组探索中为 56/58，alternative 为 38/58；第二组实际 Qwen 与正常空输入均为 6/6。

二者都失败的两项是“列表内部再包含空列表”的探索输入，Base 也不支持这一组合。它不能未经合同确认就直接加入正式评分。补充正常零行 tensor 场景后，四份候选和两个对照全部通过。

alternative 另外失败 18 项三维目标/二维 mask 场景，其 `index_copy_` 路径假定二维目标；Oracle 和四份候选通过。Base 的 CUDA mask 语义组也可处理三维目标。这表明 alternative 的通用形状支持有限；当前真实 Qwen 路径是二维目标，应先明确评分合同再决定是否提升为强制项，不能为了参考实现全绿而削弱独立断言。

Base 在第一组诊断为 26/58，但其欠量 masked_scatter 触发 device-side assert 后污染了后续 CUDA 上下文。因此不能把该批次后面的 pending/memory 失败当作独立有效负例；同步负例已另开干净进程完成。Base 的结果仅按可独立解释的早期检查使用。

本轮第一个恢复批次在执行候选代码前，被 tarfile 默认安全过滤器拒绝 `.venv/bin/python` 的绝对符号链接。第二批只允许三个已核对的解释器链接及既定目标，其余继续使用 data_filter，完整恢复成功。该基础设施错误不计入候选失败。

此前 r01 的 Docker 地址池错误、r02 的连接错误及 r03 开始时的代理冲突，都与最终四份有效答案分开保存，不混入能力通过率。

## 评分判断与后续处理

确认的是覆盖空白及已执行输入上的行为；没有确认这四份答案存在漏判缺陷。因此保持此次 4/4 的结果，不调整 reward，不修改题面或 verifier，也没有新的 commit/push。

后续加固应优先将上表的非连续布局、变化输入的重复调用、跨块计数、预热 pending-event 和 Qwen/DeepStack 方法级调用整理成小而稳定的正式用例。它们在本次四份候选上都通过；本轮没有把诊断直接提升为新版评分，也没有把扩展探索范围自动追加到题面。

实际 Qwen 检查复用了真实 `embed_input_ids`、继承的文本嵌入处理和 `_compute_deepstack_embeds`；使用确定性 embedding 权重替代完整模型加载，捕获 DeepStack 输出代替下游模型消费。未加载完整 Qwen 权重、未运行 HTTP 服务或真实图像编码。因此结论针对任务的合并行为及其实际方法调用链。上游 DeepStack 自身的 cat 等既有分配不属于这次 merge 修复的证明范围。

评分监督代码保持原状。未发现本次轨迹作弊，不等于证明监督器可抵抗任意恶意原生代码。四次小样本通过也不等于模型总体通过率 100%。

## 复现与证据

A100 根目录：`/data/codex-pr63-rollouts-20260918`。`codex-review-02` 是完整评分加 58 项诊断，`codex-review-03` 是 6 项调用链诊断；`codex-review-sync-control` 是独立同步正负例。每项 result.json 保留实际 Docker 命令，inputs-before.json 保留执行前输入哈希，批次 results.json 保留执行后不变性检查。全仓库归档仍在原始 trial 的 `agent/final-state/full-repository.tar.gz`。

本地证据链接如下（归档包含完整诊断日志和脚本；原始大仓库快照保留在 A100）：

- [原始四次运行报告](LOCAL_WORKSPACE/outputs/pr63-codex-gpt6-medium-results.md)
- [本轮证据归档](LOCAL_WORKSPACE/work/codex63/review/evidence.tar.gz)
- [独立探针](LOCAL_WORKSPACE/work/codex63/review/probes.py)
- [Qwen 调用链探针](LOCAL_WORKSPACE/work/codex63/review/probes-production.py)
- [同步正负例](LOCAL_WORKSPACE/work/codex63/review/sync-control.py)
- [轨迹指标与原生日志哈希](LOCAL_WORKSPACE/work/codex63/review/attempt-metrics.json)

本地证据及所用 skill 的 SHA-256（报告生成时核对；执行前哈希另见 inputs-before.json）：

- `work/codex63/review/evidence.tar.gz`：`f4cc1b9f33de86a014a13a1941775b5fbd2a8fd1c8d952110f2bc86f67c45303`
- `work/codex63/evidence.tar.gz`：`72eade23d91a8a8a18c917a28395a6ba2cdd5fb23074bf44897616efb15d7830`
- `work/ai-infra-bench/.agents/skills/ai-infra-bench-rollout-review/SKILL.md`：`767fe719670c4a10753d7643cddbbab9c73f111c025f2d09fe03a6cf72a22f1f`
- `work/ai-infra-bench/.agents/skills/ai-infra-bench-rollout-review/references/differential-cases.md`：`982a418e7ef9add3011ef8754e7a2ef31e0ad6ba9a8e370875194966263662d6`
- `work/ai-infra-bench/.agents/skills/ai-infra-bench-rollout-review/references/reporting.md`：`2b895c1509d9b9f64f004d21e0b5c34c79360f6d45b0dd0ee19a32fed63077a6`
