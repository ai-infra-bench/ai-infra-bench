# PR #63: four Codex GPT-6 medium runs

Task revision: 5a8b78f293f48ad6d317164beaa152857f588618; task version 1.3.2.
Model recorded: gpt-6-astra, medium. Codex CLI 0.153.4; Harbor 0.22.0.
Trials: BnWSbdd, iBKe4DE, Qt4qny2, kzaY4Pk. Each original and replay score: 32/32, reward 1.
Each candidate also passed 64/64 diagnostic cases (44 core, 20 exploratory; not a revised scoring suite).

runs/: four complete readable trajectories, native session JSONL, agent logs, configs, verifier logs/results, final tracked patches and untracked-file archives, final-state manifests.
review-evidence/: offline replay, independent diagnostics, positive/negative controls, scripts, input hashes and inventory.
reports/: run summary and trajectory review (Chinese). LOCAL_WORKSPACE links describe original local evidence locations; use bundled files where applicable.

Full multi-GB repository snapshots are retained on A100, not included in this portable ZIP. Their identities are in captured manifests and replay input hashes. The readable trajectory content and tool outputs are included. 79 opaque encrypted_content fields were omitted from exported native sessions; original sessions remain preserved. No authentication files are included. Earlier failed infrastructure-only campaigns r01/r02 are excluded; r03's own initial retries remain in its logs.

MANIFEST.sha256.json hashes the actual files in this ZIP. Independent diagnostics do not constitute a full model-serving test.
