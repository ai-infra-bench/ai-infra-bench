from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,shlex,time
ROOT=Path('/data/codex-pr63-rollouts-20260918');TASK=ROOT/'repo/tasks/vllm-multimodal-merge-memory';SCRIPT=Path('/tmp/codex-pr63-hardening-20260918/codex-review-probes.py');OUT=ROOT/'codex-review-02';OUT.mkdir(exist_ok=False)
IMAGE='ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0'
archives=[next((ROOT/'codex-gpt6-medium-r03').glob(f'jobs/*gpu{i}/*/agent/final-state/full-repository.tar.gz')) for i in range(4)]
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=[SCRIPT,Path(__file__),*TASK.joinpath('tests').glob('*'),TASK/'solution/oracle.patch',TASK/'validation/alternative-agent-implementation.patch',*archives];files=[p for p in files if p.is_file()]
frozen={str(p):digest(p) for p in files}
for a in archives:assert frozen[str(a)]==json.loads((a.parent/'manifest.json').read_text())['files']['full-repository.tar.gz']['sha256']
(OUT/'inputs-before.json').write_text(json.dumps({'hashes':frozen,'image':subprocess.check_output(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],text=True).strip()},indent=2))
restore="""import tarfile,shutil
shutil.rmtree('/workspace/repo')
def filt(m,d):
 if m.issym() and m.name in ('repo/.venv/bin/python','repo/.venv/bin/python3','repo/.venv/bin/python3.12') and m.linkname in ('/usr/local/bin/python','python'):
  return m
 return tarfile.data_filter(m,d)
with tarfile.open('/snapshot.tar.gz') as t:t.extractall('/workspace',filter=filt)
"""
def run(i):
 name=f'gpu{i}' if i<4 else ('oracle' if i==4 else 'alternative');d=OUT/name;d.mkdir();gpu=i if i<4 else i-4
 cmd=['docker','run','--rm','--init','--name','pr63-codex-review-'+name,'--network','none','--gpus',f'device={gpu}','--cpus','4','--memory','16g','--shm-size','1g','--user','root','--entrypoint','bash','-v',str(TASK/'tests')+':/tests:ro','-v',str(SCRIPT)+':/challenge.py:ro','-v',str(d)+':/logs/verifier']
 if i<4:cmd+=['-v',str(archives[i])+':/snapshot.tar.gz:ro'];setup='python3 -c '+shlex.quote(restore)
 else:
  patch=TASK/('solution/oracle.patch' if i==4 else 'validation/alternative-agent-implementation.patch');cmd+=['-v',str(patch)+':/control.patch:ro'];setup='git -C /workspace/repo -c safe.directory=/workspace/repo apply /control.patch'
 cmd += [IMAGE,'-lc','set -e; '+setup+'; cd /workspace/repo; bash /tests/test.sh; runuser -u agent -- python3 /challenge.py > /logs/verifier/challenge.log 2>&1']
 started=time.time()
 with (d/'launcher.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 record={'name':name,'exit':r.returncode,'seconds':time.time()-started,'command':cmd,'reward':(d/'reward.txt').read_text().strip() if (d/'reward.txt').exists() else None}
 if (d/'challenge.log').exists():
  for l in (d/'challenge.log').read_text().splitlines():
   if l.startswith('SUMMARY '):record['challenge']=json.loads(l[8:])
 (d/'result.json').write_text(json.dumps(record,indent=2));print(name,r.returncode,record['reward'], {k:v for k,v in record.get('challenge',{}).items() if k!='records'},flush=True);return record
with concurrent.futures.ThreadPoolExecutor(4) as pool:rows=list(pool.map(run,range(4)))
# Matching Oracle/alternative controls are preserved in codex-review-01.
assert frozen=={str(p):digest(p) for p in files}
(OUT/'results.json').write_text(json.dumps({'inputs_unchanged':True,'records':rows},indent=2))
