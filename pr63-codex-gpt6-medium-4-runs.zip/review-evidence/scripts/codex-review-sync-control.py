import sys, json, time, itertools, traceback
sys.path.insert(0, '/workspace/repo')
import torch
from vllm.model_executor.models.utils import _merge_multimodal_embeddings as merge
torch.set_num_threads(1)
records = []

def case(name, fn):
    try:
        detail = fn()
        records.append(dict(name=name, passed=True, detail=detail))
    except Exception as e:
        records.append(dict(name=name, passed=False, error=type(e).__name__, message=str(e), traceback=traceback.format_exc()))
    print(json.dumps(records[-1]), flush=True)

def semantic(md, dtype, form, batched):
    h = 37
    n = 6144
    shape = (2, 3072) if batched else (6144,)
    storage = torch.full((3072, 2, h * 2) if batched else (h * 2, n), -11.0, device='cuda', dtype=dtype)
    x = storage.transpose(0, 1)[..., ::2] if batched else storage.t()[:, ::2]
    expected = x.cpu().clone()
    for step in range(3):
        mask = (torch.arange(n).reshape(shape) + step) % 2 == 0
        k = int(mask.sum())
        values = (torch.arange(k * h).reshape(k, h) % 197 + step * 7).float()
        backing = torch.empty((k, h * 2), device='cuda')
        backing[:, ::2] = values.cuda()
        src = backing[:, ::2]
        if form == 'rank4':
            src = src.reshape(3, 2, 512, h).transpose(0, 2)
            ordered = values.reshape(3, 2, 512, h).transpose(0, 2).reshape(-1, h)
        elif form == 'nested':
            src = [src[:1023], (src[1023:1025], [src[1025:]])]
            ordered = values
        else:
            ordered = values
        out = merge(x, src, mask.to(md))
        expected[mask] = ordered.to(dtype)
        assert out is x and out.dtype == dtype
        assert torch.equal(x.cpu(), expected), 'logical row order / unchanged rows / strided in-place output'
        assert bool((storage[..., 1::2] == -11).all()) if batched else bool((storage[1::2, :] == -11).all()), 'outside destination view changed'
    return {'calls': 3}

def changed_empty(md):
    x = torch.full((17, 7), -4.0, device='cuda')
    expected = x.cpu().clone()
    for j, positions in enumerate(([1, 7, 13], [], [0], [], [2, 5, 16])):
        mask = torch.zeros(17, dtype=torch.bool)
        mask[positions] = True
        vals = (torch.arange(len(positions) * 7).reshape(-1, 7) + j * 29).float()
        src = ([], torch.empty((2, 0, 7), device='cuda')) if not positions else [vals.cuda()]
        out = merge(x, src, mask.to(md))
        expected[mask] = vals
        assert out is x and torch.equal(x.cpu(), expected)
    return {'calls': 5}

def mismatches(md, actual, expected, form):
    x = torch.zeros((4101, 29), device='cuda')
    mask = (torch.arange(4101) < expected).to(md)
    values = torch.ones((actual, 29), device='cuda')
    src = values.reshape(1, actual, 29) if form == 'tensor' else (values[:1024], [values[1024:]])
    try:
        merge(x, src, mask)
    except ValueError as e:
        assert str(actual) in str(e) and str(expected) in str(e), str(e)
        return {'error': str(e)}
    raise AssertionError('cardinality mismatch accepted')

def pending(nondefault):
    stream = torch.cuda.Stream() if nondefault else torch.cuda.default_stream()
    with torch.cuda.stream(stream):
        x = torch.zeros((3072, 73), device='cuda', dtype=torch.bfloat16)
        mask = torch.arange(3072) % 3 == 1
        v = torch.ones((1024, 73), device='cuda')
        for _ in range(3):
            merge(x, v, mask)
        stream.synchronize()
        obs = []
        for j in range(3):
            ev = torch.cuda.Event()
            torch.cuda._sleep(500000000)
            v.fill_(j + 2)
            ev.record()
            before = ev.query()
            start = time.perf_counter()
            out = merge(x, v, mask)
            after = ev.query()
            elapsed = time.perf_counter() - start
            stream.synchronize()
            assert out is x and torch.equal(x[mask.cuda()], torch.full_like(x[mask.cuda()], j + 2))
            obs.append(dict(before=before, after=after, seconds=elapsed))
        assert all((not x['before'] and (not x['after']) for x in obs)), str(obs)
    return obs

def memory(md):
    x = torch.zeros((32768, 2048), device='cuda', dtype=torch.float16)
    m = (torch.arange(32768) % 2 == 1).to(md)
    src = torch.ones((2, 8192, 2048), device='cuda', dtype=torch.float32).transpose(0, 1)
    merge(x, src, m)
    torch.cuda.synchronize()
    base = torch.cuda.memory_allocated()
    obs = []
    for _ in range(3):
        torch.cuda.reset_peak_memory_stats()
        merge(x, src, m)
        torch.cuda.synchronize()
        obs.append({'extra_peak_bytes': torch.cuda.max_memory_allocated() - base, 'retained_bytes': torch.cuda.memory_allocated() - base, 'destination_bytes': x.numel() * x.element_size()})
        assert obs[-1]['extra_peak_bytes'] < 4 * x.numel() * x.element_size()
        assert obs[-1]['retained_bytes'] == 0
    assert bool((x[1::2] == 1).all()) and bool((x[::2] == 0).all())
    return obs
for nd in (False,True):case("oracle_pending_"+str(nd),lambda nd=nd:pending(nd))
original=merge
def merge(*args,**kwargs):
 r=original(*args,**kwargs)
 torch.cuda.synchronize()
 return r
for nd in (False,True):case("blocking_negative_"+str(nd),lambda nd=nd:pending(nd))
print("SUMMARY "+json.dumps(records))
