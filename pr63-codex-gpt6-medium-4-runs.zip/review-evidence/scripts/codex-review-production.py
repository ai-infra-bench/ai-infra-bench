"""Follow-up: genuine Qwen3-VL merge/deepstack lifecycle and ordinary empty tensors."""
import json,sys,traceback
sys.path.insert(0,'/workspace/repo')
import torch
from vllm.model_executor.models.utils import _merge_multimodal_embeddings as merge
from vllm.model_executor.models.interfaces import SupportsMultiModal
from vllm.model_executor.models.qwen3_vl import Qwen3VLForConditionalGeneration as Qwen
torch.set_num_threads(1)
rows=[]
def case(name,f):
 try:r=f();rows.append({'name':name,'passed':True,'detail':r})
 except Exception as e:rows.append({'name':name,'passed':False,'error':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
 print(json.dumps(rows[-1]),flush=True)
def qwen(md,deep):
 h=31;n=4103;levels=2
 weights=torch.arange(128*h).reshape(128,h).float()%97
 class LM:
  def embed_input_ids(self,ids):return torch.nn.functional.embedding(ids,weights.to(device='cuda',dtype=torch.float16))
 class Model:
  _embed_text_input_ids=SupportsMultiModal._embed_text_input_ids
  _compute_deepstack_embeds=Qwen._compute_deepstack_embeds
  def _set_deepstack_input_embeds(self,x):self.received=x
 model=Model();model.language_model=LM();model.visual_dim=h;model.multiscale_dim=levels*h;model.deepstack_num_level=levels;model.use_deepstack=deep
 SupportsMultiModal.configure_mm_token_handling(model,vocab_size=128,mm_token_ids=[1])
 ids=(torch.arange(n)%128).cuda()
 for step in range(3):
  mask=torch.arange(n)%3==step;k=int(mask.sum());width=h*(1+levels) if deep else h
  values=(torch.arange(k*width).reshape(k,width)%103+step).float();v=values.cuda();src=(v[:1023],v[1023:])
  out=Qwen.embed_input_ids(model,ids,src,is_multimodal=mask.to(md));torch.cuda.synchronize()
  expected=weights[torch.arange(n)%128].half();expected[mask]=values[:,:h].half();assert torch.equal(out.cpu(),expected)
  if deep:
   stacked=torch.zeros(n,levels*h,dtype=torch.float16);stacked[mask]=values[:,h:].half()
   assert torch.equal(model.received.cpu(),stacked.view(n,levels,h).permute(1,0,2))
 return {'calls':3,'real_methods':['Qwen3VLForConditionalGeneration.embed_input_ids','_compute_deepstack_embeds'] if deep else ['Qwen3VLForConditionalGeneration.embed_input_ids']}
for md in ('cpu','cuda'):
 for deep in (False,True):case(f'qwen_{md}_deepstack{deep}',lambda md=md,deep=deep:qwen(md,deep))
def varying(md):
 x=torch.full((17,7),-9.,device='cuda',dtype=torch.float16);expected=x.cpu().clone()
 for j,positions in enumerate(([1,7,13],[],[0],[],[2,5,16])):
  mask=torch.zeros(17,dtype=torch.bool);mask[positions]=True;v=(torch.arange(len(positions)*7).reshape(-1,7)+j*17).float()
  source=[torch.empty((2,0,7),device='cuda')] if not positions else (v.cuda(),)
  out=merge(x,source,mask.to(md));expected[mask]=v.half();assert out is x and torch.equal(x.cpu(),expected)
 return {'calls':5}
for md in ('cpu','cuda'):case('ordinary_varying_empty_'+md,lambda md=md:varying(md))
print('SUMMARY '+json.dumps({'passed':sum(r['passed'] for r in rows),'total':len(rows),'records':rows}),flush=True)
