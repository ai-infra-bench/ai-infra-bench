from pathlib import Path
import tarfile,json,hashlib,time
root=Path('/data/codex-pr63-rollouts-20260918');base=json.loads((root/'base-file-manifest.json').read_text());out=root/'codex-gpt6-medium-r03-inventory';out.mkdir(exist_ok=True)
for archive in sorted((root/'codex-gpt6-medium-r03').glob('jobs/*/*/agent/final-state/full-repository.tar.gz')):
 before=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest();files={}
 with tarfile.open(archive,'r|gz') as t:
  for m in t:
   p=Path(m.name);parts=p.parts
   if parts[0]=='repo':parts=parts[1:]
   if not parts or parts[0]=='.git':continue
   name='/'.join(parts)
   if m.isfile():files[name]={'bytes':m.size,'sha256':hashlib.file_digest(t.extractfile(m),'sha256').hexdigest(),'type':'file'}
   elif m.issym():files[name]={'type':'symlink','target':m.linkname}
 changes={k:{'before':base.get(k),'after':files.get(k)} for k in sorted(set(base)|set(files)) if base.get(k)!=files.get(k)}
 after=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest();assert before==after
 record={'archive':str(archive),'sha256':before,'files':len(files),'changes':changes}
 name=archive.parents[2].name;(out/(name+'.json')).write_text(json.dumps(record,indent=2));print(name,len(files),list(changes),flush=True)
