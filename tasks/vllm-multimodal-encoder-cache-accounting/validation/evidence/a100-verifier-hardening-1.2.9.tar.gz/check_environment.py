import json
from pathlib import Path
import subprocess
import uuid
root=Path('/tmp/pr84-verifier-20260918-final')
out=root/'environment-check';out.mkdir(exist_ok=True)
image='sha256:aad47363477b6b2092e8d3ba616da14fc35a11af170bc19f8d26de7ef00bb107'
script='''set -eu
runuser -u agent -- python3 -I -c 'import pathlib,torch,vllm; assert str(pathlib.Path(vllm.__file__).resolve()).startswith("/app/"); print("AGENT_IMPORT_OK", torch.__version__, vllm.__file__)'
runuser -u agent -- python3 -m pytest --collect-only -q tests/v1/core/test_encoder_cache_manager.py
set +e
runuser -u nobody -- python3 -I /challenge/challenge_encoder_cache.py > /evidence/base-challenge-cache.log 2>&1
a=$?
runuser -u nobody -- python3 -I /challenge/challenge_encoder_capacity.py > /evidence/base-challenge-capacity.log 2>&1
b=$?
printf 'BASE_CHALLENGE_EXIT cache=%s capacity=%s\\n' "$a" "$b"
test "$a" -eq 1 && test "$b" -eq 1
'''
name='pr84-env-'+uuid.uuid4().hex[:10]
cmd=['docker','run','--name',name,'--network','none','--user','0:0','--cpus','4','--memory','16g','--entrypoint','bash','--mount',f'type=bind,source={root}/task/validation/challenge,target=/challenge,readonly','--mount',f'type=bind,source={out},target=/evidence',image,'-c',script]
try:
 with (out/'environment.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 (out/'status.json').write_text(json.dumps({'exit_code':r.returncode,'scope':'pinned image agent imports, pytest collection, Base independent negative challenges'},indent=2))
finally:subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=20)
