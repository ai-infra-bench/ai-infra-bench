"""Final frozen-source Harbor trials; no model calls."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from harbor.job import Job
from harbor.models.job.config import JobConfig

ROOT = Path('/data/pr84-paired-host-fixes-20260919')
TASK = ROOT / 'frozen-task'
PREVIOUS = Path('/data/pr84-independent-review-evidence-20260919')


async def main():
    infra = ROOT / 'harbor-infra'
    shutil.copytree(PREVIOUS / 'harbor-infra', infra,
                    ignore=shutil.ignore_patterns('__pycache__'))
    sys.path.insert(0, str(infra))
    os.environ['DOCKER_CONFIG'] = str(PREVIOUS / 'docker-config')
    cases = {case['name']: case for case in json.loads(
        (TASK / 'validation/ci-cases.json').read_text())['cases']}
    selected = ['oracle', 'alternate-lazy-position-metadata', 'alternate-preallocated-position-metadata', 'alternate-width-position-metadata', 'numpy-leak-with-fixed-metadata', 'numpy-payload-eviction-leak', 'python-list-eviction-leak', 'traced-python-eviction-leak', 'alternate-existing-tracemalloc', 'alternate-reusable-payload-pool', 'alternate-cache-capacity-fields', 'dynamic-report-forgery', 'early-os-exit']
    tasks = []
    for name in selected:
        task = ROOT / 'harbor-tasks' / name
        shutil.copytree(TASK, task)
        if name != 'oracle':
            case = cases[name]
            shutil.copy2(TASK / 'validation' / case['patch'], task / 'solution/control.patch')
            script = '#!/usr/bin/env bash\nset -euo pipefail\ncd /workspace/vllm\n'
            if case.get('apply_after', 'base') == 'oracle':
                script += 'git apply /solution/oracle.patch\n'
            script += 'git apply /solution/control.patch\n'
            (task / 'solution/solve.sh').write_text(script)
        tasks.append({'path': str(task)})
    config = dict(job_name='paired-host-final', jobs_dir=str(ROOT / 'harbor-jobs'),
                  n_concurrent_trials=4, quiet=True,
                  environment={'import_path': 'offline_harbor:OfflineDockerEnvironment'},
                  agents=[{'name': 'oracle'}], tasks=tasks, retry={'max_retries': 0})
    (ROOT / 'harbor-config.json').write_text(json.dumps(config, indent=2) + '\n')
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
              for directory in (ROOT / 'harbor-tasks', infra)
              for p in directory.rglob('*') if p.is_file()}
    (ROOT / 'harbor-input-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
    result = await (await Job.create(JobConfig.model_validate(config))).run()
    (ROOT / 'harbor-result.json').write_text(result.model_dump_json(indent=2) + '\n')
    print(result.model_dump_json(indent=2))


if __name__ == '__main__':
    asyncio.run(main())
