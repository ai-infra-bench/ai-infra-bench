"""Independent physical eviction check through the real request lifecycle."""
import gc
import json
from pathlib import Path
import sys
import types

tests = Path('/tests')
module = types.ModuleType('_independent_eviction')
module.__file__ = str(tests / 'encoder_runtime.py')
sys.modules[module.__name__] = module
for name in ('encoder_runtime.py', 'encoder_scenarios.py'):
    exec(compile((tests / name).read_text(), str(tests / name), 'exec'), module.__dict__)
torch = module.torch
handles = []

def remember(outputs):
    for output in outputs:
        handles.append(output.untyped_storage()._weak_ref())

def resident_outputs():
    gc.collect()
    sizes = []
    for handle in handles:
        storage = torch.UntypedStorage._new_with_weak_ptr(handle)
        sizes.append(0 if storage is None else storage.nbytes())
    return sizes

records = []
try:
    with module.Runtime() as runtime:
        profile = module.specification(16, [0, 2, 4, 6, 8, 10, 12, 14])
        pair = runtime.pair(profile, chunk=4)
        pair.model.on_encode = remember
        try:
            capacity = pair.scheduler.encoder_cache_manager.cache_size
            for index in range(6):
                spec = module.specification(16, [0, 2, 4, 6, 8, 10, 12, 14], value=100 + index * 20)
                pair.add(module.request_workload('item-' + str(index), 18, [spec], token=20 + index))
                pair.step()
                active = resident_outputs()
                pair.finish()
                completed = resident_outputs()
                records.append(dict(request=index, active_output_bytes=active,
                                    after_completion_output_bytes=completed,
                                    total_retained_encoder_bytes=sum(completed)))
        finally:
            pair.close()
finally:
    for handle in handles:
        torch.UntypedStorage._free_weak_ref(handle)
print('INDEPENDENT_EVICTION=' + json.dumps(dict(cache_capacity_rows=capacity, row_bytes=64, records=records)))
