import ast
import gc
import json
from pathlib import Path
import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_leaves

path = Path('/tests/encoder_storage.py')
tree = ast.parse(path.read_text())
node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'PayloadStorage')
exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'))

results = []
for factory in ('torch.empty', 'payload.new_empty'):
    for length in (16, 128, 4096):
        observer = PayloadStorage()
        try:
            with observer:
                payload = torch.ones(8, 16)
                observer.mark([payload])
                original_mask = torch.arange(length) < 8
                if factory == 'torch.empty':
                    mask = torch.empty(length, dtype=torch.bool, device=payload.device)
                else:
                    mask = payload.new_empty((length,), dtype=torch.bool)
                mask.copy_(original_mask)
            results.append(dict(factory=factory, span=length,
                                embedding_bytes=payload.untyped_storage().nbytes(),
                                metadata_bytes=mask.untyped_storage().nbytes(),
                                observed_payload_bytes=observer.live_bytes()))
        finally:
            observer.close()
            del payload, mask, original_mask
            gc.collect()
print(json.dumps(results, indent=2))
