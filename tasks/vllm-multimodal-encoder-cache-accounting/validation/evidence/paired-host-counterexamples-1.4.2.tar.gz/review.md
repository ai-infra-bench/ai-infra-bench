**结论：1.4.2 仍需要修改后再合并。** 本轮评审对象是 PR #84 的 `58fed254d542d8ce08b5195c4dd2390577b82066`，相对上次 `3602b95` 的更新。原来的 Tensor 淘汰检测、等价 mask 分配、容量字段改名和诊断入口修复在本轮选取的回归中符合预期；新增 `host_storage` 生命周期规则又产生了可复现的误拒和漏检。

**R1 · P1：把整个 worker 的 host 分配增长当作 encoder payload 增长，误拒有界元数据的延迟分配。** 位置：`tests/encoder_host_storage.py:27–34, 73–86`；父进程在 `tests/verify_encoder_cache.py:87–89` 重复相同判定。

`trace_host_allocations()` 记录整个进程的 traced-memory 增量。生命周期断言把前四个请求后的峰值当成基线，要求之后所有请求的总 host 占用不超过基线加固定/比例余量。它没有区分 encoder 值副本和与 encoder payload 无关的状态，也隐含要求任何有界缓存必须在四个请求内完成分配。

独立正例保留 Oracle 的完整功能，只记录最近 64 个请求的 prompt-position coverage，用 bool 数组保存诊断元数据。每个数组最多 `max_model_len=8192` 字节，固定总上限 512 KiB，不保存任何 encoder 值。有两种实现：需要新记录时分配，或构造时预分配同样大小的环形存储。完整原始 `test.sh` 给延迟分配版本 reward 0，唯一失败为 `host_storage`；预分配版本 reward 1。Harbor 分别为 `bounded-metadata-lazy__9pZgdUN`（0）和 `bounded-metadata-preallocated__zJpzWJr`（1），均无 trial error。

独立真实生命周期验证运行 96 个请求，每轮仍核对实际模型输入。两种实现的诊断历史在第 4、32、64、96 个请求时内容 SHA-256 完全一致；都在 64 条、524288 字节处封顶，直到第 96 个请求仍是同样大小。实际 encoder Tensor 驻留量始终为 8192 字节，没有保留已淘汰 encoder 的副本。因此这是分配时机影响得分，不是 payload 泄漏。题面没有要求诊断或位置元数据必须预分配，也没有规定它们只能保留四轮。

证据：`bounded-metadata-lazy/result.json`、`bounded-metadata-preallocated/result.json`、两份同名 `*-lifecycle.json`，及对应 `.patch`。这些候选 patch 不读取测试、伪造报告或改动 verifier。独立诊断为了说明已知对照的状态读取了该对照的诊断字段；这些读取不参与评分，也不构成对被测实现的接口要求。

建议将生命周期观测限定或差分归因到题面要求的 encoder payload 保留，允许有界的非 payload 状态按自身策略分配。将两个内容相同、分配时机不同的元数据实现保留为正例。增加 warmup 次数或提高阈值无法解决判定对象不一致的问题。

**R2 · P1：容差按整个 runner 的初始占用放大，固定非 payload 缓冲区可以掩盖真实 NumPy 泄漏。** 位置：`tests/encoder_host_storage.py:83–85`，及 `tests/verify_encoder_cache.py:87–89`。

`allowance = 65536 + warm // 10` 中的 `warm` 包含构造时分配的所有被跟踪对象，与 encoder payload 规模没有绑定。保留 PR 自己的 NumPy 淘汰泄漏逻辑，再加入一个固定的 8 MiB bool 位置诊断环形缓冲区，完整 verifier 和 Harbor 都给 reward 1。该缓冲区不含 encoder 值，也不随请求或 prompt span 增长。

本轮普通 `numpy-payload-eviction-leak` 重跑得到预期 reward 0；加固定缓冲区的 `numpy-leak-with-fixed-metadata` 却得到 reward 1。后者原始报告的 warm 为 8676353 字节，允许增长 933171 字节；实际第 32 次请求后已额外保留 31 份 NumPy encoder 输出，共 253952 字节，因此被容差放过。独立验证中泄漏在第 64 次达到 516096 字节，第 96 次达到 778240 字节，持续每次增加一份完整输出。Harbor trial `numpy-leak-with-fixed-metadata__4i8nC2i` reward 1、无 trial error。

这是当前声明可观察的 NumPy 分配内的漏检，不依赖任意 native allocator、tracemalloc 篡改或报告伪造。证据：`numpy-leak-with-fixed-metadata/result.json`、`verification.json`、`numpy-leak-with-fixed-metadata-lifecycle.json` 和 `.patch`。建议使判断对固定的无关初始分配保持不变，容差围绕目标 payload 或经过背景校正的增长量建立；加入同一泄漏在有/无固定缓冲区时都必须被拒的组合对照。单独去掉比例项也不能解决 R1 的误拒，需要同时处理观测归因。

**本轮检查与边界。**

| 阶段 | 结论 | 证据 |
|---|---|---|
| 题面 | 可保留 | 与上轮字节相同，明确承诺 embedding 行数计账、有界 payload、窗口、复用和表示自由度；上述两个问题不需要扩题才能修复 |
| 环境 | 未发现新增阻断项 | 固定镜像、环境构建输入及 Oracle 均未改变；新版环境诊断实际通过，Base 窗口挑战通过、容量挑战因 9 行预算实际编码 18 行而失败 |
| verifier | 不通过 | R1 错拒正确延迟分配；R2 放过已知类型的 NumPy payload 泄漏，两者均经正式 Harbor 路径确认 |

语义边界仍是处理后的媒体位置/mask 与 encoder rows → 真实请求接入、整项预留、缓存使用/淘汰、分块主模型及 lookahead 输入准备 → 实际输入、请求进展、有界 encoder payload 和 profiling 一致性。CPU 神经算术和设备原语替换的范围与上轮一致。新增全进程 host 分配观测超出了这个 payload 边界，同时因无关基线放大而失去部分检测能力。

独立重跑了 9 个现有完整入口对照：Base 0、Oracle 1、Scheduler 预算字段改名 1、compact Python payload 1、Python mask 元数据 1、template-mask 分配 1、普通 NumPy 淘汰泄漏 0、遗漏 Tensor 淘汰 0、可复用 payload 缓冲区 1，全部符合预期。另运行本轮三个新增对照；四个 Harbor trial 包含 Oracle，均无基础设施错误。四个 challenge-reporting 单测通过；严格 artifact audit 为 4 checks、0 errors、0 warnings。没有重新执行全部 52 个提交矩阵对照，也没有重新深审历史 agent 轨迹。

Harbor 使用同一固定镜像 `sha256:8d200d6c23d542fb41b456cb55bf5c984b1c467c2020e31fb0e053e120c5f852`、4 CPU、16 GiB、0 GPU，以及 PR 归档中的静态离线 Docker adapter，Harbor 0.22.0 / Compose 5.5.1。测试源码未改；候选只应用 Oracle 和明确保存的对照 patch。`review-results.json` 保存得分、trial 和 patch 身份，`identity.json` 保存 112 个任务文件的哈希；最终检查确认任务和 Harbor 输入未漂移。

PR 中既有的 F3（`disable_chunked_mm_input=True`）明确标为暂缓。本轮没有把该已知范围问题重复列成新发现，也不将它描述为已经修复。

评审 worktree：`/data/codex-pr84-rereview-58fed25-20260919`，证据：`/data/pr84-rereview-58fed25-20260919`。本轮只做评审和独立复现，没有修改、提交、推送 PR，也没有发布 GitHub review/comment。
