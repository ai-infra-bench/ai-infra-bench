"""Diagnose the known controls; this does not modify or participate in scoring."""
import gc
import hashlib
import json
from pathlib import Path
import sys
import types

tests = Path('/tests')
module = types.ModuleType('_independent_history_lifecycle')
module.__file__ = str(tests / 'encoder_runtime.py')
sys.modules[module.__name__] = module
for name in ('encoder_runtime.py', 'encoder_host_storage.py', 'encoder_scenarios.py'):
    exec(compile((tests / name).read_text(), str(tests / name), 'exec'), module.__dict__)

handles = []
torch = module.torch

def remember(outputs):
    for output in outputs:
        handles.append(output.untyped_storage()._weak_ref())

def encoder_bytes():
    sizes = []
    for handle in handles:
        storage = torch.UntypedStorage._new_with_weak_ptr(handle)
        sizes.append(0 if storage is None else storage.nbytes())
    return sum(sizes)

records = []
try:
    with module.hidden_width(256), module.Runtime() as runtime:
        indices = [0, 2, 5, 7, 10, 12, 15, 17]
        profile = module.specification(19, indices)
        pair = runtime.pair(profile, chunk=4)
        pair.model.on_encode = remember
        try:
            for index in range(96):
                item = module.specification(19, indices, value=503 + 31 * index)
                pair.add(module.request_workload(f'independent-{index}', 21, [item], token=31))
                pair.finish()
                module.forget_test_history(pair)
                if index + 1 in (4, 32, 64, 96):
                    gc.collect()
                    # These are fields of the explicit diagnostic controls we
                    # wrote, not candidate interfaces required by the verifier.
                    history = pair.runner._position_history
                    material = [(rid, array.tolist()) for rid, array in history]
                    retained = getattr(pair.runner, '_retained_numpy_encoder_history', [])
                    records.append(dict(
                        completed_requests=index + 1,
                        history_maxlen=history.maxlen,
                        history_entries=len(history),
                        history_value_bytes=sum(array.nbytes for _, array in history),
                        history_sha256=hashlib.sha256(json.dumps(material).encode()).hexdigest(),
                        live_encoder_tensor_bytes=encoder_bytes(),
                        retired_encoder_payload_bytes=sum(array.nbytes for array in retained),
                        retired_encoder_items=len(retained)))
        finally:
            pair.close()
finally:
    for handle in handles:
        torch.UntypedStorage._free_weak_ref(handle)
print('INDEPENDENT_HISTORY=' + json.dumps(records))
