"""Local Harbor adapter: Docker's network=none for an entirely offline task.

The host lacks the kernel support for Harbor's dynamic egress sidecar. This
adapter keeps ordinary Harbor execution, mounts, agents and reward collection,
and only substitutes static Docker isolation for the all-no-network policies.
"""
from pathlib import Path
from harbor.environments.capabilities import EnvironmentCapabilities
from harbor.environments.docker.docker import DockerEnvironment
from harbor.models.task.config import NetworkMode


class OfflineDockerEnvironment(DockerEnvironment):
    @staticmethod
    def _requires_egress_control(**kwargs):
        return False

    def __init__(self, *args, extra_docker_compose=None, **kwargs):
        overlay = Path(__file__).with_name('offline-compose.yaml')
        super().__init__(*args, extra_docker_compose=[*(extra_docker_compose or []), overlay], **kwargs)

    @property
    def capabilities(self):
        return EnvironmentCapabilities(disable_internet=True, mounted=True, docker_compose=True)

    async def _apply_network_policy(self, policy):
        if policy.network_mode != NetworkMode.NO_NETWORK:
            raise ValueError('This local adapter only supports network_mode=no-network')
