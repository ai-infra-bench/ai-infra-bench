"""Run the frozen verifier repair controls through Harbor without model calls."""
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

from harbor.job import Job
from harbor.models.job.config import JobConfig


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('--docker-config', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / 'task'
    sys.path.insert(0, str(root / 'infra'))
    if args.docker_config:
        os.environ['DOCKER_CONFIG'] = str(args.docker_config.resolve())
    controls = {case['name']: case for case in json.loads(
        (source / 'validation/ci-cases.json').read_text())['cases']}
    selected = ['oracle', 'alternate-scheduler-budget-field', 'alternate-cache-capacity-fields',
                'alternate-python-payload', 'alternate-numpy-payload',
                'alternate-python-mask-metadata', 'alternate-reusable-payload-pool',
                'python-list-payload-leak', 'python-list-span-growth',
                'python-list-eviction-leak', 'numpy-payload-eviction-leak',
                'early-system-exit', 'early-os-exit', 'dynamic-report-forgery',
                'alternate-existing-tracemalloc', 'traced-python-eviction-leak']
    tasks = []
    for name in selected:
        task = root / 'harbor-tasks' / name
        shutil.copytree(source, task, ignore=shutil.ignore_patterns('__pycache__'))
        if name != 'oracle':
            control = controls[name]
            shutil.copy2(source / 'validation' / control['patch'], task / 'solution/control.patch')
            script = '#!/usr/bin/env bash\nset -euo pipefail\ncd /workspace/vllm\n'
            if control.get('apply_after', 'base') == 'oracle':
                script += 'git apply /solution/oracle.patch\n'
            script += 'git apply /solution/control.patch\n'
            (task / 'solution/solve.sh').write_text(script)
        tasks.append({'path': str(task)})
    config = dict(job_name='f1-f2-f4', jobs_dir=str(root / 'harbor-jobs'),
                  n_concurrent_trials=2, quiet=True,
                  environment={'import_path': 'offline_harbor:OfflineDockerEnvironment'},
                  agents=[{'name': 'oracle'}], tasks=tasks, retry={'max_retries': 0})
    (root / 'harbor-config.json').write_text(json.dumps(config, indent=2) + '\n')
    identities = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                  for directory in (root / 'harbor-tasks', root / 'infra')
                  for path in directory.rglob('*') if path.is_file() and '__pycache__' not in path.parts}
    (root / 'harbor-input-hashes.json').write_text(json.dumps(identities, indent=2) + '\n')
    result = await (await Job.create(JobConfig.model_validate(config))).run()
    (root / 'harbor-result.json').write_text(result.model_dump_json(indent=2) + '\n')
    print(result.model_dump_json(indent=2))


if __name__ == '__main__':
    asyncio.run(main())
