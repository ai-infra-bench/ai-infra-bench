from pathlib import Path
import subprocess,sys
R=Path(__file__).parent
for case in ['base','oracle','alternate-dense-cache','alternate-distinct-profile-accessors','scheduler-capacity-from-context','runner-capacity-from-context']:
 subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr8',case,'final'],check=True)
subprocess.run([sys.executable,str(R/'run_one.py'),'pr8','oracle','frozen-final'],check=True)
print('PR8_COMPLETE',flush=True)
