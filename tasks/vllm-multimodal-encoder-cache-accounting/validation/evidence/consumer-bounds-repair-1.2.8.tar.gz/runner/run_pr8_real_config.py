from pathlib import Path
import subprocess,sys,json,concurrent.futures
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);order=['oracle','alternate-distinct-profile-accessors','base']+[c['name'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases'] if c['name']!='alternate-distinct-profile-accessors']
def lane(i):
 for case in order[i::2]:subprocess.run([sys.executable,str(R/'run_one.py'),'pr8',case,'real-config'],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(lane,i) for i in range(2)]):f.result()
print('MATRIX_COMPLETE',flush=True)
cases=['base','oracle','alternate-dense-cache','alternate-direct-mask-count','alternate-request-initialized-count','alternate-distinct-profile-accessors','scheduler-capacity-from-context','runner-capacity-from-context']
def challenge(i):
 for case in cases[i::2]:subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr8',case,'real-config'],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(challenge,i) for i in range(2)]):f.result()
subprocess.run([sys.executable,str(R/'run_one.py'),'pr8','oracle','frozen-final-real-config'],check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr8'],check=True)
subprocess.run([sys.executable,str(R/'check_portable.py'),'pr8'],check=True)
print('PR8_COMPLETE',flush=True)
