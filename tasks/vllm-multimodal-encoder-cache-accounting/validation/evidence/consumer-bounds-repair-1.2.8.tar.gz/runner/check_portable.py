from pathlib import Path
import sys,json,tarfile,hashlib
R=Path(__file__).parent;key=sys.argv[1];T=Path(json.loads((R/'targets.json').read_text())[key]['task']);d=json.loads((T/'validation/e2e-evidence.json').read_text());assert d['status']=='validated'
a=d['portable_raw_evidence'];p=T/a['archive'];assert hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'];count=0
with tarfile.open(p) as tar:
 for run in d['harbor']['runs']:
  for name,h in run['raw_artifacts'].items():
   entry=str(Path(name).relative_to(R));f=tar.extractfile(entry);assert f and hashlib.sha256(f.read()).hexdigest()==h,(entry,'hash mismatch');count+=1
 for run in d['independent_challenges']['runs']:
  for check in run['checks']:
   entry=str(Path(check['log']).relative_to(R));assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==check['sha256'];count+=1
record=dict(archive=str(p),sha256=a['sha256'],verified_raw_entries=count)
(R/(key+'-portable-check.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
