from pathlib import Path
import sys,json,torch,hashlib
sys.path.insert(0,'/tests')
from quant_ranges import cases,observe,compare,frozen_observations
assert hashlib.sha256(Path('/native/_C.abi3.so').read_bytes()).hexdigest()==sys.argv[1]
inputs=cases();expected=frozen_observations(inputs,'/tests/frozen-reference')
torch.ops.load_library('/native/_C.abi3.so')
def quantize(x,g,eps,lower,upper):
 q=torch.empty_like(x,dtype=torch.int8);s=torch.empty(x.shape[:-1]+(x.shape[-1]//g,),device=x.device,dtype=torch.float32)
 torch.ops._C.per_token_group_quant_int8(x,q,s,g,eps,float(lower),float(upper));return q,s
try:
 actual=observe(inputs,quantize);errors=compare(actual,expected);print(json.dumps(dict(cases=len(inputs),errors=errors)));assert not errors
 print('RANGE_PILOT_PASS')
except Exception as exc:
 print('RANGE_PILOT_REJECT',str(exc));raise
