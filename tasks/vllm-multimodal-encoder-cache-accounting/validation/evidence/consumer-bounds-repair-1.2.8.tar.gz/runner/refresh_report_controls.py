from pathlib import Path
import json,hashlib,ast
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task'])
p=next((R/'runs/pr8/frozen-final/oracle').glob('jobs/*/*/verifier/verification.json'))
s=p.read_text();data=json.JSONDecoder().raw_decode(s[s.index('{'):])[0];assert data['verdict']=='PASS'
saved=R/'superseded-report-controls';saved.mkdir(exist_ok=True)
for name in ['forged-completion','stale-observations']:
 patch=T/'validation'/(name+'.patch');(saved/patch.name).write_bytes(patch.read_bytes())
 payload=dict(failures={},stages=data['stages'])
 if name=='stale-observations':payload['observations']=data['observations']
 content=('---WORKER-PAYLOAD-BEGIN---\n'+json.dumps(payload)+'\n---WORKER-PAYLOAD-END---\n').encode()
 lines=patch.read_text().splitlines(keepends=True)
 lines=["+    _os.write(1, "+repr(content)+")\n" if line.startswith('+    _os.write(1, ') else line for line in lines]
 patch.write_text(''.join(lines))
 assert ast.literal_eval(next(line for line in lines if line.startswith('+    _os.write(1, '))[len('+    _os.write(1, '):-2])==content
freeze=json.loads((R/'pr8-freeze.json').read_text());(R/'pr8-freeze-before-control-refresh.json').write_text(json.dumps(freeze,indent=2)+'\n')
for name in ['forged-completion','stale-observations']:
 rel='validation/'+name+'.patch';freeze[rel]=hashlib.sha256((T/rel).read_bytes()).hexdigest()
(R/'pr8-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
(R/'superseded-controls.json').write_text(json.dumps([dict(run_root=str(R/'runs/pr8/matrix'/name),reason='Previous report format; superseded by same completion/report control in current observation format') for name in ['forged-completion','stale-observations']],indent=2)+'\n')
