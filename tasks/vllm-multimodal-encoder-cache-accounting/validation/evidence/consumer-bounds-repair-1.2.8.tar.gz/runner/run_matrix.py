from pathlib import Path
import json,subprocess,sys,os,concurrent.futures,datetime
R=Path(__file__).parent;targets=json.loads((R/'targets.json').read_text())
gpus=['GPU-3815a178-ad22-4b81-5669-0533760a7e6b','GPU-80425545-47ae-bd24-9051-ba17a38ce9f8','GPU-8380fa1c-d192-a7e4-ec39-ab836d0f4fd8','GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329','GPU-46c9b5d9-82f9-7bca-374e-6441ff3361c6','GPU-9a15bd7a-66f2-027a-13bd-8ffa6f96f710']
def lane(key,index):
 t=Path(targets[key]['task']);cases=['base','oracle']+[c['name'] for c in json.loads((t/'validation/ci-cases.json').read_text())['cases']];workers=2 if key=='pr8' else len(gpus)
 for case in cases[index::workers]:
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'START',key,index,case,flush=True)
  env=os.environ.copy()
  if key=='pr17':env['TASK_GPU']=gpus[index]
  subprocess.run([sys.executable,str(R/'run_one.py'),key,case,'matrix'],env=env,check=True)
 print('LANE_COMPLETE',key,index,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 jobs=[pool.submit(lane,'pr8',i) for i in range(2)]+[pool.submit(lane,'pr17',i) for i in range(len(gpus))]
 for f in concurrent.futures.as_completed(jobs):f.result()
print('MATRIX_COMPLETE',flush=True)
