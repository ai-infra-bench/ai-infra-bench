from pathlib import Path
import json,subprocess,sys,os,concurrent.futures,datetime
R=Path(__file__).parent;v=json.loads((R/'targets.json').read_text())['pr17'];T=Path(v['task']);gpus=['GPU-3815a178-ad22-4b81-5669-0533760a7e6b','GPU-80425545-47ae-bd24-9051-ba17a38ce9f8','GPU-8380fa1c-d192-a7e4-ec39-ab836d0f4fd8','GPU-46c9b5d9-82f9-7bca-374e-6441ff3361c6','GPU-9a15bd7a-66f2-027a-13bd-8ffa6f96f710']
excluded=[]
for p in (R/'runs/pr17/matrix').glob('*/run-record.json'):
 d=json.loads(p.read_text())
 if d['status']!='execution_or_preflight_failed':continue
 assert d['observed_trials'][0]['verifier_result'] is None and 'fully subnetted' in d['observed_trials'][0]['exception_info']['exception_message'];excluded.append(dict(run=str(p.parent),reason='Docker address pool exhausted before agent/verifier execution',trial=d['observed_trials'][0]))
(R/'excluded-startup-runs.json').write_text(json.dumps(excluded,indent=2)+'\n')
cases=['base','oracle']+[c['name'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']]
cases=[case for case in cases if case not in ('wrong-public-operator-name','renamed-private-triton-helper')]
def lane(i):
 for case in cases[i::len(gpus)]:
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'START',i,case,flush=True)
  subprocess.run([sys.executable,str(R/'run_one.py'),'pr17',case,'matrix-retry'],env=dict(os.environ,TASK_GPU=gpus[i]),check=True)
 print('LANE_COMPLETE',i,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=len(gpus)) as pool:
 for f in concurrent.futures.as_completed([pool.submit(lane,i) for i in range(len(gpus))]):f.result()
print('PR17_MATRIX_COMPLETE',flush=True)
