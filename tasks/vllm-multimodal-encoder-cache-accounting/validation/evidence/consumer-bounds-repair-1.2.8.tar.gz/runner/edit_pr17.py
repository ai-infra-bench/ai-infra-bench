from pathlib import Path
import json
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
p=T/'tests/verify_int8_quant.py';s=p.read_text()
s=s.replace('observe(boundary_inputs, lambda x, g, eps: cuda_quant(x, g, eps, -128., 127.))', 'observe(boundary_inputs["precision"], lambda x, g, eps: cuda_quant(x, g, eps, -128., 127.))').replace('observe(boundary_inputs, per_token_group_quant_int8)','observe(boundary_inputs["precision"], per_token_group_quant_int8)')
n='''        # Stage 5: Performance vs frozen baseline (run by parent)''';assert n in s;s=s.replace(n,'''        from quant_ranges import observe as observe_ranges
        result["stages"]["configured_ranges"] = observe_ranges(boundary_inputs["ranges"], cuda_quant)

'''+n)
n='    "precision_boundaries",';assert s.count(n)==1;s=s.replace(n,n+'\n    "configured_ranges",')
s=s.replace('compare(observations.get(path), boundary_expected)', 'compare(observations.get(path), boundary_expected["precision"])')
n='''            return worker_output
        except (ValueError, TypeError, AttributeError) as exc:''';assert n in s;s=s.replace(n,'''            from quant_ranges import compare as compare_ranges
            range_errors = compare_ranges(stages.get("configured_ranges"), boundary_expected["ranges"])
            if range_errors:
                return {"verdict": "FAIL", "reason": "configured_range_mismatch", "errors": range_errors}
            return worker_output
        except (ValueError, TypeError, AttributeError) as exc:''')
n='''    boundary_inputs = cases()
    boundary_expected = frozen_observations(boundary_inputs, FROZEN_DIR)''';assert n in s;s=s.replace(n,'''    from quant_ranges import cases as range_cases, frozen_observations as frozen_ranges
    boundary_inputs = {"precision": cases(), "ranges": range_cases()}
    boundary_expected = {
        "precision": frozen_observations(boundary_inputs["precision"], FROZEN_DIR),
        "ranges": frozen_ranges(boundary_inputs["ranges"], FROZEN_DIR),
    }''');p.write_text(s)
p=T/'task.toml';s=p.read_text();assert 'version = "1.2.4"' in s;p.write_text(s.replace('version = "1.2.4"','version = "1.2.5"'))
# Extend the independently written challenge with different ranges and geometry.
p=T/'validation/challenge/challenge_int8_quant.py';s=p.read_text();n='''    checked = 0
    for x, group_size, eps, lower, upper in cases:''';assert s.count(n)==1;s=s.replace(n,'''    for dtype in (torch.float16, torch.bfloat16, torch.float32):
        for lower, upper in [(0, 11), (5, 29), (11, 93)]:
            x = torch.tensor([-5., -2., -.5, 0., .75, 3.], device="cuda", dtype=dtype)
            cases.append((x.repeat(64).reshape(2, 192), 96, 2e-5, lower, upper))
    checked = 0
    for x, group_size, eps, lower, upper in cases:''');p.write_text(s)
