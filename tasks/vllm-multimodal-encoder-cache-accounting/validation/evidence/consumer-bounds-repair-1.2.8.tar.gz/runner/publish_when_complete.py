from pathlib import Path
import subprocess,sys,time,concurrent.futures
R=Path(__file__).parent
def finish(key):
 while True:
  log=R/(key+'-final.log')
  if log.exists() and key.upper()+'_COMPLETE' in log.read_text():break
  time.sleep(15)
 with (R/(key+'-finalize.log')).open('w') as log:
  subprocess.run([sys.executable,str(R/'finalize.py'),key],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('FINALIZED',key,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(finish,k) for k in ('pr8','pr17')]):f.result()
