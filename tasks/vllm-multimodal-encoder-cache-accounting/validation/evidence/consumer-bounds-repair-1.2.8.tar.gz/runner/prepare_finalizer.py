from pathlib import Path
R=Path(__file__).parent
s=Path('/data/yinchen/pr8-pr17-review-repair-20260911T154533Z/finalize.py').read_text()
s=s.replace('/data/yinchen/remaining-four-dual-review-20260911T150540Z/skill-repo','/data/yinchen/streaming-modular-task-review-20260912T051251Z/skill-repo')
a=s.index("excluded=json.loads("); b=s.index('rows=[]',a)
s=s[:a]+'''excluded=json.loads((R/'excluded-startup-runs.json').read_text()) if key=='pr17' else []
for item in excluded:item['run_root']=item['run']
excluded_roots={x['run_root'] for x in excluded}
'''+s[b:]
s=s.replace("glob(('v127-format*/*/run-record.json' if key=='pr8' else 'v124-*/*/run-record.json'))", "glob('*/*/run-record.json')")
s=s.replace(" if case=='oracle' or", " if case=='oracle' or")
a=s.index("final=next((r for r in rows");b=s.index("assert final['actual_reward']",a)
s=s[:a]+"final=next(r for r in rows if r['case']=='oracle' and Path(r['run_root']).parent.name=='frozen-final')\n"+s[b:]
s=s.replace("glob(('v127-format*/*/record.json' if key=='pr8' else 'v124-*/*/record.json'))", "glob('final/*/record.json')")
s=s.replace(" if str(p.parent) in superseded['challenges']:continue\n",'')
a=s.index(" assert digest(p.parent/'challenge.log')");b=s.index(" d['record_path']",a)
s=s[:a]+''' for check in d['checks']:
  assert digest(Path(check['log']))==check['sha256']
  assert 'ModuleNotFoundError' not in Path(check['log']).read_text()
'''+s[b:]
a=s.index("needed={'oracle'");b=s.index("assert needed<=",a)
s=s[:a]+'''needed={'base','oracle','alternate-dense-cache','alternate-direct-mask-count','alternate-request-initialized-count','alternate-distinct-profile-accessors','scheduler-capacity-from-context','runner-capacity-from-context'} if key=='pr8' else {'base','oracle','alternate-native-kernel','compatible-operator-alias','renamed-private-triton-helper','reciprocal-overflow','empty-batch-launch','range-must-include-zero','positive-lower-bound-rejected'}
'''+s[b:]
s=s.replace("('validation/history/1.2.6-before-lookahead-repair.json' if key=='pr8' else 'validation/history/1.2.3-before-empty-batch-repair.json')", "('validation/history/1.2.7-before-consumer-profile-repair.json' if key=='pr8' else 'validation/history/1.2.4-before-range-coverage-repair.json')")
s=s.replace(',superseded_format_runs=superseded','')
s=s.replace("'No new Opus rollout was run. Historical scores and reports are unchanged.'", "'No new model rollout was run. Saved Astra final tracked and untracked source was replayed as a normal control, with a normal verifier native rebuild for PR17; this is not a replay of the entire original root filesystem. Historical scores and reports are unchanged.'")
s=s.replace("('dual-review-repair-'+version+'.tar.gz')", "('consumer-bounds-repair-'+version+'.tar.gz')")
a=s.index(" tar.add(R/'execution-invariance.json'");b=s.index("evidence['portable_raw_evidence']",a)
s=s[:a]+''' tar.add(R/'performance-invariance.json',arcname='performance-invariance.json')
 tar.add(R/'skill-provenance.json',arcname='skill-provenance.json')
 tar.add(R/(key+'-freeze.json'),arcname=key+'-freeze.json')
'''+s[b:]
a=s.index("fix=(");b=s.index("text=f'''",a)
s=s[:a]+'''fix=('Capacity planning now executes the real scheduler compute_encoder_budget and runner MultiModalBudget consumers, controlling only media production and processor-cache creation. The registry default coordinate system is no longer a scoring requirement. The saved Astra source with distinct prompt/embedding accessors passes, while independent scheduler-only and runner-only regressions are rejected. All existing cache, write/read, empty-window, speculative lookahead and parent observation checks remain.' if key=='pr8' else 'Eighteen configured-range observations across FP16/BF16/FP32 now compare the real native operator against the executable frozen Triton kernel. Independent challenge inputs use different positive bounds and geometry. Both the saved Astra source and an isolated added nonpositive-lower-bound restriction are rejected. The Python convenience wrapper does not acquire a new bounds-keyword obligation; existing precision, empty-input, native dispatch, fallback and performance checks remain. The Oracle, corrected native alternative, frozen reference and all timing functions are unchanged.')
'''+s[b:]
s=s.replace("No model rollout, commit, push or PR update was performed in this repair.", "No new model rollout, commit, push or PR update was performed in this repair. Saved Astra source is a preserved implementation control, not a fresh model run.")
s=s.replace("(T/'validation/final-review.md').write_text(text);", "(T/'validation/final-review.md').write_text(text);(T/'validation/review-report.md').write_text(text);")
# Validate all code is syntactically well-formed before later execution.
compile(s,'finalize.py','exec');(R/'finalize.py').write_text(s)
