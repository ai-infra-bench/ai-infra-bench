from pathlib import Path
import json,subprocess,datetime
R=Path(__file__).parent
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
for key in ('pr8','pr17'):
 done=[];errors=[]
 for p in (R/'runs'/key).glob('*/*/run-record.json'):
  d=json.loads(p.read_text())
  if d['status']=='completed_result_checked':done.append((d['case'],d['observed_trials'][0]['verifier_result']['rewards']['reward']))
  elif d['status']=='execution_or_preflight_failed':errors.append(d['case'])
 print(key,'completed',len(done),'startup_errors',len(errors),done)
 for name in (key+'-final.log',key+'-finalize.log'):
  p=R/name
  if p.exists():print(name,p.read_text()[-900:])
for n in subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines():
 if n.startswith('vllm-int8') and n.endswith('__env-main-1'):
  p=subprocess.run(['docker','exec',n,'tail','-1','/logs/verifier/native-build.stdout.log'],capture_output=True,text=True)
  print(n,p.stdout[-160:].strip())
