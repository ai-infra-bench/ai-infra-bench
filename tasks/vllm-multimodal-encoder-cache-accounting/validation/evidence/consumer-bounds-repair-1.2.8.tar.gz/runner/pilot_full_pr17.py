from pathlib import Path
import json,subprocess,hashlib,fcntl
R=Path(__file__).parent;v=json.loads((R/'targets.json').read_text())['pr17'];T=Path(v['task']);out=R/'full-parent-pilot';out.mkdir(exist_ok=True);gpu='GPU-80425545-47ae-bd24-9051-ba17a38ce9f8'
with open('/data/yinchen/vllm-pr8-controls/.phaseD-gpu-locks/'+gpu+'.lock','a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for case,patch in [('oracle','solution/oracle.patch'),('alternate-native-kernel','validation/alternate-native-kernel.patch')]:
  native=R/'runs/pr17/matrix-retry'/case/'native';manifest=json.loads((native/'manifest.json').read_text());assert hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()==manifest['sha256']
  cmd=['docker','run','-d','--network','none','--gpus','device='+gpu,'--user','root','--cpus','8','--memory','32768m','--workdir','/workspace/repo','-e','TRITON_CACHE_DIR=/tmp/triton-cache-nobody','--mount',f'type=bind,src={T},dst=/task,readonly','--mount',f'type=bind,src={T}/tests,dst=/tests,readonly','--mount',f'type=bind,src={native},dst=/native,readonly','--entrypoint','sleep',v['image'],'infinity']
  cid=subprocess.check_output(cmd,text=True).strip()
  try:
   subprocess.run(['docker','exec','--user','agent',cid,'git','apply','/task/'+patch],check=True,capture_output=True)
   subprocess.run(['docker','exec',cid,'bash','-c','mkdir -p /logs/verifier /opt/ai-infra-bench/reference-int8 /tmp/triton-cache-nobody && chmod 1777 /tmp/triton-cache-nobody && cp /tests/frozen-reference/*.py /opt/ai-infra-bench/reference-int8/ && chmod 444 /opt/ai-infra-bench/reference-int8/*.py && cp /native/_C.abi3.so /workspace/repo/vllm/_C.abi3.so'],check=True,capture_output=True)
   with (out/(case+'.log')).open('w') as f:proc=subprocess.run(['docker','exec',cid,'python3','-I','/tests/verify_int8_quant.py'],stdout=f,stderr=subprocess.STDOUT,timeout=600)
   reward=subprocess.check_output(['docker','exec',cid,'cat','/logs/verifier/reward.txt'],text=True).strip()
   record=dict(case=case,scope='Full parent/worker and performance verifier in fresh pinned container using previously rebuilt identical-source native; excludes Harbor/native rebuild and is diagnostic only',command=cmd,exit=proc.returncode,reward=reward,native=manifest,patch_sha256=hashlib.sha256((T/patch).read_bytes()).hexdigest())
   (out/(case+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(case,reward,proc.returncode,flush=True);assert reward=='1' and proc.returncode==0
  finally:subprocess.run(['docker','rm','-f',cid],capture_output=True)
print('FULL_PARENT_PILOT_PASS',flush=True)
