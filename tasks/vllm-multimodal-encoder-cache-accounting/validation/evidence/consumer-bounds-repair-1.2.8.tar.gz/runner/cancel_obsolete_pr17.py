from pathlib import Path
import subprocess,os,signal,json,datetime
R=Path(__file__).parent
processes=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  argv=(p/'cmdline').read_bytes().split(b'\0');args=[a.decode() for a in argv if a];ppid=int(next(x.split()[1] for x in (p/'status').read_text().splitlines() if x.startswith('PPid:')))
 except (OSError,UnicodeError,StopIteration):continue
 processes.append(dict(pid=int(p.name),ppid=ppid,args=args))
names={'run_matrix.py','run_pr17_retry.py','finish_pr17.py','publish_when_complete.py'}
roots={p['pid'] for p in processes if len(p['args'])>1 and p['args'][1] in {str(R/n) for n in names}}
victims=set(roots)
while True:
 children={p['pid'] for p in processes if p['ppid'] in victims}
 if children<=victims:break
 victims|=children
runs=[];containers=[]
for p in (R/'runs/pr17').glob('*/*/run-record.json'):
 d=json.loads(p.read_text());runs.append(dict(run_root=str(p.parent),case=d.get('case'),status=d.get('status'),reason='Superseded verifier integration: configured_ranges list rejected by preexisting dict-shaped stage completion check'))
for p in (R/'runs/pr17').glob('*/*/jobs/*/*/trial.log'):
 containers.extend([p.parent.name.lower()+'__env-main-1',p.parent.name.lower()+'__env-harbor-docker-egress-control-sidecar-1'])
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),processes=[p for p in processes if p['pid'] in victims],containers=containers,runs=runs)
(R/'obsolete-pr17-cancellation.json').write_text(json.dumps(record,indent=2)+'\n')
for pid in roots:
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
for pid in victims-roots:
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
active=set(subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines())
for name in containers:
 if name in active:subprocess.run(['docker','rm','-f',name],check=True,capture_output=True)
print('cancelled obsolete orchestrators',len(roots),'descendants',len(victims),'own container candidates',len(containers),flush=True)
