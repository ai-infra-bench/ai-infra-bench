from pathlib import Path
import subprocess,sys,time,json,os
R=Path(__file__).parent
expected=['base','oracle']+[c['name'] for c in json.loads((Path(json.loads((R/'targets.json').read_text())['pr17']['task'])/'validation/ci-cases.json').read_text())['cases']]
while True:
 runs={}
 for p in (R/'runs/pr17').glob('*/*/run-record.json'):
  d=json.loads(p.read_text())
  if d['status']=='completed_result_checked':runs[d['case']]=p.parent
 if set(expected)<=runs.keys():break
 time.sleep(20)
print('MATRIX_CONFIRMED',len(runs),flush=True)
gpu='GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329'
for case in ['base','oracle','alternate-native-kernel','compatible-operator-alias','renamed-private-triton-helper','reciprocal-overflow','empty-batch-launch','range-must-include-zero','positive-lower-bound-rejected']:
 subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr17',case,'final',str(runs[case]/'native')],env=dict(os.environ,CHALLENGE_GPU=gpu),check=True)
subprocess.run([sys.executable,str(R/'run_one.py'),'pr17','oracle','frozen-final'],env=dict(os.environ,TASK_GPU=gpu),check=True)
print('PR17_COMPLETE',flush=True)
