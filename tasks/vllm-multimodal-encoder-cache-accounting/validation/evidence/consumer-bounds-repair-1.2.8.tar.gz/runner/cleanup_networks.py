from pathlib import Path
import subprocess,json,datetime,sys
R=Path(__file__).parent
roots=[Path('/data/yinchen/modular-prepare-hardening-20260912T053849Z'),R]
projects={}
for root in roots:
 for p in root.rglob('run-record.json'):
  if 'prepared' in p.parts:continue
  try:rec=json.loads(p.read_text())
  except (OSError,ValueError):continue
  for trial in rec.get('observed_trials',[]):
   tr=Path(trial['path']);slug=tr.parent.name.lower()
   for suffix in ('__env','__verifier__trial'):projects[slug+suffix]=str(p)
# Also reclaim only completed, archived trials from these user-authorized campaigns.
for root in [Path('/data/yinchen/astra-pr8-pr17-20260912T051449Z'), Path('/data/yinchen/astra-streaming-modular-20260911T154735Z')]:
 for p in root.rglob('result.json'):
  if any(part in p.parts for part in ('prepared','frozen','harbor-task','source')):continue
  try:trial=json.loads(p.read_text())
  except (OSError,ValueError):continue
  if 'agent_result' not in trial or not trial.get('finished_at'):continue
  for suffix in ('__env','__verifier__trial'):projects[p.parent.name.lower()+suffix]=str(p)
ids=subprocess.check_output(['docker','network','ls','-q'],text=True).split();records=[]
if ids:
 for n in json.loads(subprocess.check_output(['docker','network','inspect',*ids],text=True)):
  project=(n.get('Labels') or {}).get('com.docker.compose.project')
  if project not in projects or n.get('Containers'):continue
  current=json.loads(subprocess.check_output(['docker','network','inspect',n['Id']],text=True))[0]
  if current.get('Containers'):continue
  result=subprocess.run(['docker','network','rm',n['Id']],capture_output=True,text=True)
  records.append(dict(id=n['Id'],name=n['Name'],project=project,source_run=projects[project],empty=True,exit_code=result.returncode,output=result.stdout+result.stderr))
out=R/('network-cleanup-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json');out.write_text(json.dumps(records,indent=2)+'\n');print('Removed owned empty networks:',sum(r['exit_code']==0 for r in records),'record',out)
