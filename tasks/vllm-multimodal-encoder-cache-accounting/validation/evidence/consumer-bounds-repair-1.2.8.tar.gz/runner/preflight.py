from pathlib import Path
import hashlib,json,subprocess,concurrent.futures
R=Path(__file__).parent;targets=json.loads((R/'targets.json').read_text())
def run(key):
 v=targets[key];t=Path(v['task']);out=R/'preflight'/key;out.mkdir(parents=True)
 code='''import json,subprocess
from pathlib import Path
t=Path('/task');cases=[dict(name='oracle',patch='solution/oracle.patch')]+json.loads((t/'validation/ci-cases.json').read_text())['cases']
for c in cases:
 subprocess.run(['git','reset','--hard','HEAD'],check=True,stdout=subprocess.DEVNULL)
 subprocess.run(['git','clean','-fd'],check=True,stdout=subprocess.DEVNULL)
 if c.get('apply_after')=='oracle':subprocess.run(['git','apply',str(t/'solution/oracle.patch')],check=True)
 patch=t/c['patch'] if c['name']=='oracle' else t/'validation'/c['patch']
 subprocess.run(['git','apply','--check',str(patch)],check=True)
 print('PATCH_OK',c['name'])
'''
 cmd=['docker','run','--rm','--network','none','--user','agent','--workdir','/app' if key=='pr8' else '/workspace/repo','--mount',f'type=bind,src={t},dst=/task,readonly','--entrypoint','python3',v['image'],'-c',code]
 commands={'patches':cmd,'image-inspect':['docker','image','inspect',v['image']],'image-history':['docker','image','history','--no-trunc','--format','{{json .}}',v['image']],'image-check':['python',str(t.parents[1]/'.github/scripts/task_ci.py'),'image-check','--task',t.name,'--image',v['image']]}
 records={}
 for name,cmd in commands.items():
  p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300);log=out/(name+'.log');log.write_text(p.stdout);records[name]=dict(command=cmd,exit_code=p.returncode,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest());assert p.returncode==0,(name,p.stdout[-3000:])
 (out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(key,'preflight passed',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,k) for k in targets]):f.result()
