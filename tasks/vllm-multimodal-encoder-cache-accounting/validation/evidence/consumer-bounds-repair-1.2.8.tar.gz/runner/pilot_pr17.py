from pathlib import Path
import json,subprocess,fcntl,hashlib
R=Path(__file__).parent;v=json.loads((R/'targets.json').read_text())['pr17'];T=Path(v['task']);out=R/'pilot-pr17';out.mkdir();gpu='GPU-3815a178-ad22-4b81-5669-0533760a7e6b'
previous=json.loads(Path('/data/yinchen/astra-pr8-pr17-20260912T051449Z/review/pr17/native-bounds/record.json').read_text())
with open('/data/yinchen/vllm-pr8-controls/.phaseD-gpu-locks/'+gpu+'.lock','a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for c in previous['cases']:
  native=Path(c['native_path']);assert hashlib.sha256(native.read_bytes()).hexdigest()==c['sha256'];name=c['name'];cmd=['docker','run','--rm','--network','none','--gpus','device='+gpu,'--cpus','4','--memory','16384m','--user','nobody','--workdir','/','-e','TRITON_CACHE_DIR=/tmp/range-pilot','--mount',f'type=bind,src={native},dst=/native/_C.abi3.so,readonly','--mount',f'type=bind,src={T}/tests,dst=/tests,readonly','--mount',f'type=bind,src={R}/range_pilot_worker.py,dst=/pilot.py,readonly','--entrypoint','python3',v['image'],'-I','/pilot.py',c['sha256']]
  p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240);(out/f'{name}.log').write_text(p.stdout);passed=p.returncode==0 and 'RANGE_PILOT_PASS' in p.stdout
  (out/f'{name}.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,passed=passed,native_sha256=c['sha256'],scope='New configured-range module only, saved native in fresh pinned container; not full Harbor'),indent=2)+'\n');print(name,passed,flush=True);assert passed==(name!='candidate'),p.stdout[-3000:]
