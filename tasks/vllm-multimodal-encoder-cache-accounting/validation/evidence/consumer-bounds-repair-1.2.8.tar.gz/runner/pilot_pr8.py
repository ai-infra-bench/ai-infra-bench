from pathlib import Path
import json,subprocess
R=Path(__file__).parent;v=json.loads((R/'targets.json').read_text())['pr8'];T=Path(v['task']);out=R/'pilot-pr8';out.mkdir()
for case,patches in [('oracle',['solution/oracle.patch']),('alternate-distinct-profile-accessors',['validation/alternate-distinct-profile-accessors.patch'])]:
 logdir=out/case;logdir.mkdir()
 script='\n'.join('runuser -u agent -- git apply /task/'+p for p in patches)+'\nbash /tests/test.sh\n'
 cmd=['docker','run','--rm','--network','none','--user','root','--workdir','/app','--mount',f'type=bind,src={T},dst=/task,readonly','--mount',f'type=bind,src={T}/tests,dst=/tests,readonly','--mount',f'type=bind,src={logdir},dst=/logs/verifier','--entrypoint','bash',v['image'],'-euc',script]
 with (logdir/'docker.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 reward=(logdir/'reward.txt').read_text().strip() if (logdir/'reward.txt').exists() else None
 (logdir/'record.json').write_text(json.dumps(dict(command=cmd,exit=p.returncode,reward=reward,scope='direct Docker diagnostic; not Harbor'),indent=2)+'\n');print(case,reward,flush=True)
 assert reward=='1',str(logdir)
