from pathlib import Path
import json,hashlib,ast
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);save=R/'pr8-before-real-scheduler-config';save.mkdir(exist_ok=True)
rels=['tests/encoder_capacity_worker.py','tests/verify_encoder_cache.py','tests/encoder_contract.py','validation/challenge/challenge_encoder_capacity.py','validation/ci-cases.json','validation/forged-completion.patch','validation/stale-observations.patch']
for rel in rels:
 p=save/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((T/rel).read_bytes())
p=T/'tests/encoder_capacity_worker.py';s=p.read_text().replace('    from vllm.v1.core.encoder_cache_manager import compute_encoder_budget','    from vllm.config import SchedulerConfig\n    from vllm.v1.core.encoder_cache_manager import compute_encoder_budget');a=s.index('    config = SimpleNamespace(');b=s.index('    original_inputs',a);s=s[:a]+'''    # The real constructor derives both encoder capacity floors from the
    # decoder batch limit. A one-token batch makes row accounting observable
    # while retaining a configuration the production constructor can create.
    config = SchedulerConfig(
        max_model_len=4096, is_encoder_decoder=False,
        max_num_batched_tokens=1, max_num_seqs=1,
        enable_chunked_prefill=True, is_multimodal_model=True,
        disable_chunked_mm_input=False,
    )
'''+s[b:];p.write_text(s)
p=T/'tests/verify_encoder_cache.py';s=p.read_text().replace('{"scheduler": [n, n], "runner": n} for n in (8, 4, 9, 0, 0, 0)', '{"scheduler": [max(1, n), max(1, n)], "runner": max(1, n)}\n            for n in (8, 4, 9, 0, 0, 0)');p.write_text(s)
p=T/'tests/encoder_contract.py';s=p.read_text().replace("profile={'scheduler':[n,n], 'runner':n}", "profile={'scheduler':[max(1,n),max(1,n)], 'runner':max(1,n)}");p.write_text(s)
p=T/'validation/challenge/challenge_encoder_capacity.py';s=p.read_text().replace('from vllm.multimodal.inputs import PlaceholderRange', 'from vllm.config import SchedulerConfig\nfrom vllm.multimodal.inputs import PlaceholderRange');s=s.replace(' config=SimpleNamespace(max_num_encoder_input_tokens=0,encoder_cache_size=0,disable_chunked_mm_input=False,max_num_batched_tokens=256,max_num_seqs=4,enable_chunked_prefill=True)', ' config=SchedulerConfig(max_model_len=256,is_encoder_decoder=False,max_num_batched_tokens=2,max_num_seqs=1,enable_chunked_prefill=True,is_multimodal_model=True,disable_chunked_mm_input=False)\n expected_budget=max(2,expected)');s=s.replace("'expected_rows':expected,", "'expected_rows':expected,'expected_capacity':expected_budget,");s=s.replace("scheduler_budget==(expected,expected) and result['runner_budget']==expected", "scheduler_budget==(expected_budget,expected_budget) and result['runner_budget']==expected_budget");p.write_text(s)
for name in ['forged-completion','stale-observations']:
 p=T/'validation'/(name+'.patch');lines=p.read_text().splitlines(keepends=True);index=next(i for i,line in enumerate(lines) if line.startswith('+    _os.write(1, '));payload=ast.literal_eval(lines[index][len('+    _os.write(1, '):-2]).decode();body=json.loads(payload.split('---WORKER-PAYLOAD-BEGIN---\n',1)[1].split('\n---WORKER-PAYLOAD-END---',1)[0]);body['stages']['registry_capacity']={'cases':[dict(scheduler=[max(1,n)]*2,runner=max(1,n)) for n in (8,4,9,0,0,0)]};blob=('---WORKER-PAYLOAD-BEGIN---\n'+json.dumps(body)+'\n---WORKER-PAYLOAD-END---\n').encode();lines[index]='+    _os.write(1, '+repr(blob)+')\n';p.write_text(''.join(lines))
p=T/'validation/ci-cases.json';d=json.loads(p.read_text())
for case in d['cases']:case['patch_sha256']=hashlib.sha256((T/'validation'/case['patch']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
f=json.loads((R/'pr8-freeze.json').read_text());(R/'pr8-freeze-before-real-config.json').write_text(json.dumps(f,indent=2)+'\n')
for rel in rels:f[rel]=hashlib.sha256((T/rel).read_bytes()).hexdigest()
(R/'pr8-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
old=[]
for p in (R/'runs/pr8').glob('*/*/run-record.json'):old.append(dict(run_root=str(p.parent),reason='Superseded capacity fixture: final verification uses the real SchedulerConfig constructor and its derived capacity floor'))
(R/'superseded-pr8-config-runs.json').write_text(json.dumps(old,indent=2)+'\n')
for rel in ['tests/encoder_capacity_worker.py','tests/verify_encoder_cache.py','tests/encoder_contract.py','validation/challenge/challenge_encoder_capacity.py']:ast.parse((T/rel).read_text())
