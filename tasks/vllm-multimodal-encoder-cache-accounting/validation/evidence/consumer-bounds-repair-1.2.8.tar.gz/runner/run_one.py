from pathlib import Path
import json,subprocess,sys,time,hashlib,os
R=Path(__file__).parent;key,case,tag=sys.argv[1:4];v=json.loads((R/'targets.json').read_text())[key];T=Path(v['task']);out=R/'runs'/key/tag/case
for rel,h in json.loads((R/f'{key}-freeze.json').read_text()).items():assert hashlib.sha256((T/rel).read_bytes()).hexdigest()==h,rel
# One durable execution per frozen task/case/output, including concurrent resume.
import fcntl
locks=R/'case-output-locks';locks.mkdir(exist_ok=True)
case_lock=open(locks/(key+'--'+tag+'--'+case+'.lock'),'a+')
fcntl.flock(case_lock,fcntl.LOCK_EX)
if (out/'run-record.json').exists():
 rec=json.loads((out/'run-record.json').read_text())
 assert rec['status']=='completed_result_checked',('existing run is not a successful completed execution',out)
 expected=0 if case=='base' else 1 if case=='oracle' else next(c['expected_reward'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases'] if c['name']==case)
 assert rec['case']==case and rec['expected_reward']==expected
 assert rec['observed_trials'][0]['verifier_result']['rewards']['reward']==expected
 assert rec['image_id_observed']==v['image']
 assert all(rec['executable_files'].get(rel)==h for rel,h in json.loads((R/f'{key}-freeze.json').read_text()).items())
 if key=='pr17':
  native=json.loads((out/'native/manifest.json').read_text())
  assert native['case']==case and native['image']==v['image'] and native['source_run']==str(out)
  assert hashlib.sha256((out/'native/_C.abi3.so').read_bytes()).hexdigest()==native['sha256']
 print('REUSE_VERIFIED_HARBOR',key,case,expected,str(out),flush=True)
 raise SystemExit(0)
cmd=[sys.executable,'/data/yinchen/task-hardening-20260908/run_case.py','--task',str(T),'--case',case,'--output',str(out)]
if key=='pr17':cmd+=['--gpu-uuid',os.environ['TASK_GPU']]
log=R/'drivers'/key/tag;log.mkdir(parents=True,exist_ok=True)
with (log/(case+'.log')).open('w') as stream:
 p=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT)
 captured=False;marker_captured=False
 while p.poll() is None:
  if key=='pr17':
   trials=list(out.glob('jobs/*/*/trial.log'))
   if trials:
    container=trials[0].parent.name.lower()+'__env-main-1'
    if not captured:
     check=subprocess.run(['docker','exec',container,'cat','/logs/verifier/native-build.stdout.log'],capture_output=True,text=True)
     if 'native_build_completed' in check.stdout:
      native=out/'native';native.mkdir(exist_ok=True)
      cp=subprocess.run(['docker','cp',container+':/workspace/repo/vllm/_C.abi3.so',str(native/'_C.abi3.so')],capture_output=True)
      if cp.returncode==0:
       (native/'manifest.json').write_text(json.dumps(dict(case=case,image=v['image'],source_run=str(out),sha256=hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()),indent=2)+'\n');captured=True
    if case=='early-native-timing-exit' and not marker_captured:
     check=subprocess.run(['docker','exec',container,'cat','/tmp/int8-native-timing-control.txt'],capture_output=True,text=True)
     if check.returncode==0 and 'CONTROL_REACHED:early-native-timing-exit' in check.stdout:
      (out/'curator-native-timing-control.txt').write_text(check.stdout);marker_captured=True
  time.sleep(.25 if captured and case=='early-native-timing-exit' else 1)
if p.returncode:raise RuntimeError(f'{key}/{case} runner failed: '+str(log/(case+'.log')))
rec=json.loads((out/'run-record.json').read_text());assert rec['status']=='completed_result_checked'
reward=rec['observed_trials'][0]['verifier_result']['rewards']['reward'];print(key,case,reward,'expected',rec['expected_reward'],flush=True);assert reward==rec['expected_reward']
if key=='pr17':assert captured,(key,case,'native not captured')
if case=='early-native-timing-exit':assert marker_captured
