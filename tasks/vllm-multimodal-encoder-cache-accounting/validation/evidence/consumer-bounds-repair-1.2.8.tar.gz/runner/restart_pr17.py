from pathlib import Path
import subprocess,sys,time,json,os,concurrent.futures,datetime
R=Path(__file__).parent
while 'FULL_PARENT_PILOT_PASS' not in (R/'full-parent-pilot.log').read_text():
 if 'Traceback' in (R/'full-parent-pilot.log').read_text():raise RuntimeError('pilot failed')
 time.sleep(10)
cases=['oracle','alternate-native-kernel','positive-lower-bound-rejected','range-must-include-zero','compatible-operator-alias','renamed-private-triton-helper','base','wrong-public-operator-name','slow-candidate-occupancy','early-system-exit','early-os-exit','early-native-timing-exit','reciprocal-overflow','empty-batch-launch']
gpus=['GPU-4d1fbe26-f8a4-5869-e826-3143f1425f75','GPU-80425545-47ae-bd24-9051-ba17a38ce9f8','GPU-3815a178-ad22-4b81-5669-0533760a7e6b','GPU-8380fa1c-d192-a7e4-ec39-ab836d0f4fd8','GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329','GPU-9a15bd7a-66f2-027a-13bd-8ffa6f96f710']
def lane(i):
 for case in cases[i::len(gpus)]:
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'START',i,case,flush=True)
  subprocess.run([sys.executable,str(R/'run_one.py'),'pr17',case,'shape-fixed'],env=dict(os.environ,TASK_GPU=gpus[i]),check=True)
 print('LANE_COMPLETE',i,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=len(gpus)) as pool:
 for f in concurrent.futures.as_completed([pool.submit(lane,i) for i in range(len(gpus))]):f.result()
print('PR17_MATRIX_COMPLETE',flush=True)
for case in ['base','oracle','alternate-native-kernel','compatible-operator-alias','renamed-private-triton-helper','reciprocal-overflow','empty-batch-launch','range-must-include-zero','positive-lower-bound-rejected']:
 subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr17',case,'final',str(R/'runs/pr17/shape-fixed'/case/'native')],env=dict(os.environ,CHALLENGE_GPU=gpus[0]),check=True)
subprocess.run([sys.executable,str(R/'run_one.py'),'pr17','oracle','frozen-final'],env=dict(os.environ,TASK_GPU=gpus[0]),check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr17'],check=True)
print('PR17_COMPLETE',flush=True)
