from pathlib import Path
import json,hashlib,subprocess,difflib,shlex
R=Path(__file__).parent;targets=json.loads((R/'targets.json').read_text());campaign=Path('/data/yinchen/astra-pr8-pr17-20260912T051449Z')
def save_case(key,name,patch,expected,note,after='base'):
 t=Path(targets[key]['task']);p=t/'validation'/f'{name}.patch';p.write_bytes(patch)
 f=t/'validation/ci-cases.json';d=json.loads(f.read_text());assert not any(c['name']==name for c in d['cases'])
 d['cases'].append(dict(name=name,patch=p.name,apply_after=after,expected_reward=expected,patch_sha256=hashlib.sha256(patch).hexdigest(),note=note));f.write_text(json.dumps(d,indent=2)+'\n')
for key,name,expected in [('pr8','alternate-distinct-profile-accessors',1),('pr17','positive-lower-bound-rejected',0)]:
 state=next((campaign/key/'jobs').glob('*/*/final-state'));source=campaign/'review'/key/'source'/('app' if key=='pr8' else 'workspace/repo')
 patch=(state/'git-diff.patch').read_text()
 for rel in (state/'git-untracked.txt').read_text().splitlines():
  p=source/rel;assert p.is_file() and p.suffix in ('.py','.cu')
  patch+=f'diff --git a/{rel} b/{rel}\nnew file mode 100644\n'+''.join(difflib.unified_diff([],p.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+rel))
 save_case(key,name,patch.encode(),expected,'Saved Astra final tracked and untracked source files, unchanged; standard verifier build applies. Historical rollout and binary remain separate.')
controls=[('pr8','scheduler-capacity-from-context',"vllm/v1/core/encoder_cache_manager.py",'''s=p.read_text();start=s.index('def compute_encoder_budget(');end=s.index('def compute_text_encoder_budget(',start);part=s[start:end];needle='        return compute_mm_encoder_budget(';assert part.count(needle)==1;part=part.replace(needle,'        max_tokens_by_modality = {key: model_config.max_model_len for key in max_tokens_by_modality}\\n'+needle);p.write_text(s[:start]+part+s[end:])''','Correct registry and cache accounting, but scheduler capacity wrongly uses decoder context length.'),('pr8','runner-capacity-from-context','vllm/v1/worker/utils.py', '''s=p.read_text();start=s.index('    def get_encoder_budget(');end=s.index('    def get_max_items(',start);part=s[start:end];needle='return min(self.encoder_compute_budget, self.encoder_cache_size)';assert part.count(needle)==1;part=part.replace(needle,'return self.max_model_len');p.write_text(s[:start]+part+s[end:])''','Correct scheduler and registry, but runner capacity wrongly uses decoder context length.'),('pr17','range-must-include-zero','csrc/quantization/compressed_tensors/int8_quant_kernels.cu', '''s=p.read_text();needle='double eps, double int8_min, double int8_max) {';assert s.count(needle)==1;p.write_text(s.replace(needle,needle+'\\n  TORCH_CHECK(int8_min <= 0, "range must include zero");'))''','Otherwise correct Oracle rejects valid positive lower bounds; isolates the newly covered input restriction.')]
for key,name,file,edit,note in controls:
 t=Path(targets[key]['task']);code='from pathlib import Path\np=Path('+repr(file)+')\n'+edit
 script='git apply /task/solution/oracle.patch\ngit add -A\npython3 -c '+shlex.quote(code)+'\ngit diff --binary\n'
 cmd=['docker','run','--rm','--network','none','--user','agent','--workdir','/app' if key=='pr8' else '/workspace/repo','--mount',f'type=bind,src={t},dst=/task,readonly','--entrypoint','bash',targets[key]['image'],'-euc',script]
 patch=subprocess.check_output(cmd);assert patch.startswith(b'diff --git ')
 save_case(key,name,patch,0,note,'oracle')
print('controls saved')
