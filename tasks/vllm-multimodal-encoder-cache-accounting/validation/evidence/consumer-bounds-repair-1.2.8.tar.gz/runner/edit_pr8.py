from pathlib import Path
import json
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task'])
p=T/'tests/verify_encoder_cache.py';s=p.read_text();a=s.index('def check_registry_profiles_embedding_capacity():');b=s.index('\n\ndef main() -> None:',a)
s=s[:a]+'''def check_registry_profiles_embedding_capacity():
    """Observe actual encoder compute/cache capacity, not a registry default."""
    cases = [(100, [5, 15, 25, 35, 45, 55, 65, 75]),
             (41, [2, 11, 29, 38]), (9, None), (12, []), (0, []), (0, None)]
    measured = []
    for length, indices in cases:
        mask = None if indices is None else sparse_mask(length, indices)
        position = PlaceholderRange(0, length, mask)
        measured.append(observe_encoder_capacity(position))
    return {"cases": measured}
'''+s[b:]
n='    Path(__file__).with_name("encoder_fresh_worker.py").read_text() + "\\n\\ndef main() -> None:", 1)'
assert n in s;s=s.replace(n,'    Path(__file__).with_name("encoder_capacity_worker.py").read_text() + "\\n" +\n'+n)
n='''        "registry_capacity": {"profiled_prompt_tokens": 100,
                              "profiled_embedding_rows": 8},''';assert n in s;s=s.replace(n,'''        "registry_capacity": {"cases": [
            {"scheduler": [n, n], "runner": n} for n in (8, 4, 9, 0, 0, 0)]},''');p.write_text(s)
p=T/'tests/encoder_fresh_worker.py';s=p.read_text();a=s.index('    class Info:');b=s.index("    req=SparseRequest('fresh-0'",a);s=s[:a]+"    profile = observe_encoder_capacity(features[0].mm_position)\n"+s[b:];p.write_text(s)
p=T/'tests/encoder_contract.py';s=p.read_text();assert "profile={'image':n}" in s;p.write_text(s.replace("profile={'image':n}","profile={'scheduler':[n,n], 'runner':n}"))
p=T/'task.toml';s=p.read_text();assert 'version = "1.2.7"' in s;p.write_text(s.replace('version = "1.2.7"','version = "1.2.8"'))
