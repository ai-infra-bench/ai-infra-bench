from pathlib import Path
import json,hashlib
R=Path(__file__).parent;records=[]
for key,v in json.loads((R/'targets.json').read_text()).items():
 T=Path(v['task']);freeze=json.loads((R/(key+'-freeze.json')).read_text());cfg=T/'validation/ci-cases.json';cases=json.loads(cfg.read_text());changed=[]
 for name in (['alternate-distinct-profile-accessors','scheduler-capacity-from-context','runner-capacity-from-context'] if key=='pr8' else ['positive-lower-bound-rejected','range-must-include-zero']):
  p=T/'validation'/(name+'.patch');before=p.read_bytes();after=b''.join(b'\n' if line==b' \n' else line for line in before.splitlines(keepends=True))
  if before==after:continue
  save=R/'before-context-normalization'/key/p.name;save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(before);p.write_bytes(after)
  sha=hashlib.sha256(after).hexdigest();freeze[str(p.relative_to(T))]=sha
  for c in cases['cases']:
   if c['name']==name:c['patch_sha256']=sha
  changed.append(name);records.append(dict(key=key,case=name,before=str(save),after=str(p),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=sha,change='Only unified-diff empty context lines: single space to empty line; candidate source remains unchanged'))
 if changed:
  cfg.write_text(json.dumps(cases,indent=2)+'\n');freeze['validation/ci-cases.json']=hashlib.sha256(cfg.read_bytes()).hexdigest();(R/(key+'-freeze.json')).write_text(json.dumps(freeze,indent=2)+'\n')
 # Remove only generated Python bytecode from verifier source, never tracked code.
 for p in (T/'tests').rglob('__pycache__/*.pyc'):p.unlink()
 for p in (T/'tests').rglob('__pycache__'):
  if not any(p.iterdir()):p.rmdir()
(R/'context-normalization.json').write_text(json.dumps(records,indent=2)+'\n')
p=R/'superseded-controls.json';old=json.loads(p.read_text());old += [dict(run_root=str(R/'runs/pr8/matrix'/x['case']),reason='Replaced by byte-equivalent candidate source from whitespace-clean control patch') for x in records if x['key']=='pr8'];p.write_text(json.dumps(old,indent=2)+'\n')
