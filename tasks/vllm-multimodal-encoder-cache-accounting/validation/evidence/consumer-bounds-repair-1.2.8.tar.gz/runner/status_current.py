from pathlib import Path
import subprocess,json,datetime
R=Path(__file__).parent
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
for p in sorted((R/'runs/pr17').glob('shape-fixed/*')):
 record=p/'run-record.json'
 if record.exists():
  d=json.loads(record.read_text())
  if d.get('status')=='completed_result_checked':
   print(p.name,'reward',d['observed_trials'][0]['verifier_result']['rewards']['reward']);continue
  if d.get('status')=='execution_or_preflight_failed':print(p.name,'RUN_ERROR');continue
 trials=list(p.glob('jobs/*/*/trial.log'))
 if not trials:print(p.name,'preparing');continue
 name=trials[0].parent.name.lower()+'__env-main-1'
 result=subprocess.run(['docker','exec',name,'tail','-1','/logs/verifier/native-build.stdout.log'],capture_output=True,text=True)
 print(p.name,result.stdout[-150:].strip() if result.returncode==0 else 'starting/collecting')
print((R/'pr17-shape-fixed.log').read_text()[-600:])
