from pathlib import Path
import subprocess,time,sys
R=Path(__file__).parent
while not any('LANE_COMPLETE '+str(i) in (R/'pr17-shape-fixed.log').read_text() for i in [2,3,4,5]):time.sleep(10)
subprocess.run([sys.executable,str(R/'run_one.py'),'pr8','oracle','frozen-final-real-config-retry'],check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr8'],check=True)
subprocess.run([sys.executable,str(R/'check_portable.py'),'pr8'],check=True)
print('PR8_COMPLETE',flush=True)
