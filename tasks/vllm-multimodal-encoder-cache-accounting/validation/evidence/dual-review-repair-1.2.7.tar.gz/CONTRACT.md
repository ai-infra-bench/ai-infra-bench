# Frozen behavioral contracts

PR8: real multimodal Request and prompt window -> scheduler admission in embedding-row units -> real encoder write/cache -> real ordered partial gather. Cache reuse/eviction and registry profiling use the same row units. The encoder-needed interval includes existing speculative-decoding lookahead. Windows with no embeddings needed by either main or draft tokens advance even without encoder resources; nonempty cold items require their full output budget. Model inference supplies contract-valid rows; scheduling, cache and coordinate transitions run real code.

PR17: contiguous FP16/BF16/FP32 rank>=2 input -> public dispatch and candidate-built native group quantization -> quantized values and scales consistent with frozen reference; unavailable native paths retain Triton. Empty inputs preserve output shapes, dtypes and input device without a CUDA launch error or breaking subsequent device operations. Real CUDA on A100 and rebuilt candidate native are required. Five published BF16 timing workloads, 40 warmups, five repeats of 400, and per-case 1.5x threshold remain unchanged.

Statements use three prose paragraphs without hard-wrapped lines. No new model rollout or PR publication is part of this repair. Historical final-code archive gaps remain separate.
