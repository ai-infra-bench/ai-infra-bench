from pathlib import Path
import json,subprocess,os,fcntl,hashlib
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr17']['task']);image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
gpu='GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329';lock=open('/data/yinchen/vllm-pr8-controls/.phaseD-gpu-locks/'+gpu+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
code='''
import torch,json,ctypes,sys
rt=ctypes.CDLL('libcudart.so.12')
rt.cudaGetLastError.restype=ctypes.c_int;rt.cudaPeekAtLastError.restype=ctypes.c_int
if sys.argv[1]=='frozen':
 sys.path.insert(0,'/task/tests/frozen-reference')
 from frozen_reference_loader import load_frozen_reference
 quant=load_frozen_reference().per_token_group_quant_int8
else:
 from vllm.model_executor.layers.quantization.utils.int8_utils import per_token_group_quant_int8 as quant
 torch.ops.load_library('/workspace/repo/vllm/_C.abi3.so')
rows=[]
for shape in [(0,128),(3,0),(0,3,256)]:
 x=torch.empty(shape,device='cuda',dtype=torch.float32);rt.cudaGetLastError()
 r={'shape':shape}
 try:
  q,s=quant(x,64)
  r.update(q_shape=list(q.shape),s_shape=list(s.shape),cuda_error=rt.cudaPeekAtLastError())
  r['subsequent_tensor_sum']=torch.ones(3,device='cuda').sum().item()
 except Exception as e:r['error']=str(e)
 finally:rt.cudaGetLastError()
 rows.append(r)
print('EMPTY='+json.dumps(rows),flush=True)
'''
try:
 for case,relative,patch in [('frozen',None,None),('oracle','runs/pr17/final-a/oracle','solution/oracle.patch'),('alternate','pilot-pr17-alt','validation/alternate-native-kernel.patch')]:
  cid=None
  try:
   mounts=[]
   if relative:
    native=R/relative/'native';m=json.loads((native/'manifest.json').read_text());assert m['sha256']==hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()
    mounts=['--mount',f'type=bind,src={native},dst=/native,readonly']
   cid=subprocess.check_output(['docker','run','-d','--network','none','--gpus','"device='+gpu+'"','--user','root','--workdir','/workspace/repo','--mount',f'type=bind,src={T},dst=/task,readonly',*mounts,'--entrypoint','sleep',image,'infinity'],env=env,text=True).strip()
   if patch:
    subprocess.run(['docker','exec','--user','agent',cid,'git','apply','/task/'+patch],env=env,check=True)
    subprocess.run(['docker','exec',cid,'cp','/native/_C.abi3.so','/workspace/repo/vllm/_C.abi3.so'],env=env,check=True)
   p=subprocess.run(['docker','exec',cid,'python3','-I','-c',code,case],env=env,capture_output=True,text=True,timeout=180)
   (R/('pr17-empty-'+case+'.log')).write_text(p.stdout+p.stderr);print(case,p.returncode,[l for l in p.stdout.splitlines() if l.startswith('EMPTY=')],flush=True)
  finally:
   if cid:subprocess.run(['docker','rm','-f',cid],env=env,capture_output=True)
finally:lock.close()
