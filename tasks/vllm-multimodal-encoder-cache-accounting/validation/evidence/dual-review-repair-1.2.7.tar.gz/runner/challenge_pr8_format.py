from pathlib import Path
import subprocess,sys
R=Path(__file__).parent
for case in ['oracle','alternate-dense-cache','alternate-direct-mask-count','alternate-request-initialized-count','empty-window-admission','lookahead-omission','forged-completion','stale-observations','base','wrong-encoder-cache-order']:
 subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr8',case,'v127-format-final'],check=True)
