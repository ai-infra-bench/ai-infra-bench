from pathlib import Path
import json,hashlib,re
R=Path(__file__).parent
T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
p=T/'validation/alternate-native-kernel.patch'
s=p.read_text();(T/'validation/reciprocal-overflow.patch').write_text(s)
s=s.replace('static_cast<float>(vals[i].val[j]) * inv_scale','(isfinite(inv_scale) ? static_cast<float>(vals[i].val[j]) * inv_scale\n+                              : __fdiv_rn(static_cast<float>(vals[i].val[j]), y_s))')
s=s.replace('static_cast<float>(group_input[i]) * inv_scale','(isfinite(inv_scale) ? static_cast<float>(group_input[i]) * inv_scale\n+                            : __fdiv_rn(static_cast<float>(group_input[i]), y_s))')
s=s.replace('@@ -0,0 +1,267 @@','@@ -0,0 +1,269 @@');p.write_text(s)
(T/'tests/quant_boundary.py').write_text('''"""Small-value observations compared against the frozen executable baseline."""
import json
import math
import subprocess
import sys


def cases():
    pattern = [-1., -.5, 0., .5, 1., .2, 0., -.2]
    return [dict(name=name, shape=shape, group=group, eps=eps,
                 values=[v * magnitude for v in pattern])
            for name, shape, group, eps, magnitude in [
                ("subnormal-64", [3, 128], 64, 1e-45, 1e-38),
                ("subnormal-128", [4, 256], 128, 1e-45, 7e-38),
                ("subnormal-80", [2, 160], 80, 1e-45, 2e-38),
                ("small-normal", [2, 3, 128], 64, 1e-40, 1e-35),
                ("zero-underflow", [3, 128], 64, 1e-45, 0.),
                ("epsilon-dominated", [2, 256], 128, 1e-36, 1e-38),
            ]]


def observe(cases, quantize):
    import torch
    result = []
    for case in cases:
        x = torch.tensor(case["values"], device="cuda", dtype=torch.float32)
        x = x.repeat(math.prod(case["shape"]) // len(case["values"])).reshape(case["shape"])
        q, s = quantize(x, case["group"], case["eps"])
        torch.cuda.synchronize()
        result.append(dict(name=case["name"], q_shape=list(q.shape),
                           s_shape=list(s.shape), q=q.flatten().tolist(),
                           s=s.flatten().tolist()))
    return result


def frozen_observations(inputs, frozen_dir):
    code = """
import sys,json
sys.path.insert(0, sys.argv[1])
from frozen_reference_loader import load_frozen_reference
sys.path.insert(0, sys.argv[2])
from quant_boundary import observe
print('BOUNDARY=' + json.dumps(observe(json.load(sys.stdin), load_frozen_reference().per_token_group_quant_int8)))
"""
    from pathlib import Path
    proc = subprocess.run([sys.executable, "-I", "-c", code, frozen_dir,
                           str(Path(__file__).resolve().parent)],
                          input=json.dumps(inputs), capture_output=True, text=True,
                          timeout=180, check=True)
    lines = [line[9:] for line in proc.stdout.splitlines() if line.startswith("BOUNDARY=")]
    if len(lines) != 1:
        raise ValueError("missing frozen boundary observations")
    return json.loads(lines[0])


def compare(observed, expected):
    if not isinstance(observed, list) or len(observed) != len(expected):
        return ["missing boundary observations"]
    errors = []
    for got, ref in zip(observed, expected):
        if not isinstance(got, dict):
            errors.append("malformed observation")
            continue
        label = ref["name"]
        if any(got.get(k) != ref[k] for k in ("name", "q_shape", "s_shape")):
            errors.append(label + ": shape or case mismatch")
        q, s = got.get("q"), got.get("s")
        if (not isinstance(q, list) or len(q) != len(ref["q"])
                or any(type(a) is not int or abs(a-b) > 1 for a,b in zip(q, ref["q"]))):
            errors.append(label + ": quantized difference exceeds 1")
        # A normal absolute tolerance would silently accept zero subnormal scales.
        if (not isinstance(s, list) or len(s) != len(ref["s"])
                or any(type(a) not in (float, int) or not math.isfinite(a)
                       or abs(a-b) > max(abs(b)*2e-4, 1.401298464324817e-45)
                       for a,b in zip(s, ref["s"]))):
            errors.append(label + ": scale mismatch")
    return errors
''')
p=T/'tests/verify_int8_quant.py';s=p.read_text()
s=s.replace('        # Stage 5: Performance vs frozen baseline (run by parent)', '''        # Return actual values; the parent compares these with an isolated frozen run.
        sys.path.insert(0, "/tests")
        from quant_boundary import observe
        from vllm.model_executor.layers.quantization.utils.int8_utils import per_token_group_quant_int8
        boundary_inputs = json.load(sys.stdin)
        result["stages"]["precision_boundaries"] = {
            "native": observe(boundary_inputs, lambda x, g, eps: cuda_quant(x, g, eps, -128., 127.)),
            "public": observe(boundary_inputs, per_token_group_quant_int8),
        }

        # Stage 5: Performance vs frozen baseline (run by parent)''')
s=s.replace('    "configurable_arguments",\n}', '    "configurable_arguments",\n    "precision_boundaries",\n}')
s=s.replace('def run_worker() -> dict:', 'def run_worker(boundary_inputs, boundary_expected) -> dict:')
s=s.replace('            stdout=subprocess.PIPE,\n            stderr=subprocess.PIPE,\n            timeout=600,','            input=json.dumps(boundary_inputs),\n            stdout=subprocess.PIPE,\n            stderr=subprocess.PIPE,\n            timeout=600,',1)
s=s.replace('            return worker_output\n', '''            from quant_boundary import compare
            observations = stages.get("precision_boundaries", {})
            errors = {path: compare(observations.get(path), boundary_expected)
                      for path in ("native", "public")}
            if any(errors.values()):
                return {"verdict": "FAIL", "reason": "precision_boundary_mismatch", "errors": errors}
            return worker_output
''',1)
s=s.replace('    worker_result = run_worker()', '''    sys.path.insert(0, "/tests")
    from quant_boundary import cases, frozen_observations
    boundary_inputs = cases()
    boundary_expected = frozen_observations(boundary_inputs, FROZEN_DIR)
    worker_result = run_worker(boundary_inputs, boundary_expected)''')
p.write_text(s)
p=T/'validation/ci-cases.json';d=json.loads(p.read_text());d['cases'].append(dict(name='reciprocal-overflow',patch='reciprocal-overflow.patch',expected_reward=0,note='Preserved former alternative: finite FP32 tiny inputs overflow reciprocal; native/public results must agree with frozen Triton.'))
for c in d['cases']: c['patch_sha256']=hashlib.sha256((T/'validation'/c['patch']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
