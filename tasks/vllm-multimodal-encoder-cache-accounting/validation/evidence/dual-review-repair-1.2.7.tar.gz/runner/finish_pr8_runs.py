from pathlib import Path
import time,json,subprocess,sys
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);cases=['base','oracle']+[x['name'] for x in json.loads((T/'validation/ci-cases.json').read_text())['cases']]
while True:
 records=[json.loads(p.read_text()) for p in R.glob('runs/pr8/*/*/run-record.json')]
 failed=[r for r in records if r['status']=='execution_or_preflight_failed']
 if failed:raise RuntimeError(failed)
 done={r['case'] for r in records if r['status']=='completed_result_checked'}
 if set(cases)<=done:break
 time.sleep(5)
subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr8','frozen-final','base','oracle'],check=True)
