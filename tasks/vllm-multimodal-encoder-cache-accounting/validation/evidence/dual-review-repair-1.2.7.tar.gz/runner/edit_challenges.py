from pathlib import Path
import json
R=Path(__file__).parent;ts=json.loads((R/'targets.json').read_text())
p=Path(ts['pr8']['task'])/'validation/challenge/challenge_encoder_cache.py';s=p.read_text()
f='''
def challenge_cold_empty_resources():
    count = 0
    for length, indices in [(41, [2, 11, 29, 38]), (53, [7, 18, 22, 40, 51])]:
        req = request_for("empty-resources", PlaceholderRange(0, length, mask_from(length, indices)))
        scheduler = object.__new__(Scheduler)
        scheduler.ec_connector = None
        scheduler.is_encoder_decoder = False
        scheduler.scheduler_config = SimpleNamespace(disable_chunked_mm_input=False)
        n = len(indices)
        for capacity, budget in [(0,n), (n-1,n), (n,0), (n,n-1), (n,n)]:
            scheduler.encoder_cache_manager = EncoderCacheManager(cache_size=capacity)
            result = Scheduler._try_schedule_encoder_inputs(scheduler, req, 0, indices[0], budget)
            assert result == ([], indices[0], budget, []), (capacity, budget, result)
            count += 1
    return {"cases": count}

'''
s=s.replace('def main() -> None:', f+'\ndef main() -> None:',1).replace('    "multi_item_zero": {', '    "cold_empty_resources": {"cases": 10},\n    "multi_item_zero": {',1).replace('        "cold_to_cached": challenge_cold_to_cached,','        "cold_to_cached": challenge_cold_to_cached,\n        "cold_empty_resources": challenge_cold_empty_resources,',1)
p.write_text(s)
p=Path(ts['pr17']['task'])/'validation/challenge/challenge_int8_quant.py';s=p.read_text()
s=s.replace('        with replace(int8_utils, "_per_token_group_quant_int8", _TritonBomb()):\n            q, s = int8_utils.per_token_group_quant_int8(x, group_size)', '''        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU]) as profile:
            q, s = int8_utils.per_token_group_quant_int8(x, group_size)
        assert "_C::per_token_group_quant_int8" in {event.key for event in profile.key_averages()}''')
f='''
def challenge_tiny_fp32():
    # Independent values and non-power-of-two groups, separate frozen process.
    import subprocess
    from pathlib import Path
    frozen = str(Path("/task/tests/frozen-reference"))
    code = """
import sys,json,torch
sys.path.insert(0,sys.argv[1])
from frozen_reference_loader import load_frozen_reference
f=load_frozen_reference().per_token_group_quant_int8
result=[]
for group in (48,96,128):
 x=torch.tensor([-3e-38,-1e-38,0.,1e-38,2e-38,3e-38],device='cuda',dtype=torch.float32).repeat(group).reshape(3,2*group)
 q,s=f(x,group,1e-44)
 result.append([q.flatten().tolist(),s.flatten().tolist()])
print('FRESH='+json.dumps(result))
"""
    proc=subprocess.run([sys.executable,"-I","-c",code,frozen],capture_output=True,text=True,check=True)
    refs=json.loads(next(line[6:] for line in proc.stdout.splitlines() if line.startswith('FRESH=')))
    for group,(refq,refs_) in zip((48,96,128),refs):
        x=torch.tensor([-3e-38,-1e-38,0.,1e-38,2e-38,3e-38],device='cuda',dtype=torch.float32).repeat(group).reshape(3,2*group)
        for fn in (cuda_quant,int8_utils.per_token_group_quant_int8):
            q,s=fn(x,group,1e-44)
            assert max(abs(a-b) for a,b in zip(q.flatten().tolist(),refq)) <= 1
            assert all(abs(a-b) <= max(abs(b)*2e-4,1.401298464324817e-45) for a,b in zip(s.flatten().tolist(),refs_))
    return {"cases": 3, "paths": 2}

'''
s=s.replace('def main() -> None:',f+'\ndef main() -> None:',1).replace('        "custom_range": challenge_custom_range,','        "custom_range": challenge_custom_range,\n        "tiny_fp32": challenge_tiny_fp32,',1)
p.write_text(s)
