"""Publish only observed results; keep historical rewards and incomplete rollouts separate."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tomllib,tarfile,os,tempfile
R=Path(__file__).parent;key=sys.argv[1]
T=Path(json.loads((R/'targets.json').read_text())[key]['task']);repo=T.parents[1]
S=Path('/data/yinchen/remaining-four-dual-review-20260911T150540Z/skill-repo/.agents/skills/ai-infra-bench-task-review')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((R/(key+'-freeze.json')).read_text());assert all(digest(T/p)==h for p,h in freeze.items())
cases={c['name']:c for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']}
expected={'base':0,'oracle':1,**{k:v['expected_reward'] for k,v in cases.items()}}
old=json.loads((R/'before'/key/'validation/e2e-evidence.json').read_text());image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']

def parse_result(text):
 import re
 for m in re.finditer(r'^\{',text,re.M):
  try:
   d=json.JSONDecoder().raw_decode(text[m.start():])[0]
   if isinstance(d,dict) and d.get('verdict') in ['PASS','FAIL']:return d
  except ValueError:pass
 raise ValueError('missing verifier result')

excluded=json.loads((R/'excluded-runs.json').read_text()).get(key,[])
excluded_roots={x['run_root'] for x in excluded}
superseded=json.loads((R/'superseded-format-runs.json').read_text()) if key=='pr8' else {'runs':[],'challenges':[]}
excluded_roots.update(superseded['runs'])
rows=[]
records=sorted((R/'runs'/key).glob(('v127-format*/*/run-record.json' if key=='pr8' else 'v124-*/*/run-record.json')))
for path in records:
 if str(path.parent) in excluded_roots:continue
 rec=json.loads(path.read_text());assert rec['status']=='completed_result_checked',(path,rec['status'])
 case=rec['case'];out=path.parent;jobp=Path(rec['raw_result']);job=json.loads(jobp.read_text());trials=list(jobp.parent.glob('*/result.json'));assert len(trials)==1
 trial=json.loads(trials[0].read_text());verifier=trials[0].parent/'verifier';reward=trial['verifier_result']['rewards']['reward']
 assert reward==expected[case]==float((verifier/'reward.txt').read_text())
 assert job['stats']['n_errored_trials']==0 and trial['exception_info'] is None and rec['harbor_exit']==0
 assert rec['image_id_observed']==image
 required=[p for p in freeze if p.startswith(('tests/','environment/')) or p in ['task.toml','solution/solve.sh'] or p=='instruction.md']
 if case=='oracle' or cases.get(case,{}).get('apply_after')=='oracle':required.append('solution/oracle.patch')
 if case in cases:required.append('validation/'+cases[case]['patch'])
 assert all(rec['executable_files'].get(p)==freeze[p] for p in required),(path,'runtime hash mismatch')
 differences=[p for p,h in freeze.items() if rec['executable_files'].get(p)!=h]
 result=parse_result((verifier/('verification.json' if key=='pr8' else 'verification.log')).read_text())
 if reward:assert result['verdict']=='PASS'
 if key=='pr17' and case in ['base','wrong-public-operator-name']:
  assert 'native_operator_missing' in json.dumps(result)
  assert result['worker_result']['worker_output']['swapped_alias'] is (case=='wrong-public-operator-name')
 if key=='pr17' and reward:
  native=json.loads((out/'native/manifest.json').read_text())
  assert digest(out/'native/_C.abi3.so')==native['sha256']
  assert all(t['candidate_observation']['native_sha256']==native['sha256']
             for t in result['stages']['performance_vs_frozen_baseline']['timing'])
 if key=='pr8' and case in ['empty-window-admission','forged-completion','stale-observations','lookahead-omission']:
  assert result.get('reason')=='fresh_behavioral_observation_mismatch'
  if case=='empty-window-admission':assert result['observed']['empty']!=result['expected']['empty']
  if case=='lookahead-omission':
   assert result['observed']['lookahead']!=result['expected']['lookahead']
   assert all(result['observed'][k]==v for k,v in result['expected'].items() if k!='lookahead')
 if key=='pr17' and case=='reciprocal-overflow':assert result['worker_result']['reason']=='precision_boundary_mismatch'
 if key=='pr17' and case=='slow-candidate-occupancy':assert result['reason']=='performance_below_threshold'
 if key=='pr17' and case=='early-native-timing-exit':assert 'CONTROL_REACHED:early-native-timing-exit' in (out/'curator-native-timing-control.txt').read_text()
 raw={str(p):digest(p) for p in out.rglob('*') if p.is_file() and 'prepared' not in p.parts and 'native' not in p.parts}
 row=dict(case=case,scope='full Harbor run',run_root=str(out),expected_reward=expected[case],actual_reward=reward,image_id=image,gpu_uuids=rec['gpu_uuids'],job_id=job['id'],trial_id=trial['id'],task_checksum=trial['task_checksum'],errored_trials=0,harbor_exit_code=0,grading_and_selected_patch_hashes_match=True,non_grading_snapshot_differences=differences,verifier_result=result,raw_artifacts=raw)
 rows.append(row)
assert set(expected)<={r['case'] for r in rows}
final=next((r for r in rows if r['case']=='oracle' and '/frozen-final-confirmation/' in r['run_root']), None)
if final is None:final=next(r for r in rows if r['case']=='oracle' and Path(r['run_root']).parent.name.endswith('frozen-final') and not r['non_grading_snapshot_differences'])
assert final['actual_reward']==1 and not final['non_grading_snapshot_differences']
challenges=[]
for p in sorted((R/'challenges'/key).glob(('v127-format*/*/record.json' if key=='pr8' else 'v124-*/*/record.json'))):
 if str(p.parent) in superseded['challenges']:continue
 d=json.loads(p.read_text());assert d['status']=='expected_outcome_observed' and d['actual']==d['expected']
 assert d['image']==image and all(digest(T/n)==h for n,h in d['patches'].items())
 assert digest(p.parent/'challenge.log')==d['log_sha256'];d['record_path']=str(p);challenges.append(d)
needed={'oracle','alternate-dense-cache','empty-window-admission','forged-completion','stale-observations','lookahead-omission','base'} if key=='pr8' else {'oracle','alternate-native-kernel','compatible-operator-alias','reciprocal-overflow','base','renamed-private-triton-helper','empty-batch-launch'}
needed |= {name for name, reward in expected.items() if reward == 1}
assert needed<={r['case'] for r in challenges}
cfg=tomllib.loads((T/'task.toml').read_text());version=cfg['task']['version']
review=dict(mode='hardening',statement='passed; three natural prose paragraphs with the necessary behavioral and performance contract',environment='passed; source cutoff, dependency recipe and image unchanged; image identity and agent-user canary checked before each Harbor run',verification='passed for declared behavioral scope and preserved counterexamples',semantic_boundary=(R/'CONTRACT.md').read_text())
evidence=dict(schema_version='vllm_harbor_task_validation.v1',status='validated',validation_status='local_full_controls_and_independent_challenges_passed',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),task=cfg['task']['name'],task_version=version,source=old['source'],image=old['image'],artifacts={'files':{p:{'sha256':h} for p,h in freeze.items()}},freeze={'files':freeze,'final_oracle_run':final['run_root']},review=review,skill=json.loads((R/'skill-provenance.json').read_text()),provenance_gates=dict(current_hashes_match=True,final_oracle_passed=True,zero_harbor_errors=True,grading_and_selected_patch_hashes_match=True,historical_rewards_preserved=True),harbor=dict(runs=rows,run_count=len(rows),final_oracle=final,all_expected_outcomes=True,errored_trials=0),independent_challenges=dict(runs=challenges,run_count=len(challenges),all_expected_outcomes=True),prior_review_superseded=('validation/history/1.2.6-before-lookahead-repair.json' if key=='pr8' else 'validation/history/1.2.3-before-empty-batch-repair.json'),publication=dict(status='local_changes_not_committed_or_pushed'),excluded_attempts=excluded,superseded_format_runs=superseded,limitations=['No new Opus rollout was run. Historical scores and reports are unchanged.','Historical incomplete final native/source archives remain a separate rollout-review limitation.','New PR8 workloads reject fixed completion and stale observation replay; this does not certify isolation against arbitrary native process compromise.','Only current-version runs are counted. Any non-grading snapshot differences are recorded per run. Superseded-version runs are retained locally and are not counted as current validation. The final frozen Oracle matches every executable hash.'])
# Portable evidence stores raw logs/results/configs and runner sources. Native
# artifacts remain separately identified by their manifests and absolute paths.
archive=T/'validation/evidence'/('dual-review-repair-'+version+'.tar.gz');archive.parent.mkdir(exist_ok=True)
with tarfile.open(archive,'w:gz') as tar:
 seen=set()
 for row in rows:
  for name in row['raw_artifacts']:
   p=Path(name)
   if p not in seen:tar.add(p,arcname=str(p.relative_to(R)));seen.add(p)
 for attempt in excluded:
  for p in Path(attempt['run_root']).rglob('*'):
   if p.is_file() and 'prepared' not in p.parts:tar.add(p,arcname=str(p.relative_to(R)))
 for row in challenges:
  p=Path(row['record_path']).parent
  for f in p.iterdir():
   if f.is_file():tar.add(f,arcname=str(f.relative_to(R)))
 for p in R.glob('*.py'):tar.add(p,arcname='runner/'+p.name)
 tar.add(R/'CONTRACT.md',arcname='CONTRACT.md')
 tar.add(R/'execution-invariance.json',arcname='execution-invariance.json')
 for p in R.glob('*-instruction-*.md'):tar.add(p,arcname=p.name)
 if key=='pr17':tar.add(R/'pr17-performance-invariance.json',arcname='pr17-performance-invariance.json')
 if key=='pr8':
  tar.add(R/'pr8-patch-equivalence.json',arcname='pr8-patch-equivalence.json')
  tar.add(R/'pr8-whitespace-changes.json',arcname='pr8-whitespace-changes.json')
evidence['portable_raw_evidence']={'archive':str(archive.relative_to(T)),'sha256':digest(archive),'includes':'raw Harbor records/results/logs, independent challenge logs, curator runners; native binaries remain in separately identified local native directories'}
(T/'validation/e2e-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
fix=('The parent derives expected allocation, budget, profiling and tensor observations from freshly generated inputs. Real scheduler, allocator, encoder writer and gather execute in the worker. Oracle and dense-cache alternative now skip empty embedding windows before capacity/budget admission while preserving existing EAGLE lookahead, including mask-free inputs. Preserved low-resource and lookahead omission implementations, fixed completion and stale successful-report controls are rejected.' if key=='pr8' else 'Native and public FP32 boundary outputs are compared by the parent against a separate frozen Triton execution. The former native alternative is a reciprocal-overflow negative; the corrected alternative divides when the reciprocal is non-finite. Six tiny FP32 cases and three empty shapes now check both native and public outputs, including dtype, device, and subsequent CUDA health. The Oracle returns without launching for zero groups after validating output shapes; its former empty-grid launch is retained as an independent negative. The statement describes the existing median-of-five-batch-averages protocol precisely. All timing functions and thresholds are unchanged.')
text=f'''# {key.upper()} task review — {version}

The task can be retained after this repair. {fix}

Gate 1 passes: the description is three continuous prose paragraphs. Public requirements establish the behavior before the verifier and Oracle. Gate 2 passes: source, dependencies, Docker recipe and image are unchanged; each run checked image identity and an agent-user canary. Gate 3 passes for the declared behavioral boundary: {len(rows)} full Harbor runs and {len(challenges)} independent challenges met their expected outcomes; zero Harbor errors in those completed control runs. {len(excluded)} failed preflight or environment-start attempts are preserved separately and excluded from grading conclusions. The final frozen Oracle scored 1.

The exact source boundary and allowed producer substitutions are documented in semantic-boundary.md. Current executable SHA256 values, image identity, per-run job/trial IDs, actual rewards and raw evidence are in e2e-evidence.json. Only current-version runs are counted. Any non-grading snapshot differences are listed per run. Grading inputs and selected patches match; the final Oracle has no executable differences.

No model rollout, commit, push or PR update was performed in this repair. Historical scores remain unchanged, and missing historical final code/native archives still prevent complete rollout certification. This task review does not turn fixed report checks into a claim of isolation from arbitrary native process compromise.
'''
(T/'validation/final-review.md').write_text(text);(R/(key+'-RESULT.md')).write_text(text)
checks={}
for name,cmd in [('strict',[sys.executable,str(S/'scripts/audit_task_artifacts.py'),str(T),'--strict-evidence']),('task-ci',[sys.executable,str(repo/'.github/scripts/task_ci.py'),'validate',T.name]),('diff-check',['git','diff','--check','--',str(T.relative_to(repo))])]:
 if name=='diff-check':
  # Include this task's untracked files without modifying the user's Git index.
  with tempfile.TemporaryDirectory(prefix=key+'-index-',dir=R) as scratch:
   env=dict(os.environ,GIT_INDEX_FILE=str(Path(scratch)/'index'))
   subprocess.run(['git','read-tree','HEAD'],cwd=repo,env=env,check=True,capture_output=True)
   subprocess.run(['git','add','-N','--',str(T.relative_to(repo))],cwd=repo,env=env,check=True,capture_output=True)
   proc=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True)
 else:proc=subprocess.run(cmd,cwd=repo,capture_output=True,text=True)
 (R/(key+'-'+name+'.log')).write_text(proc.stdout+proc.stderr);checks[name]=proc.returncode
 print(key,name,proc.returncode,proc.stdout[-500:],proc.stderr[-300:],flush=True)
(R/(key+'-final-checks.json')).write_text(json.dumps(checks,indent=2)+'\n')
if any(checks.values()):
 evidence['status']='final_audit_failed';evidence['validation_status']='requires_correction';evidence['failed_final_checks']=checks
 (T/'validation/e2e-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
 failure_text='FINAL REVIEW INCOMPLETE: '+json.dumps(checks)+'\n\n'+text
 (T/'validation/final-review.md').write_text(failure_text);(R/(key+'-RESULT.md')).write_text(failure_text)
 raise AssertionError(checks)
print('FINALIZED',key,len(rows),len(challenges),flush=True)
