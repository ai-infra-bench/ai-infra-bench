from pathlib import Path
import json,time,subprocess,sys
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);expected={'base','oracle'}|{c['name'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']}
while True:
 excluded={x['run_root'] for x in json.loads((R/'excluded-runs.json').read_text())['pr8']}
 records=[json.loads(p.read_text()) for p in R.glob('runs/pr8/v127-*/*/run-record.json') if str(p.parent) not in excluded]
 failed=[r for r in records if r['status']=='execution_or_preflight_failed']
 if failed:raise RuntimeError(failed)
 done={r['case'] for r in records if r['status']=='completed_result_checked'}
 challenges=[json.loads(p.read_text()) for p in R.glob('challenges/pr8/v127-*/*/record.json')]
 assert all(r.get('status')=='expected_outcome_observed' for r in challenges),challenges
 if expected<=done and len(challenges)==10:break
 time.sleep(5)
subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr8','v127-frozen-final','oracle'],check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr8'],check=True)
