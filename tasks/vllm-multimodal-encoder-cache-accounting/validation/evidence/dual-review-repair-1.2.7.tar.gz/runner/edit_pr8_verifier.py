from pathlib import Path
import json
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task'])
for n in ['encoder_contract.py','encoder_fresh_worker.py']:(T/'tests'/n).write_bytes((R/n).read_bytes())
p=T/'tests/verify_encoder_cache.py';s=p.read_text();a=s.index("WORKER_CODE = r'''");b=s.index("\n'''",a)+4
worker=s[a:b]
worker=worker.replace('    result = {\n        "coordinate_spaces":', '''    fresh = None
    try:
        fresh = observe_fresh(json.load(sys.stdin))
    except Exception as exc:
        failures["fresh_observations"] = {"message": str(exc), "traceback": traceback.format_exc()}
    result = {
        "observations": fresh,
        "coordinate_spaces":''')
s=s[:a]+worker+s[b:]
# Assemble trusted fixture source before the embedded entry point executes.
pos=s.index('\n\nPAYLOAD_BEGIN')
s=s[:pos]+'''\n\nfrom pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from encoder_contract import workload, expected
WORKER_CODE = WORKER_CODE.replace("def main() -> None:",
    Path(__file__).with_name("encoder_fresh_worker.py").read_text() + "\\n\\ndef main() -> None:", 1)
'''+s[pos:]
s=s.replace('    try:\n        result = subprocess.run(\n', '    inputs = workload()\n    expected_values = expected(inputs)\n    try:\n        result = subprocess.run(\n',1)
s=s.replace('            stdout=subprocess.PIPE,\n            stderr=subprocess.PIPE,\n            timeout=300,','            input=json.dumps(inputs),\n            stdout=subprocess.PIPE,\n            stderr=subprocess.PIPE,\n            timeout=300,',1)
s=s.replace('        return {\n            "verdict": "PASS",','''        observations = worker_output.get("observations")
        if observations != expected_values:
            return {"verdict": "FAIL", "reason": "fresh_behavioral_observation_mismatch",
                    "inputs": inputs, "observed": observations, "expected": expected_values}
        return {
            "inputs": inputs,
            "observations": observations,
            "verdict": "PASS",''',1)
p.write_text(s)
