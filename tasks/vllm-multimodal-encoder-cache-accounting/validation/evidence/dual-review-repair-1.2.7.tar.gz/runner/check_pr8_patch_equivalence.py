from pathlib import Path
import subprocess,os,json,hashlib
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
code=r'''
import subprocess,json,hashlib
from pathlib import Path

def git(*args):return subprocess.check_output(['git',*args],stderr=subprocess.STDOUT)
assert not git('status','--porcelain').strip()
ci=json.loads(Path('/after/validation/ci-cases.json').read_text())
rows=[]
for c in [{'name':'oracle','patch':None}]+ci['cases']:
 patches=[]
 if c['name']=='oracle' or c.get('apply_after')=='oracle':patches.append('solution/oracle.patch')
 if c['patch']:patches.append('validation/'+c['patch'])
 digests=[]
 for root in ['/before','/after']:
  for p in patches:git('apply',root+'/'+p)
  git('add','-A');digests.append(hashlib.sha256(git('diff','--cached','--binary')).hexdigest())
  git('reset','--hard','HEAD');git('clean','-fd')
 assert digests[0]==digests[1],(c['name'],digests)
 rows.append({'case':c['name'],'applied_source_diff_sha256':digests[0],'identical':True})
print(json.dumps(rows,indent=2))
'''
cmd=['docker','run','--rm','--network','none','--user','agent','-w','/app','--mount',f'type=bind,src={R}/before-whitespace-pr8,dst=/before,readonly','--mount',f'type=bind,src={T},dst=/after,readonly','--entrypoint','python3',image,'-c',code]
p=subprocess.run(cmd,env=env,capture_output=True,text=True)
(R/'pr8-patch-equivalence.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
(R/'pr8-patch-equivalence.json').write_text(p.stdout);print(p.stdout)
