from pathlib import Path
import json,shutil,subprocess,difflib,hashlib
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task'])
shutil.copytree(T,R/'before-lookahead-pr8')
(T/'validation/history/1.2.6-before-lookahead-repair.json').write_bytes((T/'validation/e2e-evidence.json').read_bytes())
(T/'validation/lookahead-omission.patch').write_bytes((T/'solution/oracle.patch').read_bytes())
for rel in ['solution/oracle.patch','validation/alternate-dense-cache.patch']:
 p=T/rel;patch=p.read_text();tmp=R/('lookahead-'+p.stem);f=tmp/'vllm/v1/core/sched/scheduler.py';f.parent.mkdir(parents=True,exist_ok=True);base=(R/'base-scheduler.py').read_text();f.write_text(base)
 subprocess.run(['git','init','-q',str(tmp)],check=True)
 subprocess.run(['git','apply','--include=vllm/v1/core/sched/scheduler.py',str(p)],cwd=tmp,check=True)
 source=f.read_text();old='num_encoder_tokens, num_computed_tokens + num_new_tokens - start_pos';assert old in source
 source=source.replace(old,'num_encoder_tokens,\n                num_computed_tokens + num_new_tokens + shift_computed_tokens - start_pos',1)
 f.write_text(source)
 a=patch.index('diff --git a/vllm/v1/core/sched/scheduler.py');b=patch.find('\ndiff --git ',a+1);b=len(patch) if b<0 else b+1
 diff='diff --git a/vllm/v1/core/sched/scheduler.py b/vllm/v1/core/sched/scheduler.py\n'+''.join(difflib.unified_diff(base.splitlines(True),source.splitlines(True),fromfile='a/vllm/v1/core/sched/scheduler.py',tofile='b/vllm/v1/core/sched/scheduler.py'))
 p.write_text(patch[:a]+diff+patch[b:])
p=T/'instruction.md';s=p.read_text().replace('A window containing no embedding positions must still advance through its prompt tokens without scheduling the encoder or consuming encoder budget, including when the encoder budget or available cache capacity is zero.', 'When neither the current window nor speculative-decoding lookahead needs an embedding, the request must still advance through its prompt tokens without scheduling the encoder or consuming encoder budget, even if the budget or available cache capacity is zero.');p.write_text(s)
p=T/'task.toml';s=p.read_text().replace('version = "1.2.6"','version = "1.2.7"');p.write_text(s)
p=T/'tests/encoder_contract.py';s=p.read_text().replace("    return dict(allocations=allocations, empty=empty, nonempty=nonempty,", """    # Main-model tokens and EAGLE's shifted tokens both need encoder outputs.
    lookahead = [[[0], 2, 0, []], [[], 1, n, []], [[], 1, 0, []],
                 [[], 1, n-1, []], [[], 2, 0, []], [[0], 1, 0, []]]
    return dict(lookahead=lookahead, allocations=allocations, empty=empty, nonempty=nonempty,""");p.write_text(s)
p=T/'tests/encoder_fresh_worker.py';s=p.read_text();anchor="    class Info:\n";assert anchor in s
code='''    # Preserve the real caller's EAGLE lookahead, including mask-free inputs.
    lookahead=[]
    offset=specs[3]['offset']
    configurations=[(None,n,n,offset-2,2), (None,0,n,offset-2,2),
                    (None,n,0,offset-2,2), (None,n,n-1,offset-2,2),
                    ([1,n-1],0,0,offset-2,2), ([0,n-1],2,2,offset,1)]
    for indices,capacity,budget,start,count in configurations:
        mask=None if indices is None else sparse_mask(n,indices)
        feature=MultiModalFeatureSpec(data=None,modality='image',identifier='lookahead',
                                     mm_position=PlaceholderRange(offset,n,mask))
        look_request=Request(request_id='lookahead',prompt_token_ids=[1]*37,
            sampling_params=params,pooling_params=None,eos_token_id=None,mm_features=[feature])
        scheduler.encoder_cache_manager=EncoderCacheManager(cache_size=capacity)
        lookahead.append(Scheduler._try_schedule_encoder_inputs(
            scheduler,look_request,start,count,budget,shift_computed_tokens=1))
'''
s=s.replace(anchor,code+anchor,1).replace('return dict(allocations=allocations,empty=empty,nonempty=nonempty,profile=profile,','return dict(lookahead=lookahead,allocations=allocations,empty=empty,nonempty=nonempty,profile=profile,');p.write_text(s)
p=T/'validation/challenge/challenge_encoder_cache.py';s=p.read_text();f='''
def challenge_lookahead():
    scheduler=object.__new__(Scheduler)
    scheduler.ec_connector=None
    scheduler.is_encoder_decoder=False
    scheduler.scheduler_config=SimpleNamespace(disable_chunked_mm_input=False)
    cases=[(None,7,7,11,2,([0],2,0,[])),
           (None,0,7,11,2,([],1,7,[])),
           (None,7,0,11,2,([],1,0,[])),
           (None,7,6,11,2,([],1,6,[])),
           ([1,5],0,0,11,2,([],2,0,[])),
           ([0,6],2,2,13,1,([0],1,0,[]))]
    for indices,capacity,budget,start,count,wanted in cases:
        mask=None if indices is None else mask_from(7,indices)
        request=request_for('lookahead',PlaceholderRange(13,7,mask))
        scheduler.encoder_cache_manager=EncoderCacheManager(cache_size=capacity)
        actual=Scheduler._try_schedule_encoder_inputs(scheduler,request,start,count,budget,shift_computed_tokens=1)
        assert actual==wanted,(indices,capacity,budget,actual,wanted)
    return {"cases":len(cases)}

'''
s=s.replace('def main() -> None:',f+'\ndef main() -> None:',1).replace('    "cold_empty_resources": {"cases": 10},','    "lookahead": {"cases": 6},\n    "cold_empty_resources": {"cases": 10},',1).replace('        "cold_empty_resources": challenge_cold_empty_resources,','        "cold_empty_resources": challenge_cold_empty_resources,\n        "lookahead": challenge_lookahead,',1);p.write_text(s)
p=T/'validation/ci-cases.json';d=json.loads(p.read_text());d['cases'].append(dict(name='lookahead-omission',patch='lookahead-omission.patch',expected_reward=0,note='Preserved prior Oracle handles low-resource empty windows but skips encoder output required by EAGLE lookahead, including mask-free inputs.'))
for c in d['cases']:c['patch_sha256']=hashlib.sha256((T/'validation'/c['patch']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
p=T/'validation/e2e-evidence.json';d=json.loads(p.read_text());d.update(status='validation_in_progress',validation_status='lookahead_regression_repair_in_progress',task_version='1.2.7');p.write_text(json.dumps(d,indent=2)+'\n')
