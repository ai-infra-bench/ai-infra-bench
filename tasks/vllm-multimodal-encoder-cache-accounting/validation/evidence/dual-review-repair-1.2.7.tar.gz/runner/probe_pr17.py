from pathlib import Path
import json,subprocess,os,fcntl
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
N=Path('/data/yinchen/task-final-review-20260908T163254Z/native-evidence/pr17-oracle-review-a');image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
gpu='GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329';lock=open('/data/yinchen/vllm-pr8-controls/.phaseD-gpu-locks/'+gpu+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
cid=None
try:
 cid=subprocess.check_output(['docker','run','-d','--network','none','--gpus','"device='+gpu+'"','--user','root','--workdir','/workspace/repo','--mount',f'type=bind,src={T},dst=/task,readonly','--mount',f'type=bind,src={N},dst=/native,readonly','--entrypoint','sleep',image,'infinity'],env=env,text=True).strip()
 subprocess.run(['docker','exec','--user','agent',cid,'git','apply','/task/solution/oracle.patch'],env=env,check=True)
 subprocess.run(['docker','exec',cid,'cp','/native/_C.abi3.so','/workspace/repo/vllm/_C.abi3.so'],env=env,check=True)
 code='''
import sys,json,torch
sys.path.insert(0,'/task/tests')
from quant_boundary import cases,observe,frozen_observations,compare
inputs=cases();refs=frozen_observations(inputs,'/task/tests/frozen-reference')
from vllm.model_executor.layers.quantization.utils.int8_utils import per_token_group_quant_int8
results=observe(inputs,per_token_group_quant_int8)
print(json.dumps({'errors':compare(results,refs),'actual':results,'reference':refs}))
'''
 p=subprocess.run(['docker','exec',cid,'python3','-I','-c',code],env=env,capture_output=True,text=True,timeout=240)
 (R/'pr17-oracle-boundary-diagnostic.log').write_text(p.stdout+p.stderr)
 print('diagnostic',p.returncode,p.stdout[-500:] if p.returncode else next((l[:300] for l in p.stdout.splitlines() if l.startswith('{')), 'NORESULT'))
 if p.returncode:print(p.stderr[-2000:])
finally:
 if cid:subprocess.run(['docker','rm','-f',cid],env=env,capture_output=True)
 lock.close()
