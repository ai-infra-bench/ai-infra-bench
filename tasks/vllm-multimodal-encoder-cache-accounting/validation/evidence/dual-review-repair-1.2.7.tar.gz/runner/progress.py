from pathlib import Path
import datetime,json,subprocess,os,re
R=Path(__file__).parent
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
for key,pattern in [('pr8','v127-format*'),('pr17','v124-*')]:
 rows=[];excluded={a['run_root'] for a in json.loads((R/'excluded-runs.json').read_text()).get(key,[])}
 if key=='pr8':excluded.update(json.loads((R/'superseded-format-runs.json').read_text())['runs'])
 for p in sorted(R.glob('runs/'+key+'/'+pattern+'/*/run-record.json')):
  if str(p.parent) in excluded:continue
  d=json.loads(p.read_text());row={'case':d['case'],'tag':p.parent.parent.name,'status':d['status']}
  if d['status']=='completed_result_checked':row['rewards']=[t['verifier_result']['rewards'] for t in d['observed_trials']]
  if d['status']=='running' and key=='pr17':
   logs=list(p.parent.glob('jobs/*/*/trial.log'))
   if logs:
    name=logs[0].parent.name.lower()+'__env-main-1'
    o=subprocess.run(['docker','exec',name,'tail','-n','2','/logs/verifier/native-build.stdout.log'],env=env,capture_output=True,text=True)
    row['build']=(re.findall(r'\[\d+/\d+\]',o.stdout) or [o.stdout[-120:]])[-1]
  if 'error' in d:row['error']=d['error']
  rows.append(row)
 sup_ch=set(json.loads((R/'superseded-format-runs.json').read_text())['challenges']) if key=='pr8' else set()
 challenges=[json.loads(p.read_text()) for p in R.glob('challenges/'+key+'/'+pattern+'/*/record.json') if str(p.parent) not in sup_ch]
 completed=[r for r in rows if r['status']=='completed_result_checked'];live=[r for r in rows if r['status']!='completed_result_checked']
 print(key,json.dumps({'completed':len(completed),'last_completed':completed[-2:],'live':live,'challenges':len(challenges),'challenge_ok':sum(d.get('status')=='expected_outcome_observed' for d in challenges)},ensure_ascii=False))
for name in ['finish_pr8_eof','pr17-v124-finish']:
 p=R/(name+'.log')
 if p.exists() and p.stat().st_size:print(name,p.read_text()[-1000:])
