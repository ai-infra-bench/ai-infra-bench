from pathlib import Path
import json,subprocess,difflib,hashlib
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task'])
old=(T/'solution/oracle.patch').read_text();(T/'validation/empty-window-admission.patch').write_text(old)
for rel in ['solution/oracle.patch','validation/alternate-dense-cache.patch']:
 p=T/rel;s=p.read_text();temp=R/('scheduler-'+p.stem);temp.mkdir(exist_ok=True)
 f=temp/'vllm/v1/core/sched/scheduler.py';f.parent.mkdir(parents=True,exist_ok=True);base=(R/'base-scheduler.py').read_text();f.write_text(base)
 subprocess.run(['git','init','-q',str(temp)],check=True)
 subprocess.run(['git','apply','--include=vllm/v1/core/sched/scheduler.py',str(p)],cwd=temp,check=True)
 source=f.read_text();start=source.index('            # Calculate the number of embeddings') if '            # Calculate the number of embeddings' in source else -1
 if start<0:
  print(source[source.index('    def _try_schedule_encoder_inputs'):source.index('    def _try_schedule_encoder_inputs')+6500]);raise RuntimeError('locate block')
 end=source.index('\n\n',source.index('                continue',start))+2
 block=source[start:end];source=source[:start]+source[end:]
 pos=source.index('            if not self.encoder_cache_manager.can_allocate(',source.index('    def _try_schedule_encoder_inputs'))
 source=source[:pos]+block+source[pos:];f.write_text(source)
 a=s.index('diff --git a/vllm/v1/core/sched/scheduler.py');b=s.find('\ndiff --git ',a+1);b=len(s) if b<0 else b+1
 diff='diff --git a/vllm/v1/core/sched/scheduler.py b/vllm/v1/core/sched/scheduler.py\n'+''.join(difflib.unified_diff(base.splitlines(True),source.splitlines(True),fromfile='a/vllm/v1/core/sched/scheduler.py',tofile='b/vllm/v1/core/sched/scheduler.py'))
 p.write_text(s[:a]+diff+s[b:])
(T/'validation/forged-completion.patch').write_bytes(Path('/data/yinchen/remaining-four-dual-review-20260911T150540Z/diagnostics/pr8/forged-completion/candidate.patch').read_bytes())
p=T/'validation/ci-cases.json';d=json.loads(p.read_text())
for name,note in [('empty-window-admission','Preserved previous Oracle blocks a cold empty window with insufficient encoder capacity or budget.'),('forged-completion','Preserved fixed completion report; no target behavior executed.')]:
 d['cases'].append(dict(name=name,patch=name+'.patch',expected_reward=0,note=note))
for c in d['cases']:c['patch_sha256']=hashlib.sha256((T/'validation'/c['patch']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
