from pathlib import Path
import subprocess,sys
R=Path(__file__).parent
subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr8','v127-format-final-eof','alternate-request-initialized-count'],check=True)
subprocess.run([sys.executable,str(R/'run_challenge.py'),'pr8','alternate-request-initialized-count','v127-format-final-eof'],check=True)
subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr8','v127-format-z-frozen-final','oracle'],check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr8'],check=True)
