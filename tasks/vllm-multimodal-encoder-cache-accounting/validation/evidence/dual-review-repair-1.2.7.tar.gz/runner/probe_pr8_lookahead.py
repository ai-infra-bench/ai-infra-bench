from pathlib import Path
import json,subprocess,os
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr8']['task']);image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
code='''
import ast
from pathlib import Path
source=ast.parse(Path('/task/tests/verify_encoder_cache.py').read_text())
worker=next(ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='WORKER_CODE' for t in n.targets))
ns={'__name__':'lookahead_probe'};exec(worker,ns)
from types import SimpleNamespace
from vllm.sampling_params import SamplingParams
for name in ('Scheduler','EncoderCacheManager','Request','PlaceholderRange','MultiModalFeatureSpec'):globals()[name]=ns[name]
features=[MultiModalFeatureSpec(data=None,modality='image',identifier='media',mm_position=PlaceholderRange(10,3,None))]
r=Request(request_id='request',prompt_token_ids=[1]*20,sampling_params=SamplingParams(max_tokens=1),pooling_params=None,eos_token_id=None,mm_features=features)
s=object.__new__(Scheduler);s.ec_connector=None;s.is_encoder_decoder=False;s.scheduler_config=SimpleNamespace(disable_chunked_mm_input=False)
for budget in (0,3):
 s.encoder_cache_manager=EncoderCacheManager(cache_size=3)
 print('LOOKAHEAD',budget,Scheduler._try_schedule_encoder_inputs(s,r,8,2,budget,shift_computed_tokens=1))
'''
for case in ['base','oracle']:
 cid=None
 try:
  cid=subprocess.check_output(['docker','run','-d','--network','none','--user','root','--workdir','/app','--mount',f'type=bind,src={T},dst=/task,readonly','--entrypoint','sleep',image,'infinity'],env=env,text=True).strip()
  if case=='oracle':subprocess.run(['docker','exec','--user','agent',cid,'git','apply','/task/solution/oracle.patch'],env=env,check=True)
  p=subprocess.run(['docker','exec',cid,'python3','-I','-c',code],env=env,capture_output=True,text=True,timeout=120)
  (R/('pr8-lookahead-'+case+'.log')).write_text(p.stdout+p.stderr);print(case,p.returncode,[l for l in p.stdout.splitlines() if l.startswith('LOOKAHEAD')],flush=True)
 finally:
  if cid:subprocess.run(['docker','rm','-f',cid],env=env,capture_output=True)
