import pathlib,json,subprocess,os,sys,datetime,time,threading,hashlib
R=pathlib.Path(__file__).parent
key,tag=sys.argv[1:3];T=pathlib.Path(json.loads((R/'targets.json').read_text())[key]['task'])
cases=sys.argv[3:] or ['base','oracle']+[c['name'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']]
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
gpu=os.environ.get('REPAIR_GPU','GPU-8380fa1c-d192-a7e4-ec39-ab836d0f4fd8')
for case in cases:
 out=R/'runs'/key/tag/case
 cmd=[sys.executable,'/data/yinchen/task-hardening-20260908/run_case.py','--task',str(T),'--case',case,'--output',str(out)]
 if key=='pr17':cmd+=['--gpu-uuid',gpu]
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),key,case,'START',flush=True)
 p=subprocess.Popen(cmd,env=env)
 captured=False
 marker_captured=False
 while p.poll() is None:
  if key=='pr17' and not captured:
   trials=list(out.glob('jobs/*/*/trial.log'))
   if trials:
    name=trials[0].parent.name.lower()+'__env-main-1'
    check=subprocess.run(['docker','exec',name,'test','-f','/logs/verifier/frozen-reference-stage.txt'],env=env,capture_output=True)
    if check.returncode==0:
     log=subprocess.run(['docker','exec',name,'cat','/logs/verifier/native-build.stdout.log'],env=env,capture_output=True,text=True)
     if 'native_build_completed' in log.stdout:
      native=out/'native';native.mkdir(exist_ok=True)
      cp=subprocess.run(['docker','cp',name+':/workspace/repo/vllm/_C.abi3.so',str(native/'_C.abi3.so')],env=env,capture_output=True)
      if cp.returncode==0:
       (native/'manifest.json').write_text(json.dumps(dict(case=case,image=json.loads((T/'environment/image-manifest.json').read_text())['image_id'],source_run=str(out),sha256=hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()),indent=2));captured=True
  if key=='pr17' and case=='early-native-timing-exit' and not marker_captured:
   trials=list(out.glob('jobs/*/*/trial.log'))
   if trials:
    name=trials[0].parent.name.lower()+'__env-main-1'
    marker=subprocess.run(['docker','exec',name,'cat','/tmp/int8-native-timing-control.txt'],env=env,capture_output=True,text=True)
    if marker.returncode==0 and 'CONTROL_REACHED:early-native-timing-exit' in marker.stdout:
     (out/'curator-native-timing-control.txt').write_text(marker.stdout);marker_captured=True
  time.sleep(.25 if captured and case=='early-native-timing-exit' else 3)
 print(key,case,'EXIT',p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
