"""Drain one completed owned Harbor job before redistributing remaining controls."""
from pathlib import Path
import os,sys,json,time,signal,subprocess
R=Path(__file__).parent
pid=int(sys.argv[1]);record=R/sys.argv[2];gpu=sys.argv[3];next_cases=sys.argv[4:]
while True:
 if record.exists():
  d=json.loads(record.read_text())
  if d['status']=='execution_or_preflight_failed':raise RuntimeError(d.get('error'))
  if d['status']=='completed_result_checked':break
 time.sleep(.1)
if pid:
 cmd=Path(f'/proc/{pid}/cmdline').read_bytes()
 assert str(R/'run_matrix.py').encode() in cmd,cmd
 # Only stop the queue launcher after Harbor has finalized its result. The
 # completed job's run_case child releases its own lock normally.
 os.kill(pid,signal.SIGTERM)
time.sleep(2)
(R/('drained-'+str(pid)+'.json')).write_text(json.dumps(dict(pid=pid,completed_record=str(record),reason='Redistribute queued controls to independent free GPUs; no Harbor process interrupted.',next_cases=next_cases),indent=2))
if next_cases:
 env=dict(os.environ,REPAIR_GPU=gpu)
 subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr17','redistributed',*next_cases],env=env,check=True)
