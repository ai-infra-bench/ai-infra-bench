from pathlib import Path
import json,shutil,subprocess,difflib,hashlib,os,signal
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
# Stop only the still-waiting old-version finalization coordinator.
for p in Path('/proc').glob('[0-9]*/cmdline'):
 try:args=p.read_bytes().split(b'\0')
 except (FileNotFoundError,PermissionError):continue
 if len(args)>1 and args[0].endswith(b'python3') and args[1]==str(R/'finish_pr17.py').encode():os.kill(int(p.parent.name),signal.SIGTERM)
shutil.copytree(T,R/'before-empty-pr17')
(T/'validation/history/1.2.3-before-empty-batch-repair.json').write_bytes((T/'validation/e2e-evidence.json').read_bytes())
(T/'validation/empty-batch-launch.patch').write_bytes((T/'solution/oracle.patch').read_bytes())
p=T/'solution/oracle.patch';s=p.read_text()
# Extend the existing validation hunk in the shared quantizer; all metadata
# checks still execute before the zero-work return and no empty grid is launched.
old='+  TORCH_CHECK(output_s.dim() == 2 || output_s.is_contiguous());\n'
assert old in s
s=s.replace(old,old+'+  if (num_groups == 0) {\n+    return;\n+  }\n',1)
s=s.replace('@@ -120,14 +122,20 @@','@@ -120,14 +122,23 @@').replace('@@ -149,7 +157,8 @@','@@ -149,7 +160,8 @@').replace('@@ -198,6 +207,8 @@','@@ -198,6 +210,8 @@')
p.write_text(s)
p=T/'task.toml';p.write_text(p.read_text().replace('version = "1.2.3"','version = "1.2.4"'))
p=T/'instruction.md';s=p.read_text().replace('Work in `/workspace/repo`, rebuild', 'Empty inputs should return correctly shaped empty tensors and leave subsequent CUDA operations usable. Work in `/workspace/repo`, rebuild');p.write_text(s)
p=T/'tests/quant_boundary.py';s=p.read_text().replace('                ("epsilon-dominated", [2, 256], 128, 1e-36, 1e-38),','''                ("epsilon-dominated", [2, 256], 128, 1e-36, 1e-38),
                ("empty-leading", [0, 128], 64, 1e-10, 1.),
                ("empty-columns", [3, 0], 64, 1e-10, 1.),
                ("empty-higher-rank", [0, 3, 256], 128, 1e-10, 1.),''')
s=s.replace('        q, s = quantize(x, case["group"], case["eps"])\n        torch.cuda.synchronize()\n        result.append(dict(name=case["name"], q_shape=list(q.shape),\n                           s_shape=list(s.shape), q=q.flatten().tolist(),\n                           s=s.flatten().tolist()))', '''        health = {}
        try:
            q, s = quantize(x, case["group"], case["eps"])
            torch.cuda.synchronize()
            if x.numel() == 0:
                # An invalid zero-grid launch may surface only on later work.
                health["post_empty_sum"] = torch.ones(3, device=x.device).sum().item()
        except Exception as exc:
            raise RuntimeError(f"{case['name']}: {exc}") from exc
        result.append(dict(name=case["name"], q_shape=list(q.shape),
                           s_shape=list(s.shape), q=q.flatten().tolist(),
                           s=s.flatten().tolist(), **health))''')
s=s.replace('        label = ref["name"]\n', '        label = ref["name"]\n        if "post_empty_sum" in ref and got.get("post_empty_sum") != ref["post_empty_sum"]:\n            errors.append(label + ": subsequent CUDA work failed")\n')
p.write_text(s)
p=T/'validation/challenge/challenge_int8_quant.py';s=p.read_text();f='''
def challenge_empty_inputs():
    cases=[((0,192),96,torch.float16), ((2,0),64,torch.bfloat16),
           ((2,0,96),48,torch.float32)]
    for shape,group,dtype in cases:
        for quant in (cuda_quant,int8_utils.per_token_group_quant_int8):
            x=torch.empty(shape,device="cuda",dtype=dtype)
            q,s=quant(x,group)
            torch.cuda.synchronize()
            assert q.shape==x.shape and q.dtype==torch.int8 and q.is_cuda
            assert tuple(s.shape)==shape[:-1]+(shape[-1]//group,) and s.dtype==torch.float32 and s.is_cuda
            assert torch.ones(5,device="cuda").sum().item()==5.
    return {"shapes":len(cases),"paths":2}

'''
s=s.replace('def main() -> None:',f+'\ndef main() -> None:',1).replace('        "tiny_fp32": challenge_tiny_fp32,','        "tiny_fp32": challenge_tiny_fp32,\n        "empty_inputs": challenge_empty_inputs,',1);p.write_text(s)
p=T/'validation/ci-cases.json';d=json.loads(p.read_text());d['cases'].append(dict(name='empty-batch-launch',patch='empty-batch-launch.patch',expected_reward=0,note='Preserved former Oracle launches an empty CUDA grid for valid empty tensors, causing a subsequent CUDA operation to fail.'))
for case in d['cases']:case['patch_sha256']=hashlib.sha256((T/'validation'/case['patch']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
p=T/'validation/e2e-evidence.json';d=json.loads(p.read_text());d.update(status='validation_in_progress',validation_status='empty_input_repair_in_progress',task_version='1.2.4');p.write_text(json.dumps(d,indent=2)+'\n')
(T/'validation/final-review.md').write_text('Review in progress for v1.2.4. Subsequent real-CUDA diagnostics found that the prior Oracle launches an invalid zero-sized grid on valid empty inputs; the frozen Triton and alternative handle these inputs normally. Current Oracle, control and challenge validation must complete before approval.\n')
p=T/'validation/semantic-boundary.md';p.write_text(p.read_text()+'''\nEmpty leading dimensions, empty final dimensions and higher-rank empty inputs
must produce the existing empty output shapes without poisoning subsequent
CUDA work. The verifier checks all three with a real following CUDA operation;
the independent challenge uses different shapes and dtypes. The original
zero-grid Oracle is retained as empty-batch-launch, expected reward zero.\n''')
freeze={str(p.relative_to(T)):hashlib.sha256(p.read_bytes()).hexdigest() for p in T.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (str(p.relative_to(T)).startswith(('tests/','environment/','solution/')) or p.name in ['instruction.md','task.toml'] or (str(p.relative_to(T)).startswith('validation/') and (p.suffix in ['.patch','.py'] or p.name=='ci-cases.json')))}
(R/'pr17-v123-freeze.json').write_bytes((R/'pr17-freeze.json').read_bytes());(R/'pr17-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('frozen',len(freeze))
