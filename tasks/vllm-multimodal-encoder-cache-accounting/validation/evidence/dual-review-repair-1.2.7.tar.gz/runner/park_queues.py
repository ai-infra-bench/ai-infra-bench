"""Pause only queue launchers after native capture; their Harbor children continue."""
from pathlib import Path
import os,signal,time,json
R=Path(__file__).parent
pending=[(3027746,'runs/pr17/final-a/oracle'),(3048037,'runs/pr17/final-b/base'),(3066038,'runs/pr17/final-c/early-system-exit')]
while pending:
 for pid,relative in pending[:]:
  path=R/relative
  if (path/'native/manifest.json').exists():
   proc=Path(f'/proc/{pid}/cmdline')
   if proc.exists():
    assert str(R/'run_matrix.py').encode() in proc.read_bytes()
    os.kill(pid,signal.SIGSTOP)
    (R/('parked-'+str(pid)+'.json')).write_text(json.dumps(dict(pid=pid,case=relative,reason='Pause only the queue launcher after native capture; its active Harbor child continues normally. Completion watcher will terminate this launcher and redistribute queued cases.'),indent=2))
   pending.remove((pid,relative))
 time.sleep(.1)
