from pathlib import Path
import subprocess,os,time,json,hashlib
R=Path(__file__).parent;out=R/'pilot-pr17-alt';T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
name='vllm-int8-per-token-group-quanti__zxihjzs__env-main-1'
while True:
 p=subprocess.run(['docker','exec',name,'cat','/logs/verifier/native-build.stdout.log'],env=env,capture_output=True,text=True)
 if 'native_build_completed' in p.stdout:
  native=out/'native';native.mkdir(exist_ok=True)
  subprocess.run(['docker','cp',name+':/workspace/repo/vllm/_C.abi3.so',str(native/'_C.abi3.so')],env=env,check=True)
  (native/'manifest.json').write_text(json.dumps(dict(case='alternate-native-kernel',image=json.loads((T/'environment/image-manifest.json').read_text())['image_id'],source_run=str(out),sha256=hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()),indent=2));print('captured',native,flush=True);break
 if p.returncode:raise RuntimeError(p.stderr)
 time.sleep(3)
