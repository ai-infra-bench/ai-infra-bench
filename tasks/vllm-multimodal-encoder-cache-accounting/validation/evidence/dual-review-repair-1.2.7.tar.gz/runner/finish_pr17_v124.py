from pathlib import Path
import json,subprocess,sys,time,os,fcntl
R=Path(__file__).parent;T=Path(json.loads((R/'targets.json').read_text())['pr17']['task'])
expected={'base','oracle'}|{c['name'] for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']}
while True:
 paths=list(R.glob('runs/pr17/v124-*/*/run-record.json'))
 paths=[p for p in paths if str(p.parent) not in {a['run_root'] for a in json.loads((R/'excluded-runs.json').read_text()).get('pr17',[])}]
 records={json.loads(p.read_text())['case']:(p,json.loads(p.read_text())) for p in paths if p.exists()}
 failed={c:r.get('error') for c,(p,r) in records.items() if r['status']=='execution_or_preflight_failed'}
 if failed:raise RuntimeError(failed)
 if expected <= {c for c,(p,r) in records.items() if r['status']=='completed_result_checked'}:break
 time.sleep(5)
print('ALL PR17 CONTROLS COMPLETED',flush=True)
gpu='GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329'
for case in ['oracle','alternate-native-kernel','compatible-operator-alias','renamed-private-triton-helper','reciprocal-overflow','base','empty-batch-launch']:
 existing=R/'challenges/pr17/v124-final'/case/'record.json'
 if existing.exists():
  prior=json.loads(existing.read_text());assert prior['status']=='expected_outcome_observed' and prior['actual']==prior['expected']
  continue
 native=records[case][0].parent/'native'
 assert (native/'manifest.json').exists(),native
 cmd=[sys.executable,str(R/'run_challenge.py'),'pr17',case,'v124-final',str(native)]
 subprocess.run(cmd,env=dict(os.environ,CHALLENGE_GPU=gpu),check=True)
# All controls and challenges precede the final frozen Oracle.
subprocess.run([sys.executable,str(R/'run_matrix.py'),'pr17','v124-frozen-final','oracle'],env=dict(os.environ,REPAIR_GPU=gpu),check=True)
subprocess.run([sys.executable,str(R/'finalize.py'),'pr17'],check=True)
