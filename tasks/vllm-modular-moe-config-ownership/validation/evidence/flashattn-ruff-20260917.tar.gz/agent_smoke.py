import os,json,subprocess,importlib.metadata as metadata
import torch,vllm
import vllm.vllm_flash_attn as fa
assert os.getuid()!=0
assert vllm.__file__.startswith('/workspace/vllm/')
assert fa.__file__=='/workspace/vllm/vllm/vllm_flash_attn/__init__.py'
assert callable(fa.flash_attn_varlen_func) and callable(fa.get_scheduler_metadata)
assert metadata.version('ruff')=='0.14.0'
assert torch.cuda.get_device_capability()==(8,0)
torch.manual_seed(17)
q,k,v=[torch.randn(5,2,64,device='cuda',dtype=torch.bfloat16) for _ in range(3)]
cu=torch.tensor([0,2,5],device='cuda',dtype=torch.int32)
y=fa.flash_attn_varlen_func(q,k,v,max_seqlen_q=3,cu_seqlens_q=cu,max_seqlen_k=3,cu_seqlens_k=cu,fa_version=2)
expected=[]
for a,b in [(0,2),(2,5)]:
 qs,ks,vs=[x[a:b].float().transpose(0,1) for x in [q,k,v]]
 expected.append(((qs@ks.transpose(1,2)/8).softmax(-1)@vs).transpose(0,1))
torch.testing.assert_close(y.float(),torch.cat(expected),rtol=.02,atol=.02)
for code,expected_exit in [('x = 1\n',0),('print(undefined_name)\n',1)]:
 p=subprocess.run(['ruff','check','--isolated','--no-cache','--select','F821','-'],input=code,text=True,capture_output=True)
 assert p.returncode==expected_exit,(p.returncode,p.stdout,p.stderr)
 if expected_exit:assert 'F821' in p.stdout
p=subprocess.run(['ruff','format','--isolated','--check','-'],input='x = 1\n',text=True,capture_output=True);assert p.returncode==0,p.stderr
print(json.dumps({'uid':os.getuid(),'vllm':vllm.__file__,'flash_attention':fa.__file__,'flash_attention_real_cuda_numerics':'passed','ruff_lint_positive_and_negative':'passed','ruff_format':'passed','packages':{k:metadata.version(k) for k in ['torch','pytest','pluggy','iniconfig','tblib','packaging','ruff']},'gpu':torch.cuda.get_device_name()},indent=2))
