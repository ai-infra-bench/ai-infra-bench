#!/usr/bin/env bash
set -euo pipefail
cd /workspace/vllm
git apply /solution/oracle.patch

tar -xzf /solution/untracked.tar.gz -C /workspace/vllm
