#!/usr/bin/env bash
set -euo pipefail
git apply --check /solution/ci-case.patch
git apply /solution/ci-case.patch
