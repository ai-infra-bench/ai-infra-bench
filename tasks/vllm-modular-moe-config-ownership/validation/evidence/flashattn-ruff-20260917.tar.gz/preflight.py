from pathlib import Path
import json,subprocess,hashlib,re
REPO=Path('/data/jiabei/infrabench/ai-infra-bench');ROOT=Path('/tmp/pr76-flashattn-ruff');TASK=REPO/'tasks/vllm-modular-moe-config-ownership';IMAGE='ai-infra-bench/vllm-modular-moe-config-ownership:flashattn-ruff-1.2.10'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,cmd):
 (ROOT/(name+'.command.json')).write_text(json.dumps(cmd,indent=2))
 with (ROOT/name).open('w') as log:r=subprocess.run(cmd,cwd=REPO,stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:print((ROOT/name).read_text()[-5000:]);raise SystemExit(r.returncode)
image=json.loads((ROOT/'image-inspect.json').read_text())[0]
p=TASK/'environment/lock/manifest.json';d=json.loads(p.read_text());d['output']['sha256']=sha(TASK/'environment/lock/requirements.txt');p.write_text(json.dumps(d,indent=2)+'\n')
p=TASK/'environment/image-manifest.json';d=json.loads(p.read_text());d.update(image_id=image['Id'],image_tag=IMAGE,created=image['Created'],size_bytes=image['Size'],repo_digests=image.get('RepoDigests') or [],dockerfile_sha256=sha(TASK/'environment/Dockerfile'),dependency_lock_sha256=sha(TASK/'environment/lock/requirements.txt'),dependency_lock_manifest_sha256=sha(TASK/'environment/lock/manifest.json'),image_check='pending',build_notes='Built from task Dockerfile, restoring hash-locked FlashAttention Python package files from the existing v0.12.0 base and installing Ruff 0.14.0 with --no-deps --require-hashes. Native overlay and target source unchanged. Host build network with a loopback-only Git daemon serving validated Base history; no verifier or solution files in image.')
p.write_text(json.dumps(d,indent=2)+'\n')
p=TASK/'task.toml';s=p.read_text();s=re.sub(r'image_digest = "sha256:[0-9a-f]+"',f'image_digest = "{image["Id"]}"',s);p.write_text(s)
run('image-check.json',['python3','.github/scripts/task_ci.py','image-check','--task',TASK.name,'--image',IMAGE])
run('agent-smoke.log',['docker','run','--rm','--network','none','--gpus','device=0','--cpus','8','--memory','32g','-v',str(ROOT/'agent_smoke.py')+':/tmp/agent-smoke.py:ro',IMAGE,'python3','/tmp/agent-smoke.py'])
run('agent-pytest-collection.log',['docker','run','--rm','--network','none','--gpus','device=0','--cpus','8','--memory','32g',IMAGE,'python3','-m','pytest','--collect-only','-q','tests/kernels/moe/test_moe.py','tests/kernels/moe/test_modular_kernel_combinations.py','tests/kernels/moe/test_cutlass_moe.py'])
nodes=[f'tests/kernels/moe/test_moe.py::test_fused_moe[8192-False-dtype0-1-2-8-{shape}]' for shape in ['1-128-128','1-2048-128','33-2048-128','32768-2048-511','40000-1024-1024']]
run('agent-upstream-numerics.log',['docker','run','--rm','--network','none','--gpus','device=0','--cpus','8','--memory','32g',IMAGE,'python3','-m','pytest','-q',*nodes])
p=TASK/'environment/image-manifest.json';d=json.loads(p.read_text());d['image_check']='passed';p.write_text(json.dumps(d,indent=2)+'\n')
run('repository-validation.log',['python3','.github/scripts/task_ci.py','validate',TASK.name])
files={str(p.relative_to(TASK)):sha(p) for p in TASK.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (str(p.relative_to(TASK)).startswith(('environment/','tests/','solution/')) or p.name in ['instruction.md','task.toml','test_stage_reporting.py'] or p.suffix=='.patch' or 'challenge' in p.parts)}
(ROOT/'task-inputs-before.json').write_text(json.dumps(files,indent=2))
run('harbor-driver.log',['python3',str(ROOT/'validate.py')])
