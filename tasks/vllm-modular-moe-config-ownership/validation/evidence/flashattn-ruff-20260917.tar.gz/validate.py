from pathlib import Path
import subprocess,os,json,hashlib,shutil,concurrent.futures,datetime
REPO=Path('/data/jiabei/infrabench/ai-infra-bench');ROOT=Path('/tmp/pr76-flashattn-ruff')
TASK=REPO/'tasks/vllm-modular-moe-config-ownership'
IMAGE='ai-infra-bench/vllm-modular-moe-config-ownership:flashattn-ruff-1.2.10'
CAMPAIGN=REPO/'runs/vllm-modular-moe-config-ownership/codex-gpt-6-astra-20260917-200534'
GPUS=['GPU-4d1fbe26-f8a4-5869-e826-3143f1425f75','GPU-80425545-47ae-bd24-9051-ba17a38ce9f8','GPU-3815a178-ad22-4b81-5669-0533760a7e6b']
CASES=[('base',0),('early-exit-system-exit',0),('early-exit-os-exit',0),('alternate-consumer-full-pipeline',1),('rollout-r1',1),('rollout-r2',0),('rollout-r3',1),('wrong-legacy-owner',0),('oracle',1)]
def prepare(name):
 output=ROOT/'cases'/name
 source_case='oracle' if name.startswith('rollout-') else name
 cmd=['python3','.github/scripts/task_ci.py','prepare-case','--task',TASK.name,'--image',IMAGE,'--case',source_case,'--output',str(output)]
 agent=subprocess.check_output(cmd,cwd=REPO,text=True).strip()
 if name.startswith('rollout-'):
  patch=CAMPAIGN/'trials'/name.replace('rollout','codex')/'final.patch'
  shutil.copy2(patch,output/'solution/oracle.patch')
  shutil.copy2(patch.parent/'untracked.tar.gz',output/'solution/untracked.tar.gz')
  solve=output/'solution/solve.sh'
  solve.write_text(solve.read_text()+'\ntar -xzf /solution/untracked.tar.gz -C /workspace/vllm\n')
 return agent,output

def run_one(item,gpu):
 name,expected=item
 agent,path=prepare(name)
 config={'job_name':name,'jobs_dir':str(ROOT/'jobs'),'n_concurrent_trials':1,
 'environment':{'import_path':'local_nvidia_docker:LocalNvidiaDockerEnvironment','force_build':False,'delete':True,'kwargs':{'gpu_uuid':GPUS[gpu]}},
 'agents':[{'name':agent}],'tasks':[{'path':str(path)}]}
 cp=ROOT/f'harbor-config-{name}.json';cp.write_text(json.dumps(config,indent=2))
 frozen={str(p.relative_to(path)):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 (ROOT/f'inputs-{name}.json').write_text(json.dumps(frozen,indent=2))
 cmd=['/data/jiabei/infrabench/.harbor-venv/bin/harbor','run','--config',str(cp),'--yes']
 env=dict(os.environ,PYTHONPATH='/tmp/pr76-workspace-migration/runtime-tools',DOCKER_CONFIG='/data/jiabei/infrabench/.docker')
 print('START',name,flush=True)
 with (ROOT/f'harbor-{name}.log').open('w') as log:ret=subprocess.run(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
 result=ROOT/'jobs'/name/'result.json'
 check=subprocess.run(['python3','.github/scripts/task_ci.py','check-result','--result',str(result),'--expected-reward',str(expected)],cwd=REPO,text=True,capture_output=True)
 reports=list((ROOT/'jobs'/name).glob('*/verifier/report.json'))
 report=json.loads(reports[0].read_text()) if reports else None
 row={'case':name,'expected_reward':expected,'exit':ret.returncode,'check_exit':check.returncode,'check_output':check.stdout+check.stderr,'command':cmd,'report':report,'result':json.loads(result.read_text()) if result.exists() else None,'inputs_unchanged':all(hashlib.file_digest((path/p).open('rb'),'sha256').hexdigest()==v for p,v in frozen.items())}
 (ROOT/f'result-{name}.json').write_text(json.dumps(row,indent=2))
 print('END',name,'exit',ret.returncode,'check',check.returncode,'passed',report['stages_passed'] if report else None,flush=True)
 if ret.returncode or check.returncode:raise RuntimeError(f'{name}: {check.stdout} {check.stderr}')
 if name == 'rollout-r2':
  assert len(report['stages_passed'])==6 and report['failed_stage']=='flashinfer_prepare_expert_finalize' and report['stages_not_run']==[]
 if expected==1:assert len(report['stages_passed'])==7 and report['failed_stage'] is None and report['stages_not_run']==[]
 if name.startswith('early-exit'):assert report['stages_passed']==[] and len(report['stages_not_run'])==7 and report['failed_stage'] is None
 return row
results=[]
for start in [0,3,6]:
 batch=CASES[start:min(start+3,8)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  results.extend(list(pool.map(lambda pair:run_one(pair[1],pair[0]),enumerate(batch))))
 (ROOT/'harbor-results.json').write_text(json.dumps(results,indent=2))
# Final Oracle acceptance after all other frozen-input integration checks.
results.append(run_one(CASES[-1],0))
(ROOT/'harbor-results.json').write_text(json.dumps(results,indent=2))
