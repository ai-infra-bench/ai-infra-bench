from pathlib import Path
import json,hashlib,shutil
T=Path('/data/jiabei/infrabench/ai-infra-bench/tasks/vllm-modular-moe-config-ownership');R=Path('/tmp/pr76-flashattn-ruff')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
wheel=next((R/'wheels').glob('ruff*.whl'))
f=T/'environment/lock/test-requirements.txt';f.write_text(f.read_text()+f'ruff==0.14.0 --hash=sha256:{h(wheel)}\n')
f=T/'environment/lock/flash-attn-python.sha256';f.write_text('''e27ac4a87e52384ce7099358cb2d822cc108daddb08a1630eb84902e0c92467f  __init__.py
5983d81237dc6c53109a7a46311ca6fcc3b75e75138dcbd8c23bc365b381bc82  flash_attn_interface.py
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  layers/__init__.py
b826cc3339488815b26f974135a8f53d44149d019b4c82e1ad4240a6ec0e28c4  layers/rotary.py
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  ops/__init__.py
01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b  ops/triton/__init__.py
f1f4bf9a0b28cc544fa882b60628d74b8923e8b47e1f8438a7af43fa7b5061e4  ops/triton/rotary.py
''')
f=T/'environment/Dockerfile';s=f.read_text().replace('    && python3 -m pytest --version \\\n','    && python3 -m pytest --version \\\n    && ruff --version \\\n')
block='''# Restore the Python package installed alongside FlashAttention's native modules.
# These files come from the existing digest-pinned base, never the newer donor.
COPY lock/flash-attn-python.sha256 /tmp/flash-attn-python.sha256
RUN set -eux; \\
    FLASH_ATTN_SITE="$(python3 -c 'import importlib.metadata as m; print(m.distribution("vllm").locate_file("vllm/vllm_flash_attn"))')"; \\
    cd "${FLASH_ATTN_SITE}"; \\
    test "$(wc -l < /tmp/flash-attn-python.sha256)" = 7; \\
    sha256sum -c /tmp/flash-attn-python.sha256; \\
    while read -r expected rel; do \\
        case "${rel}" in *.py) ;; *) exit 1 ;; esac; \\
        case "${rel}" in /*|../*|*/../*) exit 1 ;; esac; \\
        test -f "${rel}"; \\
        test ! -L "${rel}"; \\
        install -D -m 0644 "${rel}" "/workspace/vllm/vllm/vllm_flash_attn/${rel}"; \\
    done < /tmp/flash-attn-python.sha256; \\
    cd /workspace/vllm/vllm/vllm_flash_attn; \\
    sha256sum -c /tmp/flash-attn-python.sha256; \\
    test -z "$(git -C /workspace/vllm -c safe.directory=/workspace/vllm status --porcelain=v1 --untracked-files=all)"; \\
    rm /tmp/flash-attn-python.sha256

'''
s=s.replace('USER agent\nWORKDIR /workspace/vllm',block+'USER agent\nWORKDIR /workspace/vllm');f.write_text(s)
f=T/'environment/lock/manifest.json';d=json.loads(f.read_text());d['byte_locks'].append('flash-attn-python.sha256');d['extra_wheels'].append({'name':'ruff','version':'0.14.0','sha256':h(wheel),'filename':wheel.name});d['test_tooling']['sha256']=h(T/'environment/lock/test-requirements.txt');d['flash_attention_python']={'source':'existing digest-pinned v0.12.0 base image','source_path':'site-packages/vllm/vllm_flash_attn','destination':'/workspace/vllm/vllm/vllm_flash_attn','manifest':'environment/lock/flash-attn-python.sha256','sha256':h(T/'environment/lock/flash-attn-python.sha256'),'files':7,'policy':'Restore packaged Python modules only; do not replace native donor binaries or add new dependency versions.'};f.write_text(json.dumps(d,indent=2)+'\n')
f=T/'task.toml';f.write_text(f.read_text().replace('version = "1.2.9"','version = "1.2.10"'))
shutil.copy2(R/'prior-e2e-evidence.json',T/'validation/history/before-flashattn-ruff-20260917.json')
f=T/'environment/lock/README.md';s=f.read_text();s=s.replace('Current v1.2.9 adds general test tooling', 'Historical v1.2.9 added general test tooling',1);f.write_text('Current v1.2.10 restores the seven FlashAttention Python package files from the existing digest-pinned v0.12.0 base image into the checkout, verified by `flash-attn-python.sha256`. Native libraries remain unchanged. Ruff 0.14.0 matches the Base pre-commit configuration and is installed from its exact wheel hash with `--no-deps`. See `validation/flashattn-ruff.md` for executed validation.\n\n'+s)
print('ruff wheel',wheel.name,h(wheel))
