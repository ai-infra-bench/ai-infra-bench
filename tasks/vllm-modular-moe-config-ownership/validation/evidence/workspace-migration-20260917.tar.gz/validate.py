import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path('/data/jiabei/infrabench/ai-infra-bench')
ROOT = Path('/tmp/pr76-workspace-migration')
TASK = 'vllm-modular-moe-config-ownership'
IMAGE = 'ai-infra-bench/vllm-modular-moe-config-ownership:workspace-vllm-1.2.8'
HARBOR = '/data/jiabei/infrabench/.harbor-venv/bin/harbor'
CASES = [
    ('base', 0),
    ('early-exit-system-exit', 0),
    ('early-exit-os-exit', 0),
    ('wrong-legacy-owner', 0),
    ('alternate-consumer-full-pipeline', 1),
    ('oracle', 1),
]


def main():
    results = []
    for name, expected in CASES:
        case_dir = ROOT / 'cases' / name
        prepare = [sys.executable, '.github/scripts/task_ci.py', 'prepare-case',
                   '--task', TASK, '--image', IMAGE, '--case', name,
                   '--output', str(case_dir)]
        agent = subprocess.check_output(prepare, cwd=REPO, text=True).strip()
        config = {
            'job_name': name, 'jobs_dir': str(ROOT / 'jobs'),
            'n_concurrent_trials': 1,
            'environment': {
                'import_path': 'local_nvidia_docker:LocalNvidiaDockerEnvironment',
                'force_build': False, 'delete': True,
                'kwargs': {'gpu_uuid': 'GPU-4d1fbe26-f8a4-5869-e826-3143f1425f75'},
            },
            'agents': [{'name': agent}],
            'tasks': [{'path': str(case_dir)}],
        }
        config_path = ROOT / f'harbor-config-{name}.json'
        config_path.write_text(json.dumps(config, indent=2) + '\n')
        cmd = [HARBOR, 'run', '--config', str(config_path), '--yes']
        env = dict(os.environ, PYTHONPATH=str(ROOT / 'runtime-tools'),
                   DOCKER_CONFIG=str(ROOT / 'docker-config'))
        print(f'START {name} expected_reward={expected}', flush=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (ROOT / f'harbor-{name}.log').open('w') as log:
            run = subprocess.run(cmd, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
        result_path = ROOT / 'jobs' / name / 'result.json'
        check_cmd = [sys.executable, '.github/scripts/task_ci.py', 'check-result',
                     '--result', str(result_path), '--expected-reward', str(expected)]
        check = subprocess.run(check_cmd, cwd=REPO, text=True, capture_output=True)
        record = dict(case=name, expected_reward=expected, command=cmd,
                      prepare_command=prepare, started_at=started,
                      finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      exit_code=run.returncode, check_exit_code=check.returncode,
                      check_output=check.stdout + check.stderr,
                      result_path=str(result_path))
        if result_path.exists():
            record['result'] = json.loads(result_path.read_text())
        results.append(record)
        (ROOT / 'harbor-results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(f'END {name} exit={run.returncode} check={check.returncode} {check.stdout}{check.stderr}', flush=True)
        if run.returncode or check.returncode:
            raise SystemExit(1)


if __name__ == '__main__':
    main()
