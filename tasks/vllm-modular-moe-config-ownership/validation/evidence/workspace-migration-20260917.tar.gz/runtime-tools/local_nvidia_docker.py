"""Local single-GPU Docker environment for InfraBench GPU validation.

This module lives OUTSIDE any task repository (constraint 7) and is loaded by
Harbor 0.22.0 via the ``import_path`` mechanism
(``harbor.environments.factory.EnvironmentFactory.create_environment_from_import_path``,
format ``module:ClassName``).

It subclasses the stock ``DockerEnvironment`` and does exactly one thing on top
of it: append a Compose overlay that pins the ``main`` service to ONE explicit,
pre-audited NVIDIA GPU UUID via
``services.main.deploy.resources.reservations.devices``.

Design constraints honored:

* The GPU is bound by UUID with ``device_ids: ["GPU-...."]`` — never
  ``count: all`` / ``--gpus all`` (constraint 3). A strict UUID format check
  refuses anything that is not a canonical ``GPU-<uuid>`` string.
* The task's own ``gpus`` declaration is untouched; we only add a device
  reservation overlay, we never rewrite the task compose, Dockerfile, or
  task.toml (constraints 1, 2).
* We never request ``count`` and never fall back to CPU. If the UUID is
  missing or malformed construction fails loudly (constraint 2, 12).
* The overlay is the LAST compose file, so it wins over any earlier
  ``deploy`` block for ``main`` while leaving every other service and every
  other field intact.

The single required UUID is supplied through the ``gpu_uuid`` constructor
kwarg (threaded from the trial environment config ``kwargs`` block) or, as a
fallback, the ``HARBOR_LOCAL_GPU_UUID`` environment variable.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path
from typing import override

from harbor.constants import MAIN_SERVICE_NAME
from harbor.environments.capabilities import EnvironmentCapabilities
from harbor.environments.docker.docker import DockerEnvironment

# Canonical form printed by ``nvidia-smi --query-gpu=gpu_uuid``:
# "GPU-" followed by a standard 8-4-4-4-12 hex UUID.
_GPU_UUID_RE = re.compile(
    r"^GPU-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)


def _validate_gpu_uuid(value: object) -> str:
    """Return a validated canonical GPU UUID string or raise ``ValueError``.

    Refuses ``None``, empty strings, ``"all"``, integer counts, and anything
    that is not a canonical ``GPU-<uuid>`` token. This is what keeps us from
    ever silently degrading to ``--gpus all`` or a CPU fallback.
    """
    if not isinstance(value, str):
        raise ValueError(
            "LocalNvidiaDockerEnvironment requires an explicit GPU UUID string; "
            f"got {type(value).__name__}."
        )
    candidate = value.strip()
    if not _GPU_UUID_RE.match(candidate):
        raise ValueError(
            "LocalNvidiaDockerEnvironment requires a single canonical NVIDIA GPU "
            "UUID of the form 'GPU-XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX' "
            "(never 'all', never a count). "
            f"Got: {candidate!r}."
        )
    return candidate


class LocalNvidiaDockerEnvironment(DockerEnvironment):
    """DockerEnvironment that binds the ``main`` service to one GPU UUID."""

    def __init__(self, *args, gpu_uuid: str | None = None, **kwargs):
        resolved = gpu_uuid if gpu_uuid is not None else os.environ.get(
            "HARBOR_LOCAL_GPU_UUID"
        )
        # Fail loudly at construction if the UUID is absent or malformed.
        self._gpu_uuid = _validate_gpu_uuid(resolved)
        # Initialize overlay slots BEFORE super().__init__ so the overridden
        # _docker_compose_paths property is safe if touched during base init.
        self._gpu_compose_temp_dir: tempfile.TemporaryDirectory[str] | None = None
        self._gpu_compose_path: Path | None = None
        super().__init__(*args, **kwargs)

    @property
    def _uses_compose(self) -> bool:
        # Current Harbor also has a raw Docker path; GPU overlays require Compose.
        return True

    @property
    def gpu_uuid(self) -> str:
        return self._gpu_uuid

    @property
    @override
    def capabilities(self) -> EnvironmentCapabilities:
        # Inherit every stock Docker capability, then advertise GPU allocation
        # so BaseEnvironment._validate_gpu_support accepts a task with gpus > 0.
        # The actual binding is a single-UUID device reservation (see the
        # overlay below); we never enable "all GPUs".
        base_caps = super().capabilities
        return base_caps.model_copy(update={"gpus": True})

    def _write_gpu_compose_file(self) -> Path:
        """Write a Compose overlay reserving exactly one GPU by UUID."""
        self._cleanup_gpu_compose_file()
        self._gpu_compose_temp_dir = tempfile.TemporaryDirectory()
        path = Path(self._gpu_compose_temp_dir.name) / "docker-compose-local-gpu.json"
        compose = {
            "services": {
                MAIN_SERVICE_NAME: {
                    "deploy": {
                        "resources": {
                            "reservations": {
                                "devices": [
                                    {
                                        "driver": "nvidia",
                                        # Bind ONE specific card by UUID. No
                                        # "count", so Compose never expands this
                                        # to "all available GPUs".
                                        "device_ids": [self._gpu_uuid],
                                        "capabilities": ["gpu"],
                                    }
                                ]
                            }
                        }
                    }
                }
            }
        }
        path.write_text(json.dumps(compose, indent=2))
        self._gpu_compose_path = path
        return path

    def _cleanup_gpu_compose_file(self) -> None:
        if self._gpu_compose_temp_dir is None:
            return
        try:
            self._gpu_compose_temp_dir.cleanup()
        except OSError as e:
            self.logger.debug(f"Failed to remove local-gpu compose file: {e}")
        finally:
            self._gpu_compose_temp_dir = None
            self._gpu_compose_path = None

    @property
    @override
    def _docker_compose_paths(self) -> list[Path]:
        # Take the stock list and append the GPU overlay LAST so it wins the
        # merge for services.main.deploy while leaving all other files intact.
        paths = super()._docker_compose_paths
        if self._gpu_compose_path is not None:
            paths.append(self._gpu_compose_path)
        return paths

    @override
    async def start(self, force_build: bool):
        # Materialize the GPU overlay before the base start() enumerates
        # compose files for build / up.
        self._gpu_compose_path = self._write_gpu_compose_file()
        await super().start(force_build)

    @override
    async def stop(self, delete: bool):
        try:
            await super().stop(delete)
        finally:
            self._cleanup_gpu_compose_file()
