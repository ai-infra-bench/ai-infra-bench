import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/data/jiabei/infrabench/ai-infra-bench')
TASK = REPO / 'tasks/vllm-modular-moe-config-ownership'
ROOT = Path('/tmp/pr76-workspace-migration')
IMAGE = 'ai-infra-bench/vllm-modular-moe-config-ownership:workspace-vllm-1.2.8'


def run(name, command):
    completed = subprocess.run(command, cwd=REPO, capture_output=True, text=True)
    (ROOT / name).write_text(completed.stdout + completed.stderr)
    completed.check_returncode()
    return completed.stdout


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


inspection = json.loads(run('image-inspect.json', ['docker', 'image', 'inspect', IMAGE]))[0]
assert inspection['Config']['WorkingDir'] == '/workspace/vllm'
assert inspection['Config']['User'] == 'agent'
assert 'PYTHONPATH=/workspace/vllm' in inspection['Config']['Env']
run('image-history.txt', ['docker', 'history', '--no-trunc', IMAGE])
run('image-check.json', ['python3', '.github/scripts/task_ci.py', 'image-check',
                        '--task', TASK.name, '--image', IMAGE])
smoke = '''import json, os, pathlib, torch, vllm
import vllm._custom_ops
import vllm.model_executor.layers.fused_moe.modular_kernel as modular
assert os.getcwd() == '/workspace/vllm'
assert os.getuid() != 0
assert not pathlib.Path('/workspace/repo').exists()
assert vllm.__file__.startswith('/workspace/vllm/vllm/')
assert modular.__file__.startswith('/workspace/vllm/vllm/')
assert torch.cuda.get_device_capability(0) == (8, 0)
assert torch.ones(4, device='cuda').sum().item() == 4
print(json.dumps(dict(workdir=os.getcwd(), uid=os.getuid(), vllm=vllm.__file__,
                     modular=modular.__file__, gpu=torch.cuda.get_device_name(0))))
'''
run('agent-smoke.log', ['docker', 'run', '--rm', '--network', 'none', '--gpus',
                       'device=0', '--cpus', '8', '--memory', '32g', IMAGE,
                       'python3', '-c', smoke])
manifest = json.loads((ROOT / 'image-manifest.json').read_text())
manifest.update(
    created=inspection['Created'], image_id=inspection['Id'], image_tag=IMAGE,
    repo_digests=inspection.get('RepoDigests') or [], size_bytes=inspection['Size'],
    dockerfile_sha256=sha(TASK / 'environment/Dockerfile'),
    build_notes='Rebuilt from the task Dockerfile after moving the source to /workspace/vllm, using DOCKER_BUILDKIT=0 and --network host. VLLM_REPOSITORY=git://127.0.0.1:19476/repo served the exact Base-only history read-only from the prior validated image (sha256:9518dc795c5704544809a151be898b7150391a1613bcfc8fefd42a16564e1378), bound to host loopback. The source archive and seven native libraries retain their pinned hashes. The repository image check and no-network agent-user A100 import/allocation smoke passed.',
    image_check='passed', status='built',
)
(TASK / 'environment/image-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
config_path = TASK / 'task.toml'
config_path.write_text(config_path.read_text().replace(
    'sha256:9518dc795c5704544809a151be898b7150391a1613bcfc8fefd42a16564e1378',
    inspection['Id']))
print(json.dumps(dict(image_id=inspection['Id'], image_check='passed', agent_smoke='passed')))
