import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

REPO = Path('/data/jiabei/infrabench/ai-infra-bench')
TASK = REPO / 'tasks/vllm-modular-moe-config-ownership'
ROOT = Path('/tmp/pr76-workspace-migration')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


results = load(ROOT / 'harbor-results.json')
assert len(results) == 6
for row in results:
    assert row['exit_code'] == row['check_exit_code'] == 0, row['case']
    stats = row['result']['stats']
    assert stats['n_completed_trials'] == 1 and stats['n_errored_trials'] == 0
    job = ROOT / 'jobs' / row['case']
    reports = list(job.glob('*/verifier/report.json'))
    assert len(reports) == 1, (row['case'], reports)
    report = load(reports[0])
    row['verifier_report'] = report
    if row['expected_reward'] == 1:
        assert report['completed'] and len(report['stages_passed']) == 7
    if row['case'].startswith('early-exit-'):
        expected = 'EARLY_OS_EXIT_REACHED' if row['case'].endswith('os-exit') else 'EARLY_SYSTEM_EXIT_REACHED'
        logs = '\n'.join(p.read_text(errors='replace') for p in job.glob('*/verifier/*.txt'))
        assert expected in logs, row['case']

archive = TASK / 'validation/evidence/workspace-migration-20260917.tar.gz'
inputs = [p for p in ROOT.iterdir() if p.is_file() and p.name != 'image-inspect.json']
inputs.append(ROOT / 'runtime-tools/local_nvidia_docker.py')
for job in (ROOT / 'jobs').iterdir():
    inputs.extend(p for p in job.rglob('*') if p.is_file()
                  and 'artifacts' not in p.relative_to(job).parts
                  and p.suffix in {'.json', '.txt', '.log', '.yaml'})
with tarfile.open(archive, 'w:gz') as bundle:
    for path in sorted(set(inputs)):
        bundle.add(path, arcname=path.relative_to(ROOT), recursive=False)

files = {}
for path in sorted(TASK.rglob('*')):
    relative = path.relative_to(TASK).as_posix()
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    if (relative in ['.dockerignore', 'instruction.md', 'task.toml', 'validation/ci-cases.json']
            or relative.startswith(('environment/', 'solution/', 'tests/'))
            or relative.startswith('validation/challenge/')
            or (relative.startswith('validation/') and path.suffix == '.patch')):
        files[relative] = sha(path)

revision = load(ROOT / 'revision.json')
manifest = load(TASK / 'environment/image-manifest.json')
evidence = {
    'schema_version': 'vllm_harbor_task_validation.v1',
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'workspace-migration-validated',
    'task': 'ai-infra-bench/vllm-modular-moe-config-ownership',
    'task_version': '1.2.8',
    'scope': 'Directory migration only. This is a scoped regression validation, not a new three-gate task review or a rerun of the complete historical control/challenge matrix.',
    'workspace': {'repository': '/workspace/vllm', 'artifacts': ['/workspace/vllm/vllm'], 'pythonpath': '/workspace/vllm'},
    'source': load(ROOT / 'e2e-evidence.json')['source'],
    'image': manifest,
    'revision': revision,
    'historical_evidence': {'path': 'validation/history/before-workspace-migration-20260917.json',
                            'sha256': sha(TASK / 'validation/history/before-workspace-migration-20260917.json'),
                            'note': 'Preserved byte-for-byte. Its image identity, paths, rewards and full-review conclusions refer to v1.2.7.'},
    'artifacts': {'files': files},
    'static_checks': ['repository task validator passed', 'Python and shell syntax passed', 'runtime path consistency passed', 'git diff --check passed'],
    'environment_checks': {'image_check': load(ROOT / 'image-check.json'),
                           'agent_smoke': (ROOT / 'agent-smoke.log').read_text(),
                           'agent_network': 'none', 'agent_user': 'agent', 'accelerator': 'A100',
                           'image_history_log': 'image-history.txt'},
    'build': {'command': 'DOCKER_BUILDKIT=0 docker build --network host --build-arg VLLM_REPOSITORY=git://127.0.0.1:19476/repo --tag ai-infra-bench/vllm-modular-moe-config-ownership:workspace-vllm-1.2.8 --file tasks/vllm-modular-moe-config-ownership/environment/Dockerfile tasks/vllm-modular-moe-config-ownership/environment',
              'exit_code': 0, 'log': 'build-retry.log',
              'initial_setup_failure': 'The bridge-published local Git service reset its connection; build.log records exit 128. Retried with a loopback-only host-network Git daemon; no Dockerfile or source contract change was needed.'},
    'harbor_version': subprocess.check_output(['/data/jiabei/infrabench/.harbor-venv/bin/harbor', '--version'], text=True).strip(),
    'harbor_runner': {
        'adapter': 'runtime-tools/local_nvidia_docker.py',
        'adapter_sha256': sha(ROOT / 'runtime-tools/local_nvidia_docker.py'),
        'adapter_source': '/data/yinchen/harbor-local-gpu-v022/local_nvidia_docker.py',
        'adapter_change': 'Force the current Harbor Compose execution path so the existing explicit single-GPU UUID overlay is applied to agent and verifier containers.',
        'gpu_uuid': 'GPU-4d1fbe26-f8a4-5869-e826-3143f1425f75',
        'compose_version': 'v2.39.4',
        'compose_sha256': sha(ROOT / 'docker-config/cli-plugins/docker-compose'),
        'environment': {'PYTHONPATH': str(ROOT / 'runtime-tools'), 'DOCKER_CONFIG': str(ROOT / 'docker-config')},
        'setup_failures': [
            {'record': 'setup-failed-results.json', 'reason': 'Default Docker backend did not advertise GPU support; no test executed.'},
            {'record': 'setup-failed-compose-results.json', 'reason': 'Docker Compose was not discoverable in the default Docker configuration; no test executed.'},
        ],
    },
    'harbor_runs': results,
    'raw_evidence': {'path': str(archive.relative_to(TASK)), 'sha256': sha(archive), 'size_bytes': archive.stat().st_size},
    'freeze_note': 'All executable files, the rebuilt image manifest and task image digest were frozen before Harbor runs. Subsequent evidence/report writes do not change executable hashes; prepared Harbor task copies additionally set environment.docker_image to the validated local tag.',
    'git_state': 'Local uncommitted changes on tasks/vllm-modular-moe-config-ownership-opus5-review; no commit, push or PR update.',
}
(TASK / 'validation/e2e-evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
lines = [
    '# Workspace migration validation', '',
    'Task v1.2.8 uses `/workspace/vllm` as the repository root and `PYTHONPATH`, with `/workspace/vllm/vllm` as the collected Python package artifact. The instruction, Dockerfile, task metadata, solution entrypoint, verifier import/working directory and challenge instructions were updated together. Task behavior and test assertions are unchanged.', '',
    f'The image was rebuilt from the updated Dockerfile: `{manifest["image_tag"]}`, ID `{manifest["image_id"]}`. The repository image check passed; the agent user imported the checkout from the new path and allocated CUDA tensors on A100 with networking disabled. The old repository path is absent.', '',
    'Repository validation, path consistency, Python/Shell syntax and diff whitespace checks passed. Six complete Harbor trials exercised artifact collection and the separate verifier at the new paths:', '',
    '| Case | Expected reward | Actual reward | Harbor errors |',
    '|---|---:|---:|---:|',
]
for row in results:
    lines.append(f'| {row["case"]} | {row["expected_reward"]} | {row["expected_reward"]} | 0 |')
lines += ['',
    'Oracle and the correct alternative completed all seven behavioral groups. Both early-exit controls reached their explicit import markers and received reward 0. This validates the path migration; the complete historical control/challenge matrix and three-gate review were not rerun.', '',
    'The local Harbor runner uses the existing NVIDIA Docker adapter with one explicit A100 UUID and a Compose plugin. Two initial runner setup failures (GPU capability declaration and missing Compose discovery) are preserved separately; neither executed task tests or counts as a behavioral result. The adapter only supplies hardware and selects the Compose execution path.', '',
    'The previous v1.2.7 evidence is preserved byte-for-byte in `history/before-workspace-migration-20260917.json`. Historical logs and trajectories retain their original paths and results. Current executable hashes, commands, image identity, trial results and raw evidence archive are recorded in `e2e-evidence.json`.', '',
    'Changes are local and uncommitted. No commit, push or PR update was performed.', '',
]
(TASK / 'validation/workspace-migration.md').write_text('\n'.join(lines))
print(json.dumps({'image_id': manifest['image_id'], 'trials': len(results), 'errors': 0, 'evidence_archive': str(archive)}))
