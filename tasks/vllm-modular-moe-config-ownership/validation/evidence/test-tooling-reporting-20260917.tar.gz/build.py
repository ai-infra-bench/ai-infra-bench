from pathlib import Path
import subprocess,os,json
r=Path('/tmp/pr76-experience');repo=Path('/data/jiabei/infrabench/ai-infra-bench')
image='ai-infra-bench/vllm-modular-moe-config-ownership:test-tooling-1.2.9'
name='pr76-pytest-git-source'
cmd=['docker','run','-d','--name',name,'--network','host','--user','root','--entrypoint','bash','sha256:e794462b0e49f6c58ef94f69d01a09c9f2aa6b8fd71efa1330bb826ba006a712','-lc','ln -s /workspace/vllm /repo && git config --global --add safe.directory /workspace/vllm && exec git daemon --reuseaddr --export-all --base-path=/ --listen=127.0.0.1 --port=19476 /repo']
subprocess.run(cmd,check=True)
try:
 command=['docker','build','--network','host','--build-arg','VLLM_REPOSITORY=git://127.0.0.1:19476/repo','--tag',image,'--file','tasks/vllm-modular-moe-config-ownership/environment/Dockerfile','tasks/vllm-modular-moe-config-ownership/environment']
 (r/'build-command.json').write_text(json.dumps(command,indent=2))
 with (r/'build.log').open('w') as log:
  result=subprocess.run(command,cwd=repo,env=dict(os.environ,DOCKER_BUILDKIT='0'),stdout=log,stderr=subprocess.STDOUT)
 print('build_exit',result.returncode,flush=True)
 if result.returncode:print((r/'build.log').read_text()[-3500:]);raise SystemExit(result.returncode)
 (r/'image-inspect.json').write_text(subprocess.check_output(['docker','image','inspect',image],text=True))
 (r/'image-history.txt').write_text(subprocess.check_output(['docker','history','--no-trunc',image],text=True))
 print('image',json.loads((r/'image-inspect.json').read_text())[0]['Id'],flush=True)
finally:
 subprocess.run(['docker','stop',name],check=False)
 subprocess.run(['docker','rm',name],check=False)
