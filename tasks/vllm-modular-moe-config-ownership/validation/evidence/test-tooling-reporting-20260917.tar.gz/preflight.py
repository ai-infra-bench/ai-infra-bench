from pathlib import Path
import json,subprocess,hashlib
repo=Path('/data/jiabei/infrabench/ai-infra-bench');root=Path('/tmp/pr76-experience');task=repo/'tasks/vllm-modular-moe-config-ownership';image='ai-infra-bench/vllm-modular-moe-config-ownership:test-tooling-1.2.9'
def run(name,cmd):
 with (root/name).open('w') as log:result=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 if result.returncode:print((root/name).read_text()[-3000:]);raise SystemExit(result.returncode)
run('image-check.json',['python3','.github/scripts/task_ci.py','image-check','--task',task.name,'--image',image])
run('agent-pytest-collection.log',['docker','run','--rm','--network','none','--gpus','device=0','--cpus','8','--memory','32g',image,'python3','-m','pytest','--collect-only','-q','tests/kernels/moe/test_modular_kernel_combinations.py','tests/kernels/moe/test_cutlass_moe.py'])
run('agent-smoke.log',['docker','run','--rm','--network','none','--gpus','device=0','--cpus','8','--memory','32g',image,'python3','-c','import os,torch,vllm,pytest,importlib.metadata as m; assert os.getuid()!=0; assert vllm.__file__.startswith("/workspace/vllm/"); assert torch.ones(4,device="cuda").sum().item()==4; print({k:m.version(k) for k in ["pytest","pluggy","iniconfig","tblib","packaging","torch"]}); print(torch.cuda.get_device_name(0))'])
f=task/'environment/image-manifest.json';d=json.loads(f.read_text());d['image_check']='passed';f.write_text(json.dumps(d,indent=2)+'\n')
run('repository-validation.log',['python3','.github/scripts/task_ci.py','validate',task.name])
run('reporting-unit-tests.log',['python3',str(task/'validation/test_stage_reporting.py')])
files={str(p.relative_to(task)):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in task.rglob('*') if p.is_file() and '__pycache__' not in p.parts and (str(p.relative_to(task)).startswith(('environment/','tests/','solution/')) or p.name in ['instruction.md','task.toml','test_stage_reporting.py'] or p.suffix=='.patch' or 'challenge' in p.parts)}
(root/'task-inputs-before.json').write_text(json.dumps(files,indent=2))
run('harbor-driver.log',['python3',str(root/'validate.py')])
