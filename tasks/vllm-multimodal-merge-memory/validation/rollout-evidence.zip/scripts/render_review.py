from pathlib import Path
import json,sys
r=Path(sys.argv[1])
for p in sorted(r.glob('jobs/*/*/agent/trajectory.json')):
 d=json.loads(p.read_text());parts=[]
 for s in d['steps']:
  parts.append(f"\nSTEP {s['step_id']} {s['source']}\n")
  if s.get('message'):parts.append('MESSAGE '+str(s['message'])+'\n')
  if s.get('reasoning_content'):parts.append('REASONING '+str(s['reasoning_content'])+'\n')
  for t in s.get('tool_calls',[]):parts.append('CALL '+t['function_name']+' '+json.dumps(t['arguments'],ensure_ascii=False)+'\n')
  for o in s.get('observation',{}).get('results',[]):
   meta=o.get('extra',{}).get('tool_result_metadata',{});raw=meta.get('raw_tool_result',{});content=raw.get('content',o.get('content',''))
   parts.append('RESULT '+o.get('source_call_id','')+' error='+str(o.get('extra',{}).get('tool_result_is_error'))+'\n'+(content if isinstance(content,str) else json.dumps(content,ensure_ascii=False))+'\n')
   info=meta.get('tool_use_result',{})
   if isinstance(info,dict) and info.get('stderr') and info['stderr'] not in str(content):parts.append('STDERR '+info['stderr']+'\n')
  parts.append('\n')
 text=''.join(parts);out=Path('work/rollout63/review-chunks')/p.parent.parent.name;out.mkdir(parents=True,exist_ok=True)
 for n,pos in enumerate(range(0,len(text),18000)): (out/f'{n:03}.txt').write_text(text[pos:pos+18000])
 print(p.parent.parent.name,len(text),'chars',len(list(out.glob('*.txt'))),'chunks')
