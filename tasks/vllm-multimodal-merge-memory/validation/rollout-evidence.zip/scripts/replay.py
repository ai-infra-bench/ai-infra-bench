from pathlib import Path
import json,subprocess,hashlib,concurrent.futures,time,shutil
R=Path('/data/codex-pr63-rollouts-20260918');T=R/'repo/tasks/vllm-multimodal-merge-memory';O=R/'replay-r02-v131';O.mkdir(exist_ok=False);image='ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0'
def hashes(p):return {str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in p.rglob('*') if x.is_file()}
frozen=hashes(T);(O/'inputs-before.json').write_text(json.dumps(frozen,indent=2))
restore="import tarfile,shutil;shutil.rmtree('/workspace/repo');tarfile.open('/snapshot.tar.gz').extractall('/workspace',filter='data')"
def run(slot):
 a=next((R/'flash-r02').glob(f'jobs/flash-r02-gpu{slot}/*/agent/final-state/full-repository.tar.gz'));digest=hashlib.file_digest(a.open('rb'),'sha256').hexdigest();rows=[]
 for version in ['original','corrected']:
  d=O/f'gpu{slot}-{version}';d.mkdir();tests=next((R/'flash-r02/inputs').glob(f'flash-r02-gpu{slot}'))/'tests' if version=='original' else T/'tests'
  cmd=['docker','run','--rm','--init','--network','none','--gpus',f'device={slot}','--cpus','4','--memory','16g','--shm-size','1g','--user','root','--entrypoint','bash','-v',str(a)+':/snapshot.tar.gz:ro','-v',str(tests)+':/tests:ro','-v',str(d)+':/logs/verifier','-v',str(T/'validation/independent_challenge.py')+':/challenge.py:ro',image,'-lc',"python3 -c "+__import__('shlex').quote(restore)+" && cd /workspace/repo && bash /tests/test.sh && runuser -u agent -- python3 /challenge.py"]
  start=time.time()
  with (d/'launcher.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=950)
  rows.append(dict(slot=slot,version=version,archive=str(a),sha256=digest,exit_code=r.returncode,seconds=time.time()-start,reward=(d/'reward.txt').read_text().strip() if (d/'reward.txt').exists() else None,completion=json.loads((d/'completion.json').read_text()) if (d/'completion.json').exists() else None,command=cmd));print(slot,version,rows[-1]['reward'],r.returncode,flush=True)
 assert digest==hashlib.file_digest(a.open('rb'),'sha256').hexdigest()
 return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=sum(pool.map(run,range(4)),[])
assert frozen==hashes(T);(O/'results.json').write_text(json.dumps(dict(inputs_unchanged=True,records=rows),indent=2))
