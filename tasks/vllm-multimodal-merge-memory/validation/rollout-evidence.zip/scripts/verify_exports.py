from pathlib import Path
import hashlib,json,re,tarfile
R=Path('work/rollout63');summary=[]
for r in sorted(R.glob('flash-r[0-9][0-9]')):
 manifest=json.loads((r/'review-export-manifest.json').read_text());bad=[]
 for entry in manifest:
  f=r/entry['path'];got=hashlib.sha256(f.read_bytes()).hexdigest()
  if got!=entry['export_sha256']:bad.append(str(f))
 assert not bad,bad
 for f in r.glob('jobs/*/*/agent/final-state/manifest.json'):
  d=json.loads(f.read_text());missing=[]
  for name,v in d['files'].items():
   p=f.parent/name
   if not p.exists():missing.append(name);continue
   assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],p
  assert missing==['full-repository.tar.gz'],missing
  patch=(f.parent/'tracked.patch').read_text();paths=set(re.findall(r'^diff --git a/(.*?) b/',patch,re.M));untracked=set()
  with tarfile.open(f.parent/'untracked.tar.gz') as t:untracked={m.name.removeprefix('./') for m in t if m.isfile()}
  status=(f.parent/'status.txt').read_text().splitlines();fromstatus={l[3:] for l in status}
  assert paths|untracked==fromstatus,(paths,untracked,fromstatus)
 summary.append(dict(round=r.name,files=len(manifest),redactions=sum(e['redactions'] for e in manifest),all_export_hashes_match=True,all_portable_snapshot_hashes_match=True,tracked_and_untracked_paths_match_status=True,large_full_state_archives=('retained on A100; capture-time hashes checked, no independent replay for infrastructure-only r01' if r.name=='flash-r01' else 'retained on A100; hashes verified by replay and inventory')))
Path('outputs/pr-63-export-integrity.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
