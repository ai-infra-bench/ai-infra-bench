from pathlib import Path
import argparse,json,subprocess,hashlib,concurrent.futures,time,shlex
p=argparse.ArgumentParser();p.add_argument('--round',required=True);p.add_argument('--gpu-offset',type=int,default=4);a=p.parse_args()
R=Path('/data/codex-pr63-rollouts-20260918');S=Path('/tmp/codex-pr63-hardening-20260918/candidate_challenge_v2.py');O=R/('challenge-v2-'+a.round);O.mkdir(exist_ok=False)
image='ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0';script_hash=hashlib.sha256(S.read_bytes()).hexdigest();restore="import tarfile,shutil;shutil.rmtree('/workspace/repo');tarfile.open('/snapshot.tar.gz').extractall('/workspace',filter='data')"
archives=[next((R/a.round).glob(f'jobs/{a.round}-gpu{slot}/*/agent/final-state/full-repository.tar.gz')) for slot in range(4)]
frozen={str(f):hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in archives};meta=dict(script_sha256=script_hash,archive_hashes=frozen,image_id=subprocess.check_output(['docker','image','inspect',image,'--format','{{.Id}}'],text=True).strip());(O/'inputs-before.json').write_text(json.dumps(meta,indent=2))
def run(slot):
 f=archives[slot];cmd=['docker','run','--rm','--init','--network','none','--gpus',f'device={slot+a.gpu_offset}','--cpus','4','--memory','16g','--user','root','--entrypoint','bash','-v',str(f)+':/snapshot.tar.gz:ro','-v',str(S)+':/challenge.py:ro',image,'-lc','python3 -c '+shlex.quote(restore)+' && cd /workspace/repo && runuser -u agent -- python3 /challenge.py'];start=time.time()
 with (O/f'gpu{slot}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 record=dict(slot=slot,exit_code=r.returncode,seconds=time.time()-start,command=cmd);print(json.dumps(record),flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,range(4)))
assert script_hash==hashlib.sha256(S.read_bytes()).hexdigest()
assert frozen=={str(f):hashlib.file_digest(f.open('rb'),'sha256').hexdigest() for f in archives}
(O/'results.json').write_text(json.dumps(dict(records=rows,inputs_unchanged=True),indent=2))
