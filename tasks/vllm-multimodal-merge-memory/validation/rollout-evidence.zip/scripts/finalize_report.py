from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
R=Path('work/rollout63');T=Path('work/pr-63/tasks/vllm-multimodal-merge-memory');V=T/'validation';O=Path('outputs')
rows=json.loads((O/'pr-63-rollout-attempts.json').read_text())
causes={
'flash-r01':['gateway egress denied before any model response']*4,
'flash-r02':['overstrict CPU-mask OOV fixture (F1)','overstrict CPU-mask OOV fixture (F1)','blocking CPU-to-CUDA index copy (F2)','overstrict CPU-mask OOV fixture (F1)'],
'flash-r03':['empty outer embeddings silently accepted (F4; old false positive)','blocking CPU-to-CUDA index copy (F2)','empty outer embeddings silently accepted (F4; old false positive)','complete repair in reviewed scope'],
'flash-r04':['empty outer embeddings silently accepted','complete repair in reviewed scope','empty outer embeddings silently accepted','implicit CPU-index staging waits for CUDA; also accepts empty outer mismatches']}
for row in rows:
 slot=int(row['trial'].split('gpu')[1][0]);row['task_name']='vllm-multimodal-merge-memory';row['task_version']={'flash-r01':'1.3.0','flash-r02':'1.3.0','flash-r03':'1.3.1','flash-r04':'1.3.2'}[row['round']]
 row['review']={'cause':causes[row['round']][slot],'hack':'no hack observed in reviewed material','artifacts':'native+ATIF+tracked+untracked+pre-verifier full snapshot manifest; full tar retained on A100','scope':'all agent messages/actions/tool inputs and results plus final repository changes; raw reasoning retained, not exhaustively read','limits':'bounded Python-level integrity; not full Qwen serving or arbitrary native attack proof'}
 row['verifier_outcomes']={'passed':row['completion']['completed'],'required':row['completion']['required'],'explicit_skips':0,'not_reached':row['completion']['required']-row['completion']['completed'],'lifecycle_errors':row['completion']['errors'],'failure_cause':row['review']['cause'] if row['reward']==0 else None}
(O/'pr-63-rollout-attempts.json').write_text(json.dumps(rows,indent=2)+'\n');shutil.copyfile(O/'pr-63-rollout-attempts.json',V/'rollout-attempts.json')
p=O/'pr-63-rollout-review.md';s=p.read_text();s=s.replace('# PR #63 flash rollout review（进行中）','# PR #63 flash rollout review（完成，v1.3.2）')
start=s.index('\n\n');end=s.index('\n## 范围与证据')
s=s[:start]+'''\n\n最终 v1.3.2 的评分与完整交付物重放、独立行为检查一致，可以保留该 task。发现并修复两处 verifier 问题：CPU-mask OOV 的隐藏范围扩展，以及空外层 embeddings 计数漏检。未发现仍需修改的评分问题；这是一项在已披露边界内的接受结论。

A100 上完成 3 批有效 flash 测试，每批并行 4 个，共 12 个模型答案；另保留 1 批 4 个网关配置失败。逐条 review 后各批原始奖励为 r02 `[0,0,0,0]`、r03 `[1,0,1,1]`、r04 `[0,1,0,0]`。以最终 32 项 verifier 重放分别为 `[1,1,0,1]`、`[0,0,0,1]`、`[0,1,0,0]`。旧结果原样保留。

当前 Oracle 和独立 index-copy 实现均 32/32，Base 和伪造成功退出均为 0。测试有效性、候选正确性和 task 可解性分别有对照证据；不要求四个模型答案全部通过才结束迭代。
''' +s[end:]
s=s.replace('`pr-63-rollout-skill-hashes.json`','`rollout-evidence.zip` 内 `review/pr-63-rollout-skill-hashes.json`').replace('`pr-63-rollout-attempts.json`','[rollout-attempts.json](rollout-attempts.json)')
s+='''
## 最后一批有效轨迹 r04

四条轨迹全部动作与结果、最终 production patch、新增测试均已核对，未观察到 hack。GPU1 再次读取安装的 vLLM 副本，仍为 masked_scatter，没有暴露答案；外部 WebFetch/搜索/包下载未成功得到修复。所有 4 个 Harbor trial 无框架异常，canonical task 和准备副本前后哈希均一致。

- GPU0：显式计数、pinned 非阻塞整数索引赋值，保留空外层直接返回。自测 15 项和现有 utils 4 项通过，但未测空外层配非零占位符。正式 26/32 后失败；独立六种空外层输入全部被错误接受。实际 GPU event 检查没有等待。
- GPU1：显式处理空外层数量，pinned 非阻塞 index_copy；最终仅修改 utils。直接实验覆盖设备、dtype、嵌套、计数、空输入和 view。两次基准实验参数顺序错误后修正。正式与重放均 32/32，独立语义和空计数全部正确，GPU 工作未完成时返回。CPU 大向量自测受 128 个 CPU 线程与容器 quota 影响，不据此承诺吞吐。
- GPU2：先采用阻塞 .to，经 sync-debug 实验改为 non_blocking=True，但漏掉空外层计数。新增 19 测试、既有 omni 11 测试通过。正式 26/32，独立空计数六项全错；该固定环境的 pending-event 三次均未观察到等待，不把未 pin 本身当作评分禁令。其“masked_scatter 会重复不足的源”解释不准确，不作为实现正确证据。
- GPU3：CPU 整数索引直接作用于 CUDA 目标，隐式 staging 导致同步；同时保留空外层直接返回。自测只拦截 item/cpu/tolist，不能捕获此等待。21 个新增 GPU 测试、11 个 omni、96 个 mrope 通过；CPU-only 实际为 11 passed/1 skipped，与最终答复笼统写 21 不同。正式首项即失败，独立三次均等待约 0.457 秒且 event 已完成，六项空计数也全错。

四份完整快照的非 .git 文件数为 4956、4946、4993、4998；忽略文件也逐项比对。除 Python/pytest 缓存外，差异只有 utils.py，以及 GPU0/2/3 各一个新增测试；native 资产无变动。新增测试从 Write/Edit 顺序重建，与最终 untracked 归档逐字节一致。完整状态重放的结果仍为 0、1、0、0；不是仅套用修复 patch 的替代重放。

## 所有尝试与重评

下表行数为最终 tracked diff 的新增/删除行加完整 untracked 文本行数，不是累计编辑量；均无新增二进制交付。工具次数按 ATIF 显式 tool_calls 计，不把 shell 内命令数当模型轮数。UUID、task checksum、模型/框架版本及逐文件哈希见 [rollout-attempts.json](rollout-attempts.json)。r01 的 agent step 是 harness 合成错误消息。

'''+(R/'attempts-table.md').read_text()+'''

检查数为顺序 fail-fast 的已认证通过数，后续未运行不是 pytest skip。失败时保留首个异常和 worker 未完整退出的生命周期错误；Harbor trial 正常完成也不等于候选通过。原始 verifier 日志与 completion.json 均在证据包中。

| 批次 / GPU | 原奖励 | 最终完整重评 | 空外层错误输入 | CPU mask 等待 GPU | 原因 / 评分判断 |
|---|---:|---:|---|---|---|
| r01 / 0–3 | 全 0 | 未重放 | 未执行 | 未执行 | 无模型响应；基础设施故障 |
| r02 / 0 | 0 | 1 | 32 项套件通过 | 独立未等待 | 原 OOV false negative 已修正 |
| r02 / 1 | 0 | 1 | 32 项套件通过 | 独立未等待 | 原 OOV false negative 已修正 |
| r02 / 2 | 0 | 0 | 首项失败后未测 | 独立等待 | agent 同步缺陷 |
| r02 / 3 | 0 | 1 | 32 项套件通过 | 独立未等待 | 原 OOV false negative 已修正 |
| r03 / 0 | 1 | 0 | 6/6 错误接受 | 独立未等待 | 原 false positive 已修正 |
| r03 / 1 | 0 | 0 | 6/6 正确报错 | 独立等待 | agent 同步缺陷 |
| r03 / 2 | 1 | 0 | 6/6 错误接受 | 独立未等待 | 原 false positive 已修正 |
| r03 / 3 | 1 | 1 | 6/6 正确报错 | 独立未等待 | 通过 |
| r04 / 0 | 0 | 0 | 6/6 错误接受 | 独立未等待 | 空计数漏处理 |
| r04 / 1 | 1 | 1 | 6/6 正确报错 | 独立未等待 | 通过 |
| r04 / 2 | 0 | 0 | 6/6 错误接受 | 独立未等待 | 空计数漏处理 |
| r04 / 3 | 0 | 0 | 6/6 错误接受 | 独立等待 | 隐式同步及空计数缺陷 |

所有 12 个有效答案还通过独立的改变 mask、数量、数据值并复用非连续目标的 8 项语义检查。它不能单独证明同步或错误输入正确，故与其余检查分别报告。

## 可重放证据与提交边界

[rollout-evidence.zip](rollout-evidence.zip) 包含 4 批全部 portable 导出、capture smoke、native JSONL/ATIF、完整 tracked/untracked 最终改动、原始奖励/日志、manifest、独立挑战、旧/新完整重放、文件清点和执行脚本。包内 EVIDENCE-MANIFEST.json 记录每个文件 SHA-256；各 campaign 的 pre-run 哈希和事后相等检查在原记录中。逐次 UUID 和最终 archive 绝对路径可从 rollout-attempts.json 定位。共 424 个模型批次导出文件（109+105+105+105），全部导出哈希核对通过，真实凭据扫描无需脱敏替换。

A100 的原始完整 tar 保留于 `/data/codex-pr63-rollouts-20260918/<round>/jobs/<job>/<trial>/agent/final-state/full-repository.tar.gz`，含 .git、忽略文件和 native 文件；因每个约 1.4 GB 不提交到 Git。12 个有效答案实际用这些 tar 完整恢复并重放；r01 仅验证捕获哈希，不声称做了独立行为重放。可携证据不等于离线附带了这些完整 tar，离开该 A100 后重放需取回相应快照。镜像也尚无 registry digest。

本轮使用的运行修订依次为 `9426c3232ae56eb41e138f89601a02eb6de3a968`（r02）、r03 campaign 记录的 `f61a13d…`、`5a4cf5315f94bb267428cbe63c76c9dc36fb924d`（r04）。代码修正已 push 到 origin/harden-pr-63 并在 A100 pull。最终文档和证据打包在所有 campaign 完成后产生，不改写运行时哈希，也不改变测试逻辑；最终提交身份由 Git commit 给出。

接受范围：v1.3.2 的 32 项行为评分与已审阅的 12 个真实答案一致，Oracle/独立替代实现证明当前边界可解。本轮没有未关闭的已确认 task/verifier 缺陷。旧 18 项反作弊控制矩阵是 v1.3.0 历史证据；v1.3.2 明确重跑四个模式控制，不把历史矩阵冒充新版重跑。不宣称没有未知漏洞，也不把 12 个开发样本解释为总体 pass rate。

'''+(R/'case-handoffs.md').read_text().replace('Fresh four-attempt r04 verification follows.','Fresh four-attempt r04 and complete replays agree at [0,1,0,0]; no new scoring defect found.')
p.write_text(s);(V/'rollout-review.md').write_text(s)
readme=T/'README.md';readme.write_text(readme.read_text().replace('runs 26 behavioral cases','runs 32 behavioral cases')+'\nThe completed A100 flash campaign, score corrections and final acceptance boundary are in [rollout review](validation/rollout-review.md), with all 16 attempt records and portable evidence.\n')
m=V/'remediation-matrix.md';m.write_text(m.read_text().replace('Full Qwen serving and fresh model-agent rollouts were not run.','At this historical v1.3.0 checkpoint, full Qwen serving and fresh model-agent rollouts were not run.')+'\n## Subsequent rollout remediation (v1.3.2)\n\nThe historical 26-case matrix above is not a v1.3.2 rerun. Flash rollouts exposed the CPU-mask OOV scope extension (corrected in v1.3.1) and missing empty-outer count checks (six added in v1.3.2). Current Oracle/alternative are 32/32; Base/forged-success-exit are zero. Twelve effective model attempts were reviewed and completely replayed, plus four preserved infrastructure failures. See [rollout-review.md](rollout-review.md) and [rollout-attempts.json](rollout-attempts.json).\n')
# All requested portable evidence, preserving original bytes and directory layout.
files={}
for name in ['flash-r01','flash-r02','flash-r03','flash-r04','capture-smoke-02','replay-evidence']:
 for f in (R/name).rglob('*'):
  if f.is_file():files[str(f.relative_to(R))]=f
for f in R.glob('*.py'):files['scripts/'+f.name]=f
for name in ['review-progress.json','r03-review-progress.json','r04-review-progress.json','case-handoffs.md']:
 files['review/'+name]=R/name
for name in ['pr-63-export-integrity.json','pr-63-rollout-skill-hashes.json','pr-63-flash-r01-review.json']:
 files['review/'+name]=O/name
manifest={n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}
with zipfile.ZipFile(V/'rollout-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6,strict_timestamps=False) as z:
 for name,f in sorted(files.items()):z.write(f,name)
 z.writestr('EVIDENCE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(V/'rollout-evidence.zip') as z:
 for name,rec in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==rec['sha256']
# Replace current validation with correctly scoped current results; prior evidence retained.
e=V/'e2e-evidence.json';d=json.loads(e.read_text());d['recorded_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['status']='validated-rollout-reviewed';d['validation']={'mode':'Oracle-based','controls_v132':json.loads((R/'replay-evidence/controls-v132/results.json').read_text()),'model_campaigns':[{k:c[k] for k in ['commit','model','model_revision','harbor','claude_code','reasoning_effort','concurrency','canonical_inputs_unchanged']}|{'round':name} for name in ['flash-r01','flash-r02','flash-r03','flash-r04'] for c in [json.loads((R/name/'campaign.json').read_text())]],'attempts':'validation/rollout-attempts.json','report':'validation/rollout-review.md','portable_evidence':'validation/rollout-evidence.zip','final_replay_rewards':{'flash-r02':[1,1,0,1],'flash-r03':[0,0,0,1],'flash-r04':[0,1,0,0]},'historical_validation':'validation/history/v1.3.0-evidence.json','integrity_scope':'Python report/exit forgery; not arbitrary native memory or in-process observer mutation.'}
d['snapshot_notes']=['Campaign and replay pre-run hashes and post-run equality are retained in portable evidence.','Final report/evidence/README changes occur after all frozen runs; tests, Oracle and runtime configuration remain exactly as run at 5a4cf5315f94bb267428cbe63c76c9dc36fb924d.','16 model trials retained: 4 infrastructure failures, 12 effective model answers. All 12 full final states replayed.','Complete final tar archives are retained on A100 and are not in this portable zip. Their exact paths and hashes are in the attempt records.','Historical v1.3.0 matrix is preserved, not represented as a v1.3.2 rerun.']
d['publication']={'state':'unpublished','registry_digest':None,'branch':'harden-pr-63','runtime_revision':'5a4cf5315f94bb267428cbe63c76c9dc36fb924d','runtime_revision_committed':True,'runtime_revision_pushed':True,'final_documentation_commit':'Git commit containing this evidence; no self-referential commit hash'}
d['artifacts']['files']={str(f.relative_to(T)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(T.rglob('*')) if f.is_file() and f!=e and '__pycache__' not in f.parts}
e.write_text(json.dumps(d,indent=2)+'\n');print('evidence files',len(files),'zip bytes',(V/'rollout-evidence.zip').stat().st_size)
