"""Lossless action review index: reference exact repeated bodies; diff Write/Edit.
Reasoning is retained in raw ATIF but not reproduced in the action index.
"""
from pathlib import Path
import json,sys,hashlib,difflib,re
seen={};reads={};prior=Path('work/rollout63/flash-r02')
def content(o):
 meta=o.get('extra',{}).get('tool_result_metadata',{});raw=meta.get('raw_tool_result',{});c=raw.get('content',o.get('content',''));return c if isinstance(c,str) else json.dumps(c,ensure_ascii=False)
def identity(s):return hashlib.sha256(s.encode()).hexdigest()
for p in sorted(prior.glob('jobs/*/*/agent/trajectory.json')):
 for s in json.loads(p.read_text())['steps']:
  calls={c['tool_call_id']:c for c in s.get('tool_calls',[])}
  for o in s.get('observation',{}).get('results',[]):
   c=content(o);ref=f'{p.parent.parent.name} step {s["step_id"]}';seen[identity(c)]=ref
   call=calls.get(o.get('source_call_id'),{})
   if call.get('function_name')=='Read':
    path=call['arguments'].get('file_path');target=reads.setdefault(path,{})
    for l in c.splitlines():
     m=re.match(r'^(\d+)\t(.*)$',l)
     if m:target[int(m[1])]=(m[2],ref)
for p in sorted(Path(sys.argv[1]).glob('jobs/*/*/agent/trajectory.json')):
 parts=[]
 for s in json.loads(p.read_text())['steps']:
  parts.append(f'\nSTEP {s["step_id"]} {s["source"]}\n'+str(s.get('message',''))+'\n');calls={c['tool_call_id']:c for c in s.get('tool_calls',[])}
  for c in calls.values():
   a=c['arguments'];name=c['function_name']
   if name=='Edit':
    parts.append('EDIT '+a['file_path']+' replace_all='+str(a.get('replace_all'))+'\n'+''.join(difflib.unified_diff(a['old_string'].splitlines(True),a['new_string'].splitlines(True),fromfile='old_string',tofile='new_string'))+'\n')
   else:parts.append('CALL '+name+' '+json.dumps(a,ensure_ascii=False)+'\n')
  for o in s.get('observation',{}).get('results',[]):
   body=content(o);call=calls.get(o.get('source_call_id'),{});ref=f'{p.parent.parent.name} step {s["step_id"]}';h=identity(body)
   parts.append('RESULT '+o.get('source_call_id','')+' error='+str(o.get('extra',{}).get('tool_result_is_error'))+' sha256='+h+'\n')
   if h in seen:parts.append('[exact body already reviewed: '+seen[h]+']\n')
   elif call.get('function_name')=='Read':
    path=call['arguments'].get('file_path');target=reads.setdefault(path,{});pending=0;refs=set()
    def flush():
     global pending,refs
     if pending:parts.append(f'[{pending} unchanged numbered source lines match '+', '.join(sorted(refs))+']\n');pending=0;refs=set()
    for l in body.splitlines():
     m=re.match(r'^(\d+)\t(.*)$',l)
     if m and int(m[1]) in target and target[int(m[1])][0]==m[2]:pending+=1;refs.add(target[int(m[1])][1])
     else:flush();parts.append(l+'\n')
     if m:target[int(m[1])]=(m[2],ref)
    flush()
   else:parts.append(body+'\n')
   seen[h]=ref
   info=o.get('extra',{}).get('tool_result_metadata',{}).get('tool_use_result',{})
   if isinstance(info,dict) and info.get('stderr') and info['stderr'] not in body:parts.append('STDERR '+info['stderr']+'\n')
 text=''.join(parts);out=Path('work/rollout63/delta-chunks')/p.parent.parent.name;out.mkdir(parents=True,exist_ok=True)
 for n,pos in enumerate(range(0,len(text),16000)):(out/f'{n:03}.txt').write_text(text[pos:pos+16000])
 print(p.parent.parent.name,len(text),'chars')
