from pathlib import Path
import json,tarfile,hashlib,datetime,re
R=Path('work/rollout63');rows=[]
def delta(d):
 if not d or not d.get('started_at') or not d.get('finished_at'):return None
 return (datetime.datetime.fromisoformat(d['finished_at'])-datetime.datetime.fromisoformat(d['started_at'])).total_seconds()
for rounddir in sorted(R.glob('flash-r[0-9][0-9]')):
 campaign=json.loads((rounddir/'campaign.json').read_text())
 for p in sorted(rounddir.glob('jobs/*/*/result.json')):
  d=json.loads(p.read_text());a=p.parent/'agent';traj=json.loads((a/'trajectory.json').read_text());state=a/'final-state';patch=(state/'tracked.patch').read_text();untracked=[]
  with tarfile.open(state/'untracked.tar.gz') as tar:
   for m in tar:
    if m.isfile():
     b=tar.extractfile(m).read();untracked.append(dict(path=m.name,lines=len(b.splitlines()) if b'\x00' not in b else None,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
  completion=json.loads((p.parent/'verifier/completion.json').read_text());slot=int(re.search(r'gpu(\d)',d['trial_name'])[1]);replays={}
  for rp in sorted((R/'replay-evidence').glob('replay-*/results.json')):
   for record in json.loads(rp.read_text())['records']:
    if record['slot']==slot and rounddir.name in record['archive']:
     replays[rp.parent.name+'/'+record['version']]={k:record.get(k) for k in ('reward','completion','sha256','exit_code')}
  paths=re.findall(r'^diff --git a/(.*?) b/',patch,re.M)
  row=dict(round=rounddir.name,trial=d['trial_name'],id=d['id'],checksum=d['task_checksum'],task_revision=campaign['commit'],model=campaign['model'],reasoning=campaign['reasoning_effort'],model_revision=campaign['model_revision'],harbor=campaign['harbor'],agent_harness='CapturedClaude / Claude Code '+campaign['claude_code'],reward=(d.get('verifier_result') or {}).get('rewards',{}).get('reward'),exception=d['exception_info'],steps_total=len(traj['steps']),agent_steps=sum(s['source']=='agent' for s in traj['steps']),tool_calls=sum(len(s.get('tool_calls',[])) for s in traj['steps']),tracked=paths,tracked_added=sum(l.startswith('+') and not l.startswith('+++') for l in patch.splitlines()),tracked_deleted=sum(l.startswith('-') and not l.startswith('---') for l in patch.splitlines()),untracked=untracked,seconds_total=delta(d),seconds_agent=delta(d.get('agent_execution')),seconds_verifier=delta(d.get('verifier')),completion=completion,metrics=traj.get('final_metrics'),full_state=json.loads((state/'manifest.json').read_text()),replays=replays,raw_evidence=str(p.relative_to(R)),verifier_accounting='Sequential fail-fast: completed authenticated checks are passes; later checks not run, not pytest skips; completion errors reflect lifecycle failures.')
  rows.append(row)
Path('outputs/pr-63-rollout-attempts.json').write_text(json.dumps(rows,indent=2)+'\n')
lines=['| Round / GPU | Trial | 原奖励 | 检查完成 | Agent step / tools | 最终文件 / +行 / -行 | 总 / agent / verifier 秒 |','|---|---|---:|---:|---:|---:|---:|']
for r in rows:
 files=len(r['tracked'])+len(r['untracked']);add=r['tracked_added']+sum(f['lines'] or 0 for f in r['untracked']);c=r['completion'];times=' / '.join('未记录' if r[k] is None else f'{r[k]:.1f}' for k in ('seconds_total','seconds_agent','seconds_verifier'))
 lines.append(f"| {r['round']} / {re.search(r'gpu(\d)',r['trial'])[1]} | {r['trial']} | {r['reward']} | {c['completed']}/{c['required']} | {r['agent_steps']} / {r['tool_calls']} | {files} / +{add} / -{r['tracked_deleted']} | {times} |")
Path('work/rollout63/attempts-table.md').write_text('\n'.join(lines)+'\n')
print(len(rows),'attempts summarized')
