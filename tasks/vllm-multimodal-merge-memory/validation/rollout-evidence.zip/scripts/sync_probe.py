import torch,time,json
x=torch.zeros((1024,64),device='cuda'); m=torch.arange(1024)%3==1; n=int(m.sum());v=torch.ones((n,64),device='cuda');idx=m.nonzero().flatten();pin=idx.pin_memory();dev=idx.cuda()
ops={'noop':lambda:None,'device_index_copy':lambda:x.index_copy_(0,dev,v),'cpu_bool':lambda:x.__setitem__(m,v),'cpu_index_blocking':lambda:x.index_copy_(0,idx.to(x.device),v),'cpu_index_async':lambda:x.index_copy_(0,idx.to(x.device,non_blocking=True),v),'pinned_index_async':lambda:x.index_copy_(0,pin.to(x.device,non_blocking=True),v)}
for name,fn in ops.items():
 for _ in range(3):fn()
 torch.cuda.synchronize()
 results=[]
 for i in range(3):
  ev=torch.cuda.Event(); torch.cuda._sleep(500000000); ev.record(); before=ev.query(); start=time.perf_counter();fn();elapsed=time.perf_counter()-start;after=ev.query();torch.cuda.synchronize();results.append(dict(before=before,after=after,seconds=elapsed))
 print(json.dumps(dict(name=name,results=results)),flush=True)
