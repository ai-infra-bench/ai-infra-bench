"""Unscored independent behavioral probes. Expected values never use candidate helpers."""
import torch,json,sys,time
sys.path.insert(0,'/workspace/repo')
from vllm.model_executor.models.utils import _merge_multimodal_embeddings as merge
rows=[]
for device in ('cpu','cuda'):
 x=torch.full((7,17),-9.,device='cuda',dtype=torch.float16).t();expected=torch.full((17,7),-9.,dtype=torch.float16)
 for k,positions in enumerate(([1,7,13],[0],[2,5,16],[])):
  mask=torch.zeros(17,dtype=torch.bool);mask[positions]=True
  values=(torch.arange(len(positions)*7).reshape(len(positions),7)+k*31).float();source=values.cuda().reshape(1,len(positions),7)
  out=merge(x,source,mask.to(device))
  for i,pos in enumerate(positions):expected[pos]=values[i].to(expected.dtype)
  assert out is x and torch.equal(x.cpu(),expected)
  rows.append(dict(kind='changed_inputs_repeated_strided',device=device,step=k,passed=True))
# Observe actual pending GPU work, without relying on candidate algorithm or a
# latency threshold. Warm allocations first and preallocate every fixture.
x=torch.zeros((1024,64),device='cuda');mask=torch.arange(1024)%3==1;n=int(mask.sum());v=torch.ones((n,64),device='cuda')
for _ in range(3):merge(x,v,mask)
torch.cuda.synchronize();pending=[]
for _ in range(3):
 event=torch.cuda.Event();torch.cuda._sleep(500000000);event.record();before=event.query();start=time.perf_counter();out=merge(x,v,mask);elapsed=time.perf_counter()-start;after=event.query();torch.cuda.synchronize()
 pending.append(dict(before=before,after=after,seconds=elapsed,identity=out is x))
empty=[]
for device in ('cpu','cuda'):
 for form in ('list','tensor','tuple'):
  x=torch.zeros((5,7),device='cuda');mask=(torch.arange(5)<2).to(device)
  source=[] if form=='list' else (() if form=='tuple' else torch.empty((0,7),device='cuda'))
  try:
   merge(x,source,mask)
   result=dict(raised=False)
  except Exception as exc:
   result=dict(raised=True,error_type=type(exc).__name__,message=str(exc))
  empty.append(dict(device=device,form=form,**result))
print(json.dumps(dict(empty_count_cases=empty,semantic_cases=rows,pending_gpu_work=pending,no_wait_observed=all(not r['before'] and not r['after'] and r['identity'] for r in pending))),flush=True)
