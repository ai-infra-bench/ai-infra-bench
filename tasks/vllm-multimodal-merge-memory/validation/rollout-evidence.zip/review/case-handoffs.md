## Case handoffs

### CPU-mask OOV scope correction (v1.3.1)

- Behavior / contract: CPU-mask merge support is explicit; CPU-mask OOV preprocessing is absent from the Qwen3-VL repair contract. Normal CUDA-mask OOV behavior is preserved.
- Mode / scope: Oracle-based; real production SupportsMultiModal initialization and lookup, small deterministic weights replacing full model weights.
- Artifacts: complete r02 final states, native logs, ATIF and untracked files available; all four originals and revised suites replayed without candidate edits.
- Stable boundary: configure_mm_token_handling → _embed_text_input_ids → embed_input_ids → production merge. Qwen3-VL at Base does not enable OOV handling; normal runners produce CUDA masks.
- Expected / actual: a correct merge-only repair should preserve normal CUDA-mask OOV preparation. v1.3.0 instead rejected three repairs on CPU/CUDA mismatch in unmodified masked_fill.
- Remediation: retain an in-vocabulary CPU-mask interface case and normal OOV CUDA-mask case; do not make the CPU case wait or relax output/memory/count requirements.
- Outcome: r02 originals [0,0,0,0], old replay [0,0,0,0], v1.3.1 replay [1,1,0,1]. GPU2 independently blocks in .to; it is not an OOV false negative.
- Controls / identities: controls-v131 and replay-r02-v131 contain pre-run task hashes, exact image, archive identities and post-run equality. Oracle and index-copy alternative both 1; Base/forged-success-exit 0.
- Confidence: reproduced; promoted as a fixture correction. Later empty-container checks are independent and retain these three successes.

### Empty outer embedding count mismatches (v1.3.2)

- Behavior / contract: incorrect embedding/placeholder counts must raise a useful error for either mask device; empty inputs are a no-op only when no placeholders exist. This is explicit.
- Mode / scope: Oracle-based, same real merge boundary as existing malformed-count checks; no model-wrapper behavior change or model-forward requirement.
- Artifacts: complete r03 originals captured before grading; all messages/actions/tool results and final tracked/untracked code reviewed. Ignored files/native assets retained in replay.
- Minimal malformed-count event: CUDA destination (5,7), Boolean CPU/CUDA mask with two true rows, source [], (), or CUDA (0,7) tensor. Expected ValueError identifies 0 and 2; GPU0/GPU2 returned unchanged without error for all six forms.
- Reference role: expected behavior derives from the disclosed count contract. Oracle is a solvability control, not an algorithm template.
- Why missed: the old zero-count fixture passed [empty_tensor], whose outer length is 1; two answers retained len(multimodal_embeddings)==0 early return.
- Independent vs scored cases: challenge-v2 uses 5×7 and two placeholders; scored cases use 9×16, three placeholders, both mask devices and all three outer forms. Real CUDA destination/source; no mocked error path.
- Original outcomes: r03 [1,0,1,1]. Independent empty-case results: GPU0/2 accept all six wrongly; GPU1/3 reject all six correctly. Independent pending-work test finds GPU1 waits; others return before event completion.
- Revised full suite: [0,0,0,1]. Old suite replay reproduces [1,0,1,1]. Complete Oracle and alternative remain 1 (32/32), Base and forged-success-exit remain 0.
- Frozen inputs: challenge-v2-flash-r03/inputs-before.json records script and all four full archive hashes before execution; results.json confirms unchanged. replay-r03-v132 contains both full-suite commands, task pre-hashes, archive hashes and after checks. Controls-v132 records exact inputs and command.
- Confidence / stage: confirmed false positives; six cases promoted without changing the task instruction. r02 v1.3.2 replay remains [1,1,0,1]. Fresh four-attempt r04 verification follows.
