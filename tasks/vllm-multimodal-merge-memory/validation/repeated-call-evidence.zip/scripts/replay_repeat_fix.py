from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import shlex
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
ROOT = a.root
TASK = ROOT / 'task'
OUT = ROOT / 'replay'
OUT.mkdir(exist_ok=False)
CAMPAIGN = Path('/data/codex-pr63-rollouts-20260918/codex-gpt6-medium-r03')
IMAGE = 'sha256:9b8b0bfbce07832a29b5831c05726ca795f00eface39d678b9a9aea20646d51b'
archives = [next(CAMPAIGN.glob(f'jobs/*gpu{i}/*/agent/final-state/full-repository.tar.gz')) for i in range(4)]
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
files = [*archives, *TASK.joinpath('tests').glob('*'), Path(__file__)]
files = [f for f in files if f.is_file()]
before = {str(f): digest(f) for f in files}
for archive in archives:
    manifest = json.loads((archive.parent / 'manifest.json').read_text())
    assert before[str(archive)] == manifest['files']['full-repository.tar.gz']['sha256']
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2))
restore = """import tarfile, shutil
shutil.rmtree('/workspace/repo')
def filt(member, destination):
    if member.issym() and member.name in ('repo/.venv/bin/python', 'repo/.venv/bin/python3', 'repo/.venv/bin/python3.12') and member.linkname in ('/usr/local/bin/python', 'python'):
        return member
    return tarfile.data_filter(member, destination)
with tarfile.open('/snapshot.tar.gz') as archive:
    archive.extractall('/workspace', filter=filt)
"""
def run(index, gpu):
    archive = archives[index]
    trial = archive.parents[2].name
    out = OUT / trial
    out.mkdir()
    cmd = ['docker', 'run', '--rm', '--init', '--name', f'pr63-repeat-replay-{index}',
           '--network', 'none', '--gpus', f'device={gpu}', '--cpus', '4', '--memory', '16g',
           '--shm-size', '1g', '--user', 'root', '--entrypoint', 'bash',
           '-v', f'{TASK / "tests"}:/tests:ro', '-v', f'{archive}:/snapshot.tar.gz:ro',
           '-v', f'{out}:/logs/verifier', IMAGE, '-lc',
           'set -e\npython3 -c ' + shlex.quote(restore) + '\ncd /workspace/repo\nbash /tests/test.sh\n']
    t = time.monotonic()
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=1200)
    (out / 'command.json').write_text(json.dumps(cmd, indent=2))
    (out / 'launcher.log').write_text(proc.stdout + proc.stderr)
    completion = json.loads((out / 'completion.json').read_text()) if (out / 'completion.json').exists() else {}
    row = dict(trial=trial, original_reward=1, reward=int((out / 'reward.txt').read_text()) if (out / 'reward.txt').exists() else None,
               completed=completion.get('completed'), required=completion.get('required'), errors=completion.get('errors'),
               process_exit=proc.returncode, seconds=round(time.monotonic()-t, 3), gpu=gpu,
               archive=str(archive), archive_sha256=before[str(archive)])
    (out / 'result.json').write_text(json.dumps(row, indent=2))
    print(json.dumps(row), flush=True)
    return row
def lane(gpu, indices):
    return [run(i, gpu) for i in indices]
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(lane, 4+i, range(i, 4, 2)) for i in range(2)]
    rows = [r for f in futures for r in f.result()]
unchanged = before == {str(f): digest(f) for f in files}
(OUT / 'results.json').write_text(json.dumps(dict(image=IMAGE, inputs_unchanged=unchanged, results=rows), indent=2))
assert unchanged
assert all(r['process_exit'] == 0 and r['reward'] == 1 and r['completed'] == 34 and r['errors'] == [] for r in rows), rows
