from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--phase', choices=['smoke', 'matrix'], required=True)
a = p.parse_args()
ROOT = a.root
TASK = ROOT / 'task'
IMAGE = 'sha256:9b8b0bfbce07832a29b5831c05726ca795f00eface39d678b9a9aea20646d51b'
OUT = ROOT / a.phase
OUT.mkdir(exist_ok=False)
def hashes():
    return {str(f.relative_to(TASK)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in TASK.rglob('*') if f.is_file()}
before = hashes()
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2))
manifest = json.loads((TASK / 'validation/ci-cases.json').read_text())
cases = [dict(name='base', patch=None, expected_reward=0),
         dict(name='oracle', patch='/task/solution/oracle.patch', expected_reward=1)]
cases += [dict(name=c['name'], patch='/task/validation/' + c['patch'],
               expected_reward=c['expected_reward']) for c in manifest['cases']]
if a.phase == 'smoke':
    cases = [c for c in cases if c['name'] in ('oracle', 'stale-placement-cache', 'content-keyed-placement-cache')]
else:
    cases += [dict(name='oracle-repeat', patch='/task/solution/oracle.patch', expected_reward=1),
              dict(name='alternative-repeat', patch='/task/validation/alternative-agent-implementation.patch', expected_reward=1)]

def run(c, gpu):
    out = OUT / c['name']
    out.mkdir()
    script = 'set -e\ncd /workspace/repo\n'
    if c['patch']:
        script += f"git -c safe.directory=/workspace/repo apply {c['patch']}\n"
    script += 'bash /tests/test.sh\n'
    cmd = ['docker', 'run', '--rm', '--name', 'pr63-repeat-fix-' + c['name'],
           '--network', 'none', '--gpus', 'device=' + str(gpu), '--cpus', '4', '--memory', '16g',
           '--user', 'root', '--entrypoint', 'bash', '-v', f'{TASK}:/task:ro',
           '-v', f'{TASK / "tests"}:/tests:ro', '-v', f'{out}:/logs/verifier', IMAGE, '-lc', script]
    t = time.monotonic()
    completed = subprocess.run(cmd, capture_output=True, text=True, timeout=880)
    (out / 'command.json').write_text(json.dumps(cmd, indent=2))
    (out / 'launcher.log').write_text(completed.stdout + completed.stderr)
    reward = int((out / 'reward.txt').read_text()) if (out / 'reward.txt').exists() else None
    completion = json.loads((out / 'completion.json').read_text()) if (out / 'completion.json').exists() else {}
    log = (out / 'verifier.log').read_text() if (out / 'verifier.log').exists() else ''
    reason = next((s for s in reversed(log.splitlines()) if s.strip()), '')
    ratios = [r for item in completion.get('records', []) for r in item.get('value', {}).get('peak_ratios', [])]
    row = dict(name=c['name'], expected_reward=c['expected_reward'], reward=reward,
               process_exit=completed.returncode, seconds=round(time.monotonic()-t, 3), gpu=gpu,
               completed=completion.get('completed'), required=completion.get('required'),
               child_status=completion.get('child_status'), errors=completion.get('errors'),
               max_peak_ratio=max(ratios) if ratios else None, reason=reason)
    (out / 'result.json').write_text(json.dumps(row, indent=2))
    print(json.dumps(row), flush=True)
    return row

# Each worker holds one GPU and processes its candidates sequentially.
def run_lane(gpu, selected):
    return [run(c, gpu) for c in selected]
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run_lane, 6 + lane, cases[lane::2]) for lane in range(2)]
    results = [r for future in futures for r in future.result()]
after = hashes()
summary = dict(image=IMAGE, phase=a.phase, results=results, inputs_unchanged=before == after)
(OUT / 'results.json').write_text(json.dumps(summary, indent=2))
assert summary['inputs_unchanged']
assert all(r['process_exit'] == 0 and r['reward'] == r['expected_reward'] for r in results), results
assert all(r['completed'] == 34 and r['errors'] == [] for r in results if r['expected_reward'] == 1), results
