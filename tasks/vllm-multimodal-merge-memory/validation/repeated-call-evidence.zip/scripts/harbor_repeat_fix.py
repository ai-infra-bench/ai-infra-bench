from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import yaml

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--gpus', default='6,7')
a = p.parse_args()
gpus = [int(value) for value in a.gpus.split(',')]
assert len(gpus) == 2 and gpus[0] != gpus[1]
ROOT = a.root
TASK = ROOT / 'task'
OUT = ROOT / 'harbor'
OUT.mkdir(exist_ok=False)
def hashes(root):
    return {str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file()}
before = hashes(TASK)
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2))
cases = [
    ('oracle', None, 1),
    ('stale-placement-cache', 'stale-placement-cache.patch', 0),
    ('alternative', 'alternative-agent-implementation.patch', 1),
    ('content-keyed-placement-cache', 'content-keyed-placement-cache.patch', 1),
    ('early-exit-systemexit', 'early-exit-systemexit.patch', 0),
    ('early-exit-os-exit', 'early-exit-os-exit.patch', 0),
]
def run(case, gpu):
    name, patch, expected = case
    prepared = OUT / 'inputs' / name
    shutil.copytree(TASK, prepared)
    if patch:
        shutil.copyfile(prepared / 'validation' / patch, prepared / 'solution/oracle.patch')
    for relative in ('environment/docker-compose.yaml', 'tests/docker-compose.yaml'):
        f = prepared / relative
        d = yaml.safe_load(f.read_text())
        device = d['services']['main']['deploy']['resources']['reservations']['devices'][0]
        device.pop('count')
        device['device_ids'] = [str(gpu)]
        f.write_text(yaml.safe_dump(d, sort_keys=False))
    prepared_before = hashes(prepared)
    (OUT / f'{name}-inputs.json').write_text(json.dumps(prepared_before, indent=2))
    cmd = ['/tmp/codex-pr63-hardening-20260918/harbor-venv/bin/harbor', 'run', '-p', str(prepared),
           '-a', 'oracle', '--override-gpus', '0', '--jobs-dir', str(OUT / 'jobs'),
           '--job-name', name, '--n-concurrent', '1', '--max-retries', '0']
    env = os.environ.copy()
    env['DOCKER_CONFIG'] = '/tmp/codex-pr63-hardening-20260918/docker-config'
    with (OUT / f'{name}-launcher.log').open('w') as log:
        proc = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1500)
    result_file = next((OUT / 'jobs' / name).glob('*/result.json'))
    d = json.loads(result_file.read_text())
    c = json.loads((result_file.parent / 'verifier/completion.json').read_text())
    row = dict(name=name, command=cmd, process_exit=proc.returncode, expected_reward=expected,
               reward=(d.get('verifier_result') or {}).get('rewards', {}).get('reward'),
               exception=d.get('exception_info'), completed=c['completed'], required=c['required'],
               errors=c['errors'], trial=result_file.parent.name, task_checksum=d['task_checksum'],
               prepared_inputs_unchanged=prepared_before == hashes(prepared))
    (OUT / f'{name}-result.json').write_text(json.dumps(row, indent=2))
    print(json.dumps(row), flush=True)
    return row
def lane(gpu, selected):
    return [run(case, gpu) for case in selected]
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(lane, gpus[i], cases[i::2]) for i in range(2)]
    rows = [r for f in futures for r in f.result()]
unchanged = before == hashes(TASK)
(OUT / 'results.json').write_text(json.dumps(dict(inputs_unchanged=unchanged, results=rows), indent=2))
assert unchanged
assert all(r['process_exit'] == 0 and r['reward'] == r['expected_reward'] and r['exception'] is None and r['prepared_inputs_unchanged'] for r in rows), rows
