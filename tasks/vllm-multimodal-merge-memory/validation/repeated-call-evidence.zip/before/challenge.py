import json
import torch
from vllm.model_executor.models.utils import _merge_multimodal_embeddings as merge

outcomes = []
for device in ('cpu', 'cuda'):
    # Two consecutive equal-sized chunks can place the same number of image
    # embeddings at different offsets. Reuse the destination across chunks.
    dst = torch.full((19, 31), -7., dtype=torch.float16, device='cuda')
    for iteration, positions in enumerate(([0, 4, 11], [2, 7, 18], [1, 6, 13])):
        dst.fill_(-7.)
        mask = torch.zeros(19, dtype=torch.bool)
        mask[positions] = True
        values = torch.arange(93, dtype=torch.float32).reshape(3, 31) + iteration * 100
        expected = torch.full((19, 31), -7., dtype=torch.float16)
        expected[positions] = values.to(torch.float16)
        result = merge(dst, (values.cuda(),), mask.to(device))
        outcomes.append(dict(device=device, iteration=iteration,
                             correct=result is dst and torch.equal(dst.cpu(), expected)))
print(json.dumps(outcomes))
assert all(row['correct'] for row in outcomes), outcomes
