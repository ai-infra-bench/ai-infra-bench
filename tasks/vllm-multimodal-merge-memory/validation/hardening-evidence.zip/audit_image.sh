#!/usr/bin/env bash
set -euo pipefail
id
cd /workspace/repo
git rev-parse HEAD
git status --short
test -z "$(git remote)"
test -z "$(git for-each-ref --format='%(refname)' refs/remotes refs/tags)"
test -z "$(git fsck --full --no-reflogs --unreachable --no-progress 2>/dev/null)"
if git cat-file -e 4f6eed3bd4a92c6bd513460ee85b917d6df88a17 2>/dev/null; then
    echo 'ERROR: future Oracle object present'; exit 1
fi
for path in /tests /solution /validation /opt/ai-infra-verifier; do
    test ! -e "$path"
done
python3 - <<'PY'
import inspect,json,pathlib,torch,vllm
from vllm.model_executor.models.utils import _merge_multimodal_embeddings
print(json.dumps({'torch':torch.__version__,'active_source':vllm.__file__,'merge_uses_masked_scatter':'masked_scatter_' in inspect.getsource(_merge_multimodal_embeddings)}))
# The ordinary donor package is not erased by PYTHONPATH; inspect its relevant
# source instead of assuming that checkout HEAD proves image-wide isolation.
p=pathlib.Path('/usr/local/lib/python3.12/dist-packages/vllm/model_executor/models/utils.py')
s=p.read_text(); start=s.index('def _merge_multimodal_embeddings('); end=s.index('\n\ndef isin_list(',start)
print('installed_donor_merge:\n'+s[start:end])
PY
python3 -m pytest tests/models/test_utils.py -q
