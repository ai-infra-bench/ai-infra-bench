"""Formal Oracle/control runs; no model API is used."""
import hashlib,json,shutil,subprocess,time,os
from pathlib import Path
ROOT=Path('/tmp/codex-pr63-hardening-20260918')
TASK=ROOT/'vllm-multimodal-merge-memory'
HARBOR=ROOT/'harbor-venv/bin/harbor'
os.environ['DOCKER_CONFIG']=str(ROOT/'docker-config')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
records=[]
for name,expected in [('oracle',1),('early-exit-systemexit',0),('early-exit-os-exit',0),('forged-success-exit',0),('forged-checkpoint-callback',0)]:
    prepared=ROOT/'harbor-inputs'/name
    shutil.copytree(TASK,prepared)
    if name!='oracle':
        shutil.copyfile(TASK/'validation'/f'{name}.patch',prepared/'solution/oracle.patch')
    hashes={str(p.relative_to(prepared)):hashlib.sha256(p.read_bytes()).hexdigest() for p in prepared.rglob('*') if p.is_file()}
    job='pr63-hardening-'+name
    command=[str(HARBOR),'run','-p',str(prepared),'-a','oracle','--override-gpus','0','--jobs-dir',str(ROOT/'harbor-jobs'),'--job-name',job,'--n-concurrent','1']
    before=time.time()
    with (ROOT/f'harbor-{name}.log').open('w') as log:
        completed=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
    job_dir=ROOT/'harbor-jobs'/job
    trials=[]
    for f in job_dir.glob('*/result.json'):
        data=json.loads(f.read_text());vr=data.get('verifier_result') or {}
        trials.append(dict(path=str(f),reward=(vr.get('rewards') or {}).get('reward'),exception=data.get('exception_info'),checksum=data.get('task_checksum'),trial_id=data.get('id')))
    row=dict(case=name,expected_reward=expected,exit_code=completed.returncode,seconds=round(time.time()-before,3),command=command,trials=trials,input_hashes=hashes)
    records.append(row)
    (ROOT/'harbor-results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ('input_hashes','command')}),flush=True)
    # These are deterministic Oracle/control runs, not unknown model states.
    # The canonical image + exact patch reconstruct their artifacts. Retain
    # hashes and remove only huge copied binaries from OUR completed jobs.
    removed=[]
    for f in job_dir.rglob('*'):
        if f.is_file() and f.stat().st_size>100*1024*1024:
            h=hashlib.sha256()
            with f.open('rb') as stream:
                for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
            removed.append(dict(path=str(f.relative_to(job_dir)),bytes=f.stat().st_size,sha256=h.hexdigest()))
            f.unlink()
    (job_dir/'large-artifact-manifest.json').write_text(json.dumps(removed,indent=2)+'\n')
    assert len(trials)==1 and completed.returncode==0 and trials[0]['reward']==expected and trials[0]['exception'] is None, row
    assert hashes=={str(p.relative_to(prepared)):hashlib.sha256(p.read_bytes()).hexdigest() for p in prepared.rglob('*') if p.is_file()}, 'input changed'
