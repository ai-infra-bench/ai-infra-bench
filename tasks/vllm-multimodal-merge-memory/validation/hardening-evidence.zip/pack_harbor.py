from pathlib import Path
import hashlib,json,tarfile
R=Path('/tmp/codex-pr63-hardening-20260918')
rows=json.loads((R/'harbor-results.json').read_text());assert len(rows)==5
manifest=[]
for row in rows:
 job=R/'harbor-jobs'/('pr63-hardening-'+row['case'])
 trial=Path(row['trials'][0]['path']).parent
 c=json.loads((trial/'verifier/completion.json').read_text())
 assert c['completed']==(26 if row['case']=='oracle' else 0)
 row['completed_checks']=c['completed'];row['child_status']=c['child_status'];row['completion_errors']=c['errors']
 for f in (trial/'artifacts').rglob('*'):
  if f.is_file():
   h=hashlib.sha256()
   with f.open('rb') as stream:
    for b in iter(lambda:stream.read(8*1024*1024),b''):h.update(b)
   manifest.append(dict(path=str(f.relative_to(R)),bytes=f.stat().st_size,sha256=h.hexdigest()))
(R/'harbor-results.json').write_text(json.dumps(rows,indent=2)+'\n')
(R/'harbor-artifact-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(R/'harbor-evidence.tar.gz','w:gz') as t:
 for name in ['harbor-results.json','harbor-launch.log','harbor-artifact-hashes.json','run_harbor.py','pack_harbor.py']:
  t.add(R/name,arcname=name)
 for p in R.glob('harbor-*.log'):t.add(p,arcname=p.name)
 for directory in ['harbor-jobs','harbor-before-compose']:
  for p in (R/directory).rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(R)
   if 'harbor-inputs' in rel.parts:continue
   if 'artifacts' in rel.parts and p.name!='manifest.json':continue
   if p.stat().st_size>10*1024*1024:continue
   t.add(p,arcname=str(rel))
print('packed',len(manifest),'artifact hashes')
