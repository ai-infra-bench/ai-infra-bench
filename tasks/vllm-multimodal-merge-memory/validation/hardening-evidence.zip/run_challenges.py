import json,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/codex-pr63-hardening-20260918');TASK=ROOT/'vllm-multimodal-merge-memory'
records=[]
for name,patch in [('oracle','/solution/oracle.patch'),('alternative','/validation/alternative-agent-implementation.patch')]:
 command=['docker','run','--rm','--network','none','--gpus','device=0','--cpus','4','--memory','16g','--user','root','--entrypoint','bash','-v',str(TASK/'solution')+':/solution:ro','-v',str(TASK/'validation')+':/validation:ro','ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0','-lc',f'cd /workspace/repo && git -c safe.directory=/workspace/repo apply {patch} && runuser -u agent -- python3 /validation/independent_challenge.py']
 before=time.time();r=subprocess.run(command,capture_output=True,text=True,timeout=180)
 (ROOT/f'challenge-{name}.log').write_text(r.stdout+r.stderr)
 records.append(dict(name=name,command=command,exit_code=r.returncode,seconds=round(time.time()-before,3),stdout=r.stdout,stderr=r.stderr))
 (ROOT/'independent-challenges.json').write_text(json.dumps(records,indent=2)+'\n')
 assert r.returncode==0,records[-1]
 print(name,'passed',flush=True)
