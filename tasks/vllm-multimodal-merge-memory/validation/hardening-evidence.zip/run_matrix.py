"""Run declared candidates in isolated offline containers, one GPU at a time."""
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/codex-pr63-hardening-20260918')
TASK=ROOT/'vllm-multimodal-merge-memory'
IMAGE='ai-infra-bench/vllm-multimodal-merge-memory:hardening-1.3.0'
OUT=ROOT/'matrix'
OUT.mkdir(exist_ok=True)
manifest=json.loads((TASK/'validation/ci-cases.json').read_text())
cases=[dict(name='base',expected_reward=0),dict(name='oracle',expected_reward=1)]+manifest['cases']
cases += [dict(name='oracle-repeat-2',expected_reward=1,oracle=True),dict(name='oracle-repeat-3',expected_reward=1,oracle=True),dict(name='alternative-repeat-2',expected_reward=1,patch='alternative-agent-implementation.patch'),dict(name='base-repeat-2',expected_reward=0)]
image_id=subprocess.check_output(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],text=True).strip()
inputs={str(p.relative_to(TASK)):hashlib.sha256(p.read_bytes()).hexdigest() for p in TASK.rglob('*') if p.is_file() and '__pycache__' not in str(p)}
records=[]
for case in cases:
 name=case['name']; directory=OUT/name; directory.mkdir(exist_ok=True)
 command='set -e; cd /workspace/repo; '
 if name=='oracle' or case.get('oracle'):
  command+='git -c safe.directory=/workspace/repo apply /solution/oracle.patch; '
 elif 'patch' in case:
  command+='git -c safe.directory=/workspace/repo apply /validation/'+case['patch']+'; '
 command+='bash /tests/test.sh'
 args=['docker','run','--rm','--init','--name','codex-pr63-'+name,'--network','none','--gpus','device=0','--cpus','4','--memory','16g','--shm-size','1g','--user','root','--entrypoint','bash',
       '-v',str(TASK/'tests')+':/tests:ro','-v',str(TASK/'solution')+':/solution:ro','-v',str(TASK/'validation')+':/validation:ro','-v',str(directory)+':/logs/verifier',IMAGE,'-lc',command]
 started=time.time()
 with (directory/'launcher.log').open('w') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=950)
 reward_file=directory/'reward.txt'
 reward=int(reward_file.read_text().strip()) if reward_file.exists() else None
 completion=directory/'completion.json'
 record=dict(name=name,expected=case['expected_reward'],reward=reward,exit_code=result.returncode,seconds=round(time.time()-started,3),command=args,completion=json.loads(completion.read_text()) if completion.exists() else None)
 records.append(record)
 (OUT/'results.json').write_text(json.dumps(dict(image=image_id,inputs=inputs,cases=records),indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items() if k not in ('command','completion')}),flush=True)
 if reward!=case['expected_reward'] or result.returncode:
  print((directory/'launcher.log').read_text()[-2500:],flush=True)
  if (directory/'verifier.log').exists():print((directory/'verifier.log').read_text()[-3500:],flush=True)
  break
assert inputs=={str(p.relative_to(TASK)):hashlib.sha256(p.read_bytes()).hexdigest() for p in TASK.rglob('*') if p.is_file() and '__pycache__' not in str(p)},'task changed during matrix'

assert len(records)==len(cases) and all(r["reward"]==r["expected"] and r["exit_code"]==0 for r in records), "matrix did not pass"
