from pathlib import Path
import subprocess,json,sys,time,tarfile,hashlib
out=Path(sys.argv[1])
for _ in range(1000):
 s=json.loads((out/'status.json').read_text())
 if s['status']!='running':break
 time.sleep(1)
assert s['status']=='completed',s
subprocess.run(['sudo','-n','chmod','-R','a+rX',str(out)],check=True)
inputs=json.loads((out/'inputs.json').read_text())
assert all(hashlib.sha256((out/'patches'/(c['name']+'.patch')).read_bytes()).hexdigest()==c['patch_sha256'] for c in inputs['candidates'])
files=[p for p in out.rglob('*') if p.is_file() and not p.is_symlink() and p.name not in ['collector.log','collection.json','collection-manifest.json','evidence.tar.gz']]
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'collection-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(out/'collection-manifest.json')
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
p=out/'evidence.tar.gz';(out/'collection.json').write_text(json.dumps({'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(files)}))
