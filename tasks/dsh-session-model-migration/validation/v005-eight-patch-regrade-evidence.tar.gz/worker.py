from pathlib import Path
import json,subprocess,sys,time,concurrent.futures,hashlib,traceback
out=Path(sys.argv[1]);inputs=json.loads((out/'inputs.json').read_text());state={'status':'running','started_at':time.time(),'image_id':inputs['image_id'],'cases':[]}
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
def run(c):
 patch=out/'patches'/(c['name']+'.patch');assert hashlib.sha256(patch.read_bytes()).hexdigest()==c['patch_sha256']
 with (out/(c['name']+'-worker.log')).open('w') as log:r=subprocess.run(['/usr/bin/python3',str(out/'run-case.py'),str(out),c['name'],str(patch),inputs['image_id']],stdout=log,stderr=subprocess.STDOUT,timeout=1250)
 assert r.returncode==0,c['name']
 result=json.loads((out/(c['name']+'.json')).read_text());assert result['grading']['child_exit_code'] is not None,result
 assert result['patch_sha256']==c['patch_sha256']
 assert result['image_id']==inputs['image_id'] and result['network_mode']=='none'
 return result
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for f in concurrent.futures.as_completed([pool.submit(run,c) for c in inputs['candidates']]):
   state['cases'].append(f.result());save()
 assert len(state['cases'])==8
 state.update(status='completed',finished_at=time.time());save()
except Exception:
 state.update(status='failed',error=traceback.format_exc(),finished_at=time.time());save();raise
