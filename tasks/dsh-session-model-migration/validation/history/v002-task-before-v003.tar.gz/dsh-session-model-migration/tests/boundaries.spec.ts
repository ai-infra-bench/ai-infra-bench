import { afterEach, expect, it } from 'vitest'
import { LlmAdapter } from '@deepseek-ai/dsh-llm'
import { resolveProfiles } from '@deepseek-ai/dsh-llm-pi-ai/src/config.ts'
import { resolveRouteModels } from '@deepseek-ai/dsh-llm-pi-ai/src/catalog.ts'
import { cleanup, endpoint, completion, responseText, harness, profile, turn, migrate } from './support.ts'

afterEach(cleanup)

class SmallCatalog extends LlmAdapter {
  async resolveModel(provider: string, model: string) {
    return { provider, id: model, name: model, context: { contextWindow: 32 }, defaultMaxTokens: 32 }
  }
  async *stream(): AsyncIterable<any> { throw new Error('admission must not generate') }
}

it('rejects an empty session whose explicit output cap exceeds destination capacity', async () => {
  const h = await harness({})
  h.ctx.llm.registerAdapter(['destination'], new SmallCatalog())
  const agent = h.create('main', { maxTokens: 177 })
  const before = agent.session.snapshotEvents()
  await expect(migrate(h, agent)).rejects.toThrow(/context|window|fit|budget|capacity/i)
  expect(agent.session.snapshotEvents()).toEqual(before)
})

it('accepts an installed Responses model when its protocol is inherited from the catalog', async () => {
  // The existing catalog supplies the protocol for known models without source.api.
  const profiles = { openai: { models: [{ id: 'gpt-4.1' }], baseURL: 'http://127.0.0.1:1' } }
  const catalog = resolveRouteModels({ provider: 'openai', ...profiles.openai, defaultInput: ['text'], defaultContextWindow: 65536, defaultMaxTokens: 128 })
  expect(catalog.models.map(model => model.api)).toEqual(['openai-responses'])
  expect(() => resolveProfiles(profiles)).not.toThrow()
  expect(() => resolveProfiles({ openai: { ...profiles.openai, responsesReasoningText: true } })).not.toThrow()
})

it('preserves an explicit output allowance after migration and reopening saved events', async () => {
  const source = await endpoint(), destination = await endpoint()
  source.scripts.push(completion('Retained work with a caller-owned output allowance.'))
  const h = await harness({
    origin: profile(source.url, 'openai-completions', 'old-model'),
    destination: profile(destination.url, 'openai-responses', 'next-model', { responsesReasoningText: true }),
  })
  const agent = h.create('main', { maxTokens: 177 })
  await turn(h.ctx, agent, 'Keep my output allowance.')
  expect(agent.session.requestHeader().config.maxTokens).toBe(177)
  await migrate(h, agent)
  const reopened = await h.reopen(agent.session.snapshotEvents())
  destination.scripts.push(responseText('Resumed.'))
  await turn(h.ctx, reopened, 'Continue after reopening.')
  expect(destination.requests).toHaveLength(1)
  expect(destination.requests[0].body.max_output_tokens).toBe(177)
})

it('keeps distinct provider tool IDs paired when their pipe prefixes coincide', async () => {
  const source = await endpoint(), destination = await endpoint()
  source.scripts.push(completion('Inspect two independent values.', [
    { id: 'shared|opaque_a', value: 'alpha' },
    { id: 'shared|opaque_b', value: 'beta' },
  ], 'Both observations matter.'), completion('Both observations saved.'))
  const h = await harness({
    origin: profile(source.url, 'openai-completions', 'old-model'),
    destination: profile(destination.url, 'openai-responses', 'next-model', { responsesReasoningText: true }),
  })
  const agent = h.create()
  await turn(h.ctx, agent, 'Record both values.')
  expect(h.recorded).toEqual(['alpha', 'beta'])
  await migrate(h, agent)
  destination.scripts.push(responseText('Reviewed both observations.'))
  await turn(h.ctx, agent, 'Review all retained observations.')
  const input = destination.requests[0].body.input
  const calls = input.filter((item: any) => item.type === 'function_call')
  const results = input.filter((item: any) => item.type === 'function_call_output')
  expect(calls).toHaveLength(2)
  expect(new Set(calls.map((call: any) => call.call_id)).size).toBe(2)
  expect(results).toHaveLength(2)
  for (const call of calls) {
    const matches = results.filter((result: any) => result.call_id === call.call_id)
    expect(matches).toHaveLength(1)
    expect(matches[0].output).toContain(`recorded:${JSON.parse(call.arguments).value}`)
  }
})
