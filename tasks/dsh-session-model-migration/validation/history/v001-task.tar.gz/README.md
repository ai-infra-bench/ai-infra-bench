# Checked session model migration

Implement [the migration request](instruction.md) in DeepSeek Harness: admit a session-local model change only when retained work fits the destination, preserve the selection across reopening, and support an opt-in Responses gateway that needs historical plaintext reasoning with tool calls.

This is a constructed feature scenario informed by upstream discussions [#1780](https://github.com/deepseek-ai/deepseek-harness/discussions/1780) and [#1410](https://github.com/deepseek-ai/deepseek-harness/discussions/1410). It does not claim to reproduce a historical deployment or prescribe a community patch. [HelpMatey PR #1](https://github.com/HelpMatey/deepseek-harness/pull/1) addresses related compaction behavior; this task deliberately checks migration without automatic compaction.

## Environment

Base is `deepseek-ai/deepseek-harness@4e84901e6471b79ec0338099867ebb4606d12bb5`, dated September 1, 2026. The image contains the complete source and its locked dependencies, Node 22.23.2, pnpm 11.7.0, Python, Git, build tools, and ripgrep. It uses 4 CPUs, 8 GiB RAM, 20 GiB storage, and a 36,000-second agent budget. Agent and verifier run offline; protocol fixtures use loopback HTTP. No real model credentials or GPUs are required.

The Dockerfile pins the parent image and Debian snapshot, checks out only Base history, and removes fetch metadata, remotes, tags, reflogs, and unreachable objects. Tests, solutions, and control patches enter only after the agent phase. The built image identity and dependency provenance are recorded in `environment/`.

## Verification

The verifier executes 18 deterministic cases through the existing Session Controller business operation, real Loader composition, LLM runtime, pi-ai serialization, session projections, token meter, agent loop, and tools. Only model catalog answers and model-generated HTTP events are fixtures. The work tool writes a real file, and the follow-up request must include its result.

| Cases | Observable behavior |
|---|---|
| Migration workflow | Historical calls and results survive; a reopened session continues on the destination and executes another tool; rejected migration can continue on its original model |
| Admission | Exact fit, complete history and request overhead, explicit versus adapter-default output allowance, unknown capacity, empty sessions, queued/running sessions, stale asynchronous checks |
| Compatibility | Provider and model changes, ordered plaintext reasoning, foreign metadata removal, parallel call pairing, native replay fidelity, missing reasoning, default-off behavior, configuration rejection |
| Regression | Legacy model selection remains permissive and persists the deployment default |

Reward is binary: all expected cases must finish and pass. A separate Python parent validates the exact result collection and starts reward at zero, so an early native process exit cannot earn credit. Tests assert gateway content and call pairing without prescribing the internal projection function or generated call-ID spelling.

## Validation

Base scores 0 in two clean Docker runs; the reference scores 1 in two runs, and the alternative implementation also scores 1. All five incorrect controls score 0, including native process termination before test completion. All eight candidate classes pass their expected Harbor rewards with zero trial exceptions. Final Oracle passes 18/18. See [the review](validation/review.md) and [run evidence](validation/e2e-evidence.json).

A fresh GPT-5.6 Sol (`high`, Codex 0.118.0) trial completed normally in 51m 49s: **reward 1, 18/18 tests**, with no Harbor exceptions or retries. See [solver-run evidence](validation/model-run/README.md) for the exact submission and full scored trajectory. This single run is separate from Base/Oracle validation.

## Layout

```text
instruction.md                    Agent-facing feature request
task.toml                        Harbor configuration
 environment/Dockerfile           Clean Base environment
 environment/image-manifest.json  Built image identity
 environment/lock/manifest.json   Dependency provenance
 solution/solve.sh                Oracle entrypoint
 solution/feature.patch           Reference code, docs, and source tests
 tests/                           Behavioral verifier and external fixtures
 validation/ci-cases.json          Correct alternative and wrong controls
 validation/*.patch               Full patches against Base, curator-only
 validation/e2e-evidence.json      Final executable hashes and run evidence
 validation/review.md              Scenario, environment, and verifier review
```

## Running

From the benchmark repository:

```bash
harbor run -p tasks/dsh-session-model-migration -a nop -e docker
harbor run -p tasks/dsh-session-model-migration -a oracle -e docker
harbor run -p tasks/dsh-session-model-migration -a codex -m <model> -e docker
python .github/scripts/task_ci.py validate dsh-session-model-migration
```

The task remains in development. The reference is newly authored rather than a merged upstream PR. Changing executable task files requires rerunning the affected Base, Oracle, controls, and Harbor cases.
