# Task review

Retain this task. The scenario, environment, and behavioral verification pass the three review gates. No blocking finding remains. This is a separate post-construction review by the primary agent, not an independent second-agent review. The task remains an uncommitted development candidate; no solver-model evaluation or publication is claimed.

## Scenario

The task requests existing-session model selection, destination context admission, and a declared gateway extension. These are plausible operations at the existing Session Controller, token-meter, LLM runtime, and pi-ai interfaces. Discussions #1780 and #1410 motivate the failure modes; their reports are not treated as reproduced incidents. The plaintext Responses representation is an explicit constructed gateway contract, not a claim that every OpenAI endpoint accepts it. The task does not require automatic compaction, generic format conversion, image downgrade, or guaranteed future capacity.

## Environment and cutoff

Semantic boundary: checked `selectModel` request → actual agent quiescence and session revision, destination capability resolution, token-meter estimation, durable model selection → reopened agent dispatch → real pi-ai HTTP serialization → tool execution → next model request containing the tool result.

The session controller business class is the stable entrypoint. Loader, registry, agent loop, session log and projections, token meter, provider routing, native replay conversion, HTTP clients, and tool runtime run for real. Only external catalog answers and model-generated event streams are deterministic substitutes. They preserve protocol shape, order, call cardinality, terminal events, and continuation. No arbitrary model answer is used as a correctness judge. Reopening round-trips saved events through JSON into a fresh agent, rather than mocking selection persistence.

The Base image contains the source and exact Base lockfile installation. Git isolation checks pass with no remotes, tags, reflogs, fetch metadata, unreachable objects, or mounted task files. Two original upstream suites pass 25 tests before verifier mounts. The semantic protocol libraries' registry dates precede the cutoff; vendored runtime code is pinned by Base. The image is retained locally on the validation host's build and Harbor Docker daemons. It has no published registry digest; the recorded SHA-256 is its Docker image ID.

## Behavioral coverage and fairness

| Requirement | Tests and actual observations |
|---|---|
| Successful migration and reopening | Real source tool calls write alpha/beta; saved events reopen on the destination; a new call writes gamma; the next request carries its result |
| Failed migration is atomic | Too-small destination leaves events and settings unchanged; the old route generates successfully afterward |
| Destination budgeting | Real token meter includes retained messages and latest system/tools; exact fit succeeds; one-token excess fails; previous usage totals do not substitute for destination repricing |
| Output allowance | Explicit allowance survives; source adapter default is replaced by the destination default; missing window or allowance rejects even empty sessions |
| Quiescence and races | Pending input, active generation, and transient queue changes during awaited catalog resolution reject without committing selection |
| Session locality | Sibling selection and persisted deployment default remain unchanged; legacy selection continues to update the default |
| Reasoning and call pairing | Provider and model changes preserve ordered plaintext reasoning, assistant text, and parallel tool pairs; foreign opaque and item state is absent |
| Compatibility boundaries | Native same-route opaque replay is retained; missing reasoning is not fabricated; default-off route serialization is retained; incompatible protocol configuration rejects |

The correct alternative uses a final HTTP payload hook with request-local marker replacement and a two-pass call mapping. The reference uses pi-ai's JSON replay carrier and deterministic call mapping before serialization. Both pass 18/18. Tests do not require either approach or a particular generated call ID. The reasoning assertions were widened to permit harmless additional destination fields while still rejecting foreign opaque/item state; the final suite was rerun afterward.

An independent review probe adds a second failed migration after a successful pending selection, then reopens before dispatch. Both correct implementations preserve the pending destination and retained work. This is a separate local probe, not a scored test or a Docker/Harbor trial.

## Runs

| Candidate | Final Docker evidence | Harbor reward |
|---|---:|---:|
| Base | 6/18 passed, twice; failure is missing requested behavior | 0 |
| Reference | 18/18 passed, twice | 1 |
| Alternative payload projection | 18/18 passed | 1 |
| No capacity check | 15/18 passed | 0 |
| No revision check | 17/18 passed | 0 |
| Saves global default | 17/18 passed | 0 |
| No reasoning transfer | 15/18 passed | 0 |
| Native early exit | Workers terminate before assertions complete | 0 |

The original `process.exit(0)` control was intercepted by Vitest and is superseded by the final `process.reallyExit(0)` control. Its marker appears at the intended selection boundary in three worker processes. The Vitest parent exits 1 and the grading wrapper writes reward 0. Vitest's JSON even reports `success: true` with incomplete tests in this case, demonstrating why the wrapper also checks child status, exact completed collection, pass counts, and skipped/pending counts. Final Docker and Harbor results use the native-exit patch hash in the manifest; earlier intercepted-exit logs remain only as superseded raw history.

All eight required candidate classes have completed Harbor trials with zero trial exceptions. The strengthened native-exit case and Oracle were rerun last. Final Oracle job `80c57a34-7910-4ca8-8d4f-7b10bd663088`, trial `oracle-final__Jcbkxnv`, scores 1 with 18/18 passed and no skips.

## Evidence and limits

[Machine-readable evidence](e2e-evidence.json) records hashes, commands, image identity, candidate results, and the final Harbor input checksum. [The evidence archive](evidence.tar.gz) contains raw Docker, image-audit, and Harbor logs/results. Harbor copies were prepared with the exact retained image tag injected into their task configuration; the submitted task keeps its reproducible Dockerfile. Later evidence and documentation additions change the directory checksum without changing the executed behavior. The review probe is curator-only and was run separately.

The scenario checks an estimate at selection time, not exact model tokenization, future prompt size, or provider availability. It exercises a declared local reasoning gateway, not a real external model endpoint. Focused source compilation, legacy suites, an owner-local keyless request snapshot, and bilingual documentation checks passed. A complete upstream lint/build/doc-sync gate and a real solver evaluation remain outside this validation claim.
