"""Run candidate code in a child; require every expected assertion to finish."""
from collections import Counter
import json
import os
from pathlib import Path
import subprocess

tests = Path(__file__).resolve().parent
root = Path(os.environ.get("DSH_ROOT", "/workspace/deepseek-harness"))
logs = Path(os.environ.get("DSH_LOGS", "/logs/verifier"))
logs.mkdir(parents=True, exist_ok=True)
report = logs / "results.json"
report.unlink(missing_ok=True)
(logs / "reward.txt").write_text("0\n")
(logs / "reward.json").unlink(missing_ok=True)
reward = 0
reason = "verifier did not complete"
code = None
try:
    expected = Counter(json.loads((tests / "expected-tests.json").read_text()))
    env = dict(os.environ, DSH_REPORT=str(report), DSH_ROOT=str(root), CI="true")
    with (logs / "vitest.log").open("w") as stream:
        result = subprocess.run(
            ["node", str(root / "node_modules/vitest/vitest.mjs"), "run", "--configLoader", "native", "--config", str(tests / "vitest.config.mjs")],
            cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=480,
        )
    code = result.returncode
    data = json.loads(report.read_text())
    suites = data["testResults"]
    assertions = [case for suite in suites for case in suite["assertionResults"]]
    actual = Counter(case["fullName"] for case in assertions)
    complete = actual == expected and all(case["status"] == "passed" for case in assertions)
    success = (
        code == 0 and complete and data["success"] is True
        and data["numTotalTests"] == sum(expected.values())
        and data["numPassedTests"] == sum(expected.values())
        and data["numFailedTests"] == 0 and data["numPendingTests"] == 0
        and data.get("numTodoTests", 0) == 0
        and all(suite["status"] == "passed" for suite in suites)
    )
    reward = int(success)
    reason = "all required tests passed" if success else "failed, skipped, or incomplete tests"
except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as error:
    reason = f"incomplete verification: {type(error).__name__}: {error}"
finally:
    (logs / "reward.txt").write_text(f"{reward}\n")
    (logs / "grading-details.json").write_text(json.dumps({"reward": reward, "child_exit_code": code, "reason": reason}, indent=2) + "\n")
    print(json.dumps({"reward": reward, "child_exit_code": code, "reason": reason}))
