import { afterEach, describe, expect, it } from 'vitest'
import { LlmAdapter, createUserMessage } from '@deepseek-ai/dsh-llm'
import { cleanup, endpoint, completion, harness, profile, turn, migrate } from './support.ts'

afterEach(cleanup)

/** Only substitutes the external model catalog/generation; all session logic is real. */
class Catalog extends LlmAdapter {
  window: number | undefined = 100000
  output: number | undefined = 32
  pause?: () => Promise<void>
  requests: any[] = []
  generation?: () => Promise<void>
  async resolveModel(provider: string, model: string) {
    await this.pause?.()
    return { provider, id: model, name: model, ...(this.window === undefined ? {} : { context: { contextWindow: this.window } }), ...(this.output === undefined ? {} : { defaultMaxTokens: this.output }) }
  }
  async *stream(options: any): AsyncIterable<any> {
    this.requests.push(options)
    await this.generation?.()
    yield { type: 'block-start', index: 0, blockType: 'text' }
    yield { type: 'text-delta', index: 0, text: 'continued' }
    yield { type: 'block-end', index: 0, block: { type: 'text', text: 'continued' } }
    yield { type: 'finish', reason: { kind: 'stop' } }
  }
}
async function setup(options = {}) {
  const origin = await endpoint()
  origin.scripts.push(completion('Reasonably long retained work. '.repeat(60)))
  const h = await harness({ origin: profile(origin.url, 'openai-completions', 'old-model') })
  const catalog = new Catalog()
  h.ctx.llm.registerAdapter(['destination'], catalog)
  const agent = h.create('main', options)
  await turn(h.ctx, agent, 'Retain the complete observations and tool definitions.')
  return { h, agent, catalog, origin }
}
function estimate(h: any, agent: any, maxTokens = 32) {
  const previous = agent.session.requestHeader()
  return h.ctx.tokenMeter.measure(agent.session, { ...previous, config: { ...previous.config, provider: 'destination', model: 'next-model', maxTokens } }).totalTokens
}

describe('destination budget and admission', () => {
  it('allows exact fit, reprices history and tools, and checks an already selected route again', async () => {
    const { h, agent, catalog } = await setup()
    const input = estimate(h, agent)
    expect(input).toBeGreaterThan(400)
    const headerless = h.ctx.tokenMeter.measure(agent.session, { config: { provider: 'destination', model: 'next-model', maxTokens: 32 } }).totalTokens
    expect(input).toBeGreaterThan(headerless)
    catalog.window = input + 32 - 1
    const before = agent.session.snapshotEvents()
    await expect(migrate(h, agent)).rejects.toThrow()
    expect(agent.session.snapshotEvents()).toEqual(before)
    catalog.window++
    await migrate(h, agent)
    expect(h.agents.selectionFor(agent).current.provider).toBe('destination')
    const selected = agent.session.snapshotEvents()
    catalog.window--
    await expect(migrate(h, agent)).rejects.toThrow()
    expect(agent.session.snapshotEvents()).toEqual(selected)
    expect(catalog.requests).toHaveLength(0)
  })

  it('replaces the old adapter output default with the destination default', async () => {
    const { h, agent, catalog } = await setup()
    expect(agent.session.requestHeader().adapterDefaults.maxTokens).toBe(true)
    catalog.window = estimate(h, agent) + 32
    await migrate(h, agent)
    await turn(h.ctx, agent, 'Continue.')
    expect(catalog.requests).toHaveLength(1)
    expect(catalog.requests[0].maxTokens).toBe(32)
  })

  it('retains an explicit output allowance through admission and continuation', async () => {
    const { h, agent, catalog } = await setup({ maxTokens: 177 })
    expect(agent.session.requestHeader().config.maxTokens).toBe(177)
    const input = estimate(h, agent, 177)
    catalog.window = input + 176
    await expect(migrate(h, agent)).rejects.toThrow()
    catalog.window++
    await migrate(h, agent)
    await turn(h.ctx, agent, 'Continue.')
    expect(catalog.requests[0].maxTokens).toBe(177)
  })

  it.each(['window', 'output'] as const)('refuses unknown destination %s even on an empty session', async missing => {
    const h = await harness({})
    const catalog = new Catalog(); catalog[missing] = undefined
    h.ctx.llm.registerAdapter(['destination'], catalog)
    const agent = h.create()
    const before = agent.session.snapshotEvents()
    await expect(migrate(h, agent)).rejects.toThrow(/window|output|capacity|allowance|unknown|context/i)
    expect(agent.session.snapshotEvents()).toEqual(before)
    expect(catalog.requests).toHaveLength(0)
  })

  it('admits an empty session at a window equal to its output allowance', async () => {
    const h = await harness({}), catalog = new Catalog()
    catalog.window = catalog.output
    h.ctx.llm.registerAdapter(['destination'], catalog)
    const agent = h.create()
    await migrate(h, agent)
    expect(h.agents.selectionFor(agent).current.provider).toBe('destination')
    expect(catalog.requests).toHaveLength(0)
  })

  it('rejects queued input without consuming or rewriting it', async () => {
    const { h, agent, catalog } = await setup()
    agent.inbox.append('next-step', createUserMessage({ content: [{ type: 'text', text: 'pending work' }], source: { kind: 'user' } }))
    const before = agent.session.snapshotEvents()
    await expect(migrate(h, agent)).rejects.toThrow(/idle|pending|queued|busy/i)
    expect(agent.session.snapshotEvents()).toEqual(before)
    expect(agent.inbox.nextStep).toHaveLength(1)
    expect(catalog.requests).toHaveLength(0)
  })

  it('rejects stale checks when the session changes during catalog lookup', async () => {
    const { h, agent, catalog } = await setup()
    const entered = Promise.withResolvers<void>(), release = Promise.withResolvers<void>()
    catalog.pause = async () => { entered.resolve(); await release.promise }
    const checking = migrate(h, agent)
    const rejected = expect(checking).rejects.toThrow(/changed|retry|idle|pending|busy/i)
    await entered.promise
    agent.inbox.append('next-step', createUserMessage({ content: [{ type: 'text', text: 'briefly queued' }], source: { kind: 'user' } }))
    agent.inbox.clear()
    const changed = agent.session.snapshotEvents()
    release.resolve()
    await rejected
    expect(agent.session.snapshotEvents()).toEqual(changed)
    expect(h.agents.selectionFor(agent).current.provider).toBe('origin')
  })

  it('refuses migration during an active generation with no queued input', async () => {
    const { h, agent, catalog } = await setup()
    await migrate(h, agent)
    const entered = Promise.withResolvers<void>(), release = Promise.withResolvers<void>()
    catalog.generation = async () => { entered.resolve(); await release.promise }
    const running = turn(h.ctx, agent, 'Keep working.')
    await entered.promise
    expect(agent.status).toBe('running')
    expect(agent.inbox.hasPending).toBe(false)
    const before = agent.session.snapshotEvents()
    try {
      await expect(migrate(h, agent)).rejects.toThrow(/idle|running|busy/i)
      expect(agent.session.snapshotEvents()).toEqual(before)
    } finally { release.resolve(); await running }
    expect(catalog.requests).toHaveLength(1)
  })

  it('keeps legacy selection permissive and saves its deployment default', async () => {
    const { h, agent, catalog } = await setup()
    catalog.window = 1
    await h.commands.selectModel({ sessionId: agent.session.id, provider: 'destination', model: 'next-model' })
    expect(h.agents.selectionFor(agent).current.provider).toBe('destination')
    expect(h.ctx.agentDefaultModel.currentSelection().provider).toBe('destination')
  })
})
