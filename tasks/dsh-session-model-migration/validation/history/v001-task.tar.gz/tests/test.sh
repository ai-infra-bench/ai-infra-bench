#!/usr/bin/env bash
set -euo pipefail
exec python3 /tests/grade.py
