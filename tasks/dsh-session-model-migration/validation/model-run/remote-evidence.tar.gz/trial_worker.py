import importlib.util,json,os,subprocess,sys,time,toml
from pathlib import Path
root=Path(sys.argv[1]);out=root/'dsh-migration-model-20260910'
os.environ['PATH']=str(root/'bin')+':'+str(root/'.venv/bin')+':'+os.environ.get('PATH','/usr/bin:/bin')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
record={'status':'preflight','started_at':time.time(),'model':'gpt-5.6-sol','reasoning_effort':'high','max_output_tokens':32768,'codex_version':'0.118.0','source_commit':'4e84901e6471b79ec0338099867ebb4606d12bb5','compaction':'native remote; normal default threshold'}
def save():(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 subprocess.run([str(root/'.venv/bin/python'),str(out/'probe.py'),'--base-url','http://127.0.0.1:19878/v1','--model','gpt-5.6-sol','--out',str(out/'model-preflight.json')],check=True)
 ci=out/'task_ci.py';spec=importlib.util.spec_from_file_location('task_ci',ci);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 image='ai-infra-bench-local/dsh-session-model-migration:solver-codex-011800';case=out/'case';m.prepare_case(out/'task',image,'base',case)
 capture='''set -eu
cd /workspace/deepseek-harness
mkdir -p /tmp/benchmark-submission
git rev-parse HEAD > /tmp/benchmark-submission/head.txt
git status --short > /tmp/benchmark-submission/status.txt
idx=$(mktemp /tmp/submission-index.XXXXXX)
trap 'rm -f "$idx"' EXIT
cp .git/index "$idx"
export GIT_INDEX_FILE="$idx"
git add -N --all -- .
git diff --binary 4e84901e6471b79ec0338099867ebb4606d12bb5 > /tmp/benchmark-submission/submission.patch
git diff --stat 4e84901e6471b79ec0338099867ebb4606d12bb5 > /tmp/benchmark-submission/diff-stat.txt
'''
 config=toml.loads((case/'task.toml').read_text())
 config['verifier']['collect']=[{'command':capture,'timeout_sec':120}]
 config['artifacts']=[{'source':'/tmp/benchmark-submission','destination':'submission'}]
 from harbor.models.task.config import TaskConfig
 TaskConfig.model_validate(config)
 (case/'task.toml').write_text(toml.dumps(config))
 (out/'prepared-task.toml').write_text((case/'task.toml').read_text())
 job='dsh-migration-gpt56-sol-high'
 cmd=[str(root/'.venv/bin/python'),str(out/'harbor_cli.py'),'--egress-context',str(out/'egress-context'),'--legacy-docker-build','--egress-base-image','harbor-prebuilt:harbor-docker-egress-control-sidecar--b1e6760734a9e6f6','--','run','--path',str(case),'--agent','codex','--env','docker','--jobs-dir',str(out/'jobs'),'--job-name',job,'--n-concurrent','1','--no-delete','--environment-kwarg','keep_containers=true','--yes','--model','gpt-5.6-sol','--agent-kwarg','version=0.118.0','--agent-kwarg','reasoning_effort=high','--agent-kwarg','web_search=disabled','--allow-agent-host','10.37.124.162','--agent-env','OPENAI_API_KEY=router-local','--agent-env','OPENAI_BASE_URL=http://10.37.124.162:19878/v1']
 record.update(status='running',argv=cmd,image=image,agent_started_at=time.time());save();print('TRIAL_START',flush=True)
 p=subprocess.run(cmd);record.update(cli_exit_code=p.returncode,finished_at=time.time())
 result_path=out/'jobs'/job/'result.json'
 if result_path.exists():record['result']=json.loads(result_path.read_text())
 record['submission_patches']=[str(p.relative_to(out)) for p in (out/'jobs').glob('**/artifacts/submission/submission.patch')]
 record['status']='completed' if p.returncode==0 and record.get('result',{}).get('stats',{}).get('n_errored_trials')==0 else 'infrastructure_error'
 save();print('TRIAL_DONE',record['status'],flush=True)
except Exception as exc:
 record.update(status='launcher_error',error_type=type(exc).__name__,finished_at=time.time());save();raise
