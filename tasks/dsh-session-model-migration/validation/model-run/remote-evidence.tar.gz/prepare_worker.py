import subprocess,json,sys,os,time,getpass
from pathlib import Path
root=Path(sys.argv[1]);out=root/'dsh-migration-model-20260910'
os.environ['PATH']=str(root/'bin')+':'+str(root/'.venv/bin')+':'+os.environ['PATH']
image='ai-infra-bench-local/dsh-session-model-migration:solver-codex-011800'
build=out/'solver-image';build.mkdir()
(build/'Dockerfile').write_text('FROM ai-infra-bench-local/dsh-code-mode-parallel-dispatch:solver-codex-011800 AS tooling\nFROM ai-infra-bench/dsh-session-model-migration:base-4e84901e6471\nCOPY --from=tooling /usr/local/bin/codex /usr/local/bin/codex\nRUN codex --version\n')
with (out/'build.log').open('w') as log:subprocess.run(['docker','build','--network=none','-t',image,str(build)],stdout=log,stderr=subprocess.STDOUT,check=True)
(out/'image-inspect.json').write_text(subprocess.check_output(['docker','image','inspect',image],text=True))
audit='''set -e
cd /workspace/deepseek-harness
test "$(git rev-parse HEAD)" = 4e84901e6471b79ec0338099867ebb4606d12bb5
test -z "$(git status --porcelain)"
test -z "$(git remote)"
for p in /tests /solution /validation; do test ! -e "$p"; done
codex --version
'''
p=subprocess.run(['docker','run','--rm','--network=none',image,'bash','-lc',audit],capture_output=True,text=True);(out/'image-audit.log').write_text(p.stdout+p.stderr);p.check_returncode()
cmd=['sudo','-n','systemd-run','--unit=aib-dsh-migration-model-relay','--collect','--uid='+getpass.getuser(),'--property=StandardOutput=append:'+str(out/'relay.log'),'--property=StandardError=append:'+str(out/'relay.log'),str(root/'.venv/bin/python'),str(out/'relay.py'),'--upstream','http://[fdbd:dc03:13:632:9d28:21c:a500:ea]:19877','--port','19878']
subprocess.run(cmd,check=True)
import urllib.request
for _ in range(30):
 try:
  with urllib.request.urlopen('http://127.0.0.1:19878/health',timeout=3) as r:
   if r.status==200:break
 except Exception:time.sleep(1)
else:raise RuntimeError('Relay did not become ready')
subprocess.run([str(root/'.venv/bin/python'),str(out/'trial_worker.py'),str(root)],check=True)
