"""Verify native compaction AND continuation before spending a benchmark trial."""
import argparse
import json
import os
from pathlib import Path
import uuid

import httpx


def probe(base_url: str, model: str) -> dict:
    marker = 'COMPACT_' + uuid.uuid4().hex
    result = {'model': model, 'base_url': base_url, 'passed': False}
    with httpx.Client(timeout=660, trust_env=False,
                      headers={'authorization': 'Bearer ' + os.environ.get('OPENAI_API_KEY', 'router-local')}) as client:
        compact = client.post(base_url.rstrip('/') + '/responses/compact', json={
            'model': model, 'input': [{'role': 'user', 'content': 'Remember this identifier for later: ' + marker}],
        })
        result['compact_status'] = compact.status_code
        if compact.status_code != 200:
            return result
        body = compact.json()
        if body.get('object') != 'response.compaction' or not any(
            item.get('type') == 'compaction' and item.get('encrypted_content') for item in body.get('output', [])
        ):
            result['error'] = 'Missing native compaction output'
            return result
        # The entire compacted window is canonical, including retained messages.
        response = client.post(base_url.rstrip('/') + '/responses', json={
            'model': model, 'input': body['output'] + [{'role': 'user', 'content': 'Return only the identifier I asked you to remember.'}],
            'max_output_tokens': 512, 'reasoning': {'effort': 'low'}, 'stream': False,
        })
        result['continuation_status'] = response.status_code
        if response.status_code != 200:
            return result
        answer = response.json()
        text = ''.join(part.get('text', '') for item in answer.get('output', [])
                       if item.get('type') == 'message' for part in item.get('content', []))
        result['response_status'] = answer.get('status')
        result['memory_preserved'] = text.strip() == marker
        result['passed'] = answer.get('status') == 'completed' and result['memory_preserved']
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url', required=True, help='Client API base ending in /v1')
    parser.add_argument('--model', default='gpt-5.6-sol')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = probe(args.base_url, args.model)
    except (httpx.RequestError, ValueError) as error:
        # Never print exception URLs: upstream credentials can live in query params.
        result = {'passed': False, 'error_type': type(error).__name__}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
