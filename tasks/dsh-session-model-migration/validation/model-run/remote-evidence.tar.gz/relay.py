"""Credential-free remote relay for Responses create and native compaction."""
from __future__ import annotations

import argparse
import json

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.background import BackgroundTask
import uvicorn

HOP_HEADERS = {'host', 'content-length', 'connection', 'transfer-encoding',
               'keep-alive', 'proxy-authenticate', 'proxy-authorization',
               'te', 'trailer', 'upgrade', 'accept-encoding'}


def forward_headers(headers):
    blocked = HOP_HEADERS | {s.strip().lower() for s in headers.get('connection', '').split(',')}
    return {k: v for k, v in headers.items() if k.lower() not in blocked}


def create_app(upstream: str, *, timeout: float = 660, max_output_tokens: int = 32768,
               transport: httpx.AsyncBaseTransport | None = None) -> FastAPI:
    app = FastAPI()
    base = upstream.rstrip('/')

    @app.get('/health')
    async def health():
        async with httpx.AsyncClient(trust_env=False, timeout=10, transport=transport) as client:
            response = await client.get(base + '/healthz')
        return JSONResponse({'upstream_status': response.status_code}, status_code=response.status_code)

    @app.post('/v1/responses')
    @app.post('/v1/responses/compact')
    async def responses(request: Request):
        raw = await request.body()
        if request.url.path == '/v1/responses':
            try:
                payload = json.loads(raw)
                payload.setdefault('max_output_tokens', max_output_tokens)
                raw = json.dumps(payload).encode()
            except (ValueError, AttributeError):
                return JSONResponse({'error': {'message': 'Expected a JSON object'}}, status_code=400)
        # Compaction has its own schema: preserve the body, including opaque items.
        url = httpx.URL(base + request.url.path).copy_merge_params(request.query_params)
        client = httpx.AsyncClient(trust_env=False, timeout=httpx.Timeout(timeout, connect=10), transport=transport)
        req = client.build_request('POST', url, content=raw, headers=forward_headers(request.headers))
        try:
            response = await client.send(req, stream=True)
        except httpx.RequestError as error:
            await client.aclose()
            return JSONResponse({'error': {'message': 'Model router unavailable'}},
                                status_code=504 if isinstance(error, httpx.TimeoutException) else 502)

        async def close():
            await response.aclose()
            await client.aclose()

        async def chunks():
            try:
                async for chunk in response.aiter_raw():
                    yield chunk
            finally:
                await close()

        return StreamingResponse(chunks(), status_code=response.status_code,
                                 headers=forward_headers(response.headers), background=BackgroundTask(close))

    return app


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--upstream', required=True, help='Local capture router origin, without /v1')
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=19866)
    args = parser.parse_args()
    uvicorn.run(create_app(args.upstream), host=args.host, port=args.port, access_log=False)


if __name__ == '__main__':
    main()
