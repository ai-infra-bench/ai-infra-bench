"""Run Harbor with a separately built egress sidecar that allows slow HTTP replies.

No installed Harbor files or global Docker tags are modified. Network policy,
HTTP sniffing, and hostname allowlist enforcement remain unchanged.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys

import yaml


def prepare_egress_context(source: Path, destination: Path, *, read_timeout: int = 720,
                           base_image: str | None = None) -> None:
    if read_timeout <= 0:
        raise ValueError('read_timeout must be positive')
    config = yaml.safe_load((source / 'gost.yaml').read_text())
    handlers = [service['handler'] for service in config['services']
                if service.get('handler', {}).get('type') == 'red']
    if len(handlers) != 1:
        raise ValueError('Expected exactly one Harbor transparent egress handler')
    handlers[0].setdefault('metadata', {})['readTimeout'] = f'{read_timeout}s'
    shutil.copytree(source, destination)
    (destination / 'gost.yaml').write_text(yaml.safe_dump(config, sort_keys=False))
    if base_image is not None:
        # A retained Harbor sidecar already contains the exact pinned GOST binary.
        # Reuse it offline while preserving all original COPY/entrypoint behavior.
        if not base_image or any(c.isspace() for c in base_image):
            raise ValueError('base_image must be a single Docker image reference')
        (destination / 'Dockerfile').write_text(
            'FROM ' + base_image + '\nCOPY gost.yaml /opt/egress-sidecar/gost.yaml\n')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--egress-context', type=Path, required=True,
                        help='New directory for the auditable patched build context')
    parser.add_argument('--egress-base-image', help='Optional retained sidecar image for offline builds')
    parser.add_argument('--egress-read-timeout', type=int, default=720)
    parser.add_argument('--legacy-docker-build', action='store_true',
                        help='Prebuild with docker build when the host lacks Buildx; requires a retained sidecar base')
    parser.add_argument('harbor_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.legacy_docker_build and not args.egress_base_image:
        parser.error('--legacy-docker-build requires --egress-base-image')
    from harbor.environments.docker.docker import DockerEnvironment
    source = DockerEnvironment._EGRESS_CONTROL_SIDECAR_CONTEXT_PATH
    prepare_egress_context(source, args.egress_context,
                           read_timeout=args.egress_read_timeout, base_image=args.egress_base_image)
    DockerEnvironment._EGRESS_CONTROL_SIDECAR_CONTEXT_PATH = args.egress_context.resolve()
    DockerEnvironment._EGRESS_CONTROL_SIDECAR_DOCKER_NAME = 'ai-infra-bench-local:harbor-egress-timeout'
    if args.legacy_docker_build:
        from harbor.utils.container_cache import docker_build_context_hash
        platform = subprocess.check_output(
            ['docker', 'version', '--format', '{{.Server.Os}}/{{.Server.Arch}}'], text=True).strip()
        digest = docker_build_context_hash(context=args.egress_context,
            dockerfile_path=args.egress_context / 'Dockerfile', build_args={}, platform=platform)
        image = DockerEnvironment._EGRESS_CONTROL_SIDECAR_DOCKER_NAME + '--' + digest
        exists = subprocess.run(['docker', 'image', 'inspect', image],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if exists.returncode:
            subprocess.run(['docker', 'build', '--network=none', '--platform=' + platform,
                            '-t', image, str(args.egress_context)], check=True)
    from harbor.cli.main import app
    argv = args.harbor_args
    if argv[:1] == ['--']:
        argv = argv[1:]
    sys.argv = ['harbor', *argv]
    app()


if __name__ == '__main__':
    main()
