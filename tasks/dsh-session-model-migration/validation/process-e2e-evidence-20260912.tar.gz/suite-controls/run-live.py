#!/usr/bin/env python3
"""One live migration attempt; preserve failures, never silently reroll.
Requires live-proxy.py on a reachable credential-owning machine.
"""
import argparse,json,time,uuid,urllib.request,traceback
from pathlib import Path
from run import Host,check,disk,dump
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/workspace/deepseek-harness'));p.add_argument('--proxy',required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args()
args.out.mkdir(parents=True);world=args.out/'world';world.mkdir();(world/'.dsh').mkdir()
(world/'invoice-a.txt').write_text('Invoice A: 137\n');(world/'invoice-b.txt').write_text('Invoice B: 251\n')
model='gpt-6-astra'
def profile(api,path):
    # Conservative declared fixture capacities, not a claim about the model's true limit.
    return {'apiKeyEnv':'MIGRATION_FIXTURE_KEY','baseURL':args.proxy+path,'api':api,'models':[{'id':model,'contextWindow':65536,'maxTokens':16384,'reasoningEfforts':{'high':'high'}}],'reasoning':'high','retryPolicy':{'mode':'normal','maxRetries':0}}
providers={'origin':profile('openai-completions','/source'),'destination':{**profile('openai-responses','/destination'),'responsesReasoningText':True}}
overlay=args.out/'overlay.json';dump(overlay,[{'id':'llm-deepseek','disabled':True},{'id':'session-title-llm','disabled':True},{'id':'agent-instructions','disabled':True},{'id':'agent-default-model','config':{'provider':'origin','model':model}},{'id':'llm-pi-ai','config':{'providers':providers}},{'id':'agent-presets','config':{'default':'minimal','includeUserRoot':False}},{'id':'session-persistence-jsonl','config':{'root':str(world/'.dsh/sessions'),'packChunks':False}}])
host=None;sid='live-'+uuid.uuid4().hex;stage='boot';result={'status':'running','model':model,'effort':'high','source':'https://aidp.bytedance.net/api/modelhub/online/v2/crawl','destination':'https://aidp.bytedance.net/api/modelhub/online/responses'}
def wire():
    with urllib.request.urlopen(args.proxy+'/evidence',timeout=10) as r:return json.load(r)
def turn(text):
    start=len(wire())
    host.rpc('session/prompt',{'request':{'sessionId':sid,'requestId':str(uuid.uuid4()),'mode':'queue','content':[{'type':'text','text':text}]}})
    deadline=time.monotonic()+240
    while time.monotonic()<deadline:
        records=wire();dump(args.out/'wire.json',records)
        failures=[r for r in records[start:] if r['status']!=200]
        check(not failures,'live upstream failure: '+json.dumps(failures,ensure_ascii=False)[-1500:])
        rows=host.rpc('session/list',{'_request':{}})['items'];row=next(x for x in rows if x['sessionId']==sid)
        if len(records)>start and not row['running']:return records[start:]
        time.sleep(.5)
    raise TimeoutError('live turn did not settle')
try:
    host=Host(args.root,world,'first',overlay,args.out);host.create(sid);stage='source-real-inference'
    source=turn('Read invoice-a.txt and invoice-b.txt using tools, in separate calls. Keep the amounts for later; do not write a report yet.')
    check(any(any(x.get('role')=='tool' and '137' in str(x.get('content')) for x in r['body'].get('messages',[])) for r in source),'model did not obtain real invoice A tool result')
    check(any(any(x.get('role')=='tool' and '251' in str(x.get('content')) for x in r['body'].get('messages',[])) for r in source),'model did not obtain real invoice B tool result')
    before_count=len(wire());stage='checked-migration';host.select(sid,'destination',model);check(len(wire())==before_count,'admission generated')
    host.stop();first_pid=host.pid;host=None;before=disk(world,args.out,'before-restart')
    stage='disk-restart';host=Host(args.root,world,'second',overlay,args.out);check(host.pid!=first_pid,'process reused');host.create(sid)
    stage='destination-real-inference';destination=turn('Using the amounts already inspected, write report.txt containing exactly three lines: A=<amount>, B=<amount>, Total=<sum>. Verify the file with a tool.')
    check((world/'report.txt').read_text()=='A=137\nB=251\nTotal=388\n','live model did not produce the correct report')
    first=destination[0]['body'];inputs=first['input']
    check(any(x.get('type')=='function_call' for x in inputs),'historical tool calls missing')
    check(any(x.get('type')=='function_call_output' and '137' in str(x.get('output')) for x in inputs),'historical tool data missing')
    source_reasoning=any('reasoning_content' in r['response'] for r in source)
    if source_reasoning:check(any(x.get('type')=='reasoning' and any(c.get('type')=='reasoning_text' for c in x.get('content',[])) for x in inputs),'plaintext reasoning lost')
    host.stop();host=None;after=disk(world,args.out,'after-restart')
    for key,value in before.items():check(after[key]['rows'][:len(value['rows'])]==value['rows'],'persisted history changed')
    result.update(status='passed',source_returned_reasoning=source_reasoning,session_id=sid)
except Exception:result.update(status='failed',stage=stage,error=traceback.format_exc())
finally:
    if host is not None:
        try:host.stop()
        except Exception:result['shutdown_error']=traceback.format_exc()
    dump(args.out/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
check(result['status']=='passed','live acceptance did not pass')
