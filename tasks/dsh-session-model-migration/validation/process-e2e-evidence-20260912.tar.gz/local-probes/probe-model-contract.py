from pathlib import Path
import json,ast,urllib.request,urllib.error,urllib.parse,time
from dotenv import dotenv_values
root=Path('/tmp/aib-dsh-migration-process-e2e-design-20260912')
failed=json.loads((root/'live-proxy-reverse/live-wire.json').read_text())[-1]
keys=ast.literal_eval(dotenv_values('/home/tiger/.env')['GPT56_EXPERIMENT_API_KEYS'])
results=[]
for add_summary in [False,True]:
 body=json.loads(json.dumps(failed['body']));body['model']='gpt-5.6-sol'
 if add_summary:
  for item in body['input']:
   if item.get('type')=='reasoning' and 'summary' not in item:item['summary']=[]
 req=urllib.request.Request('https://aidp.bytedance.net/api/modelhub/online/responses?ak='+urllib.parse.quote(keys[0],safe=''),data=json.dumps(body).encode(),headers={'Content-Type':'application/json','extra':json.dumps({'session_id':failed['affinity']+'-model-contract'})})
 start=time.time()
 try:
  with urllib.request.urlopen(req,timeout=180) as r:status=r.status;response=r.read().decode()
 except urllib.error.HTTPError as e:status=e.code;response=e.read().decode()
 record={'diagnostic_only':True,'model':body['model'],'added_empty_summary':add_summary,'status':status,'elapsed':time.time()-start,'request':body,'response':response}
 results.append(record)
 print(json.dumps({k:v for k,v in record.items() if k not in ('request','response')}),flush=True);print(response[-700:] if status!=200 else 'accepted',flush=True)
(root/'model-contract-probes.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
