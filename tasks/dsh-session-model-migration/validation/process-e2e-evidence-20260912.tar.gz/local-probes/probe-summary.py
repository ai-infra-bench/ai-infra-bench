from pathlib import Path
import json,ast,urllib.request,urllib.error,urllib.parse,time
from dotenv import dotenv_values
root=Path('/tmp/aib-dsh-migration-process-e2e-design-20260912')
records=json.loads((root/'live-proxy-reverse/live-wire.json').read_text());failed=records[-1];body=json.loads(json.dumps(failed['body']))
changed=0
for item in body['input']:
 if item.get('type')=='reasoning' and 'summary' not in item:item['summary']=[];changed+=1
keys=ast.literal_eval(dotenv_values('/home/tiger/.env')['GPT56_EXPERIMENT_API_KEYS'])
req=urllib.request.Request('https://aidp.bytedance.net/api/modelhub/online/responses?ak='+urllib.parse.quote(keys[1],safe=''),data=json.dumps(body).encode(),headers={'Content-Type':'application/json','extra':json.dumps({'session_id':failed['affinity']})})
start=time.time()
try:
 with urllib.request.urlopen(req,timeout=180) as r:status=r.status;response=r.read().decode()
except urllib.error.HTTPError as e:status=e.code;response=e.read().decode()
evidence={'diagnostic_only':True,'change':'add summary=[] to foreign reasoning items; no tool execution','changed_items':changed,'status':status,'elapsed':time.time()-start,'request':body,'response':response}
(root/'summary-field-probe.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in evidence.items() if k not in ('request','response')}));print(response[-500:] if status!=200 else 'upstream accepted patched request')
