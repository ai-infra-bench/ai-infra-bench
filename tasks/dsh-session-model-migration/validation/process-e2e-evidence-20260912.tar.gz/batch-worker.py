from pathlib import Path
import subprocess,json,time,hashlib,concurrent.futures,traceback,sys
root=Path(sys.argv[1]);out=root/'dsh-migration-process-e2e-20260912';suite=out/'suite-frozen'
patches={'gpt6-1': 'dsh-migration-v004-gpt6-high-once-20260912/jobs/dsh-migration-v004-gpt6-astra-high-once/case__Ey7yT2X/artifacts/submission.patch', 'gpt6-2': 'dsh-migration-v004-gpt6-high-add3-20260912/jobs/dsh-migration-v004-gpt6-astra-high-add3/case__Sfw335Z/artifacts/submission.patch', 'gpt6-3': 'dsh-migration-v004-gpt6-high-add3-20260912/jobs/dsh-migration-v004-gpt6-astra-high-add3/case__FGnstyx/artifacts/submission.patch', 'gpt6-4': 'dsh-migration-v004-gpt6-high-add3-20260912/jobs/dsh-migration-v004-gpt6-astra-high-add3/case__aLS8Drb/artifacts/submission.patch', 'gpt56-1': 'dsh-migration-v004-gpt56-high-once-20260912/jobs/dsh-migration-v004-gpt56-sol-high-once/case__E89Wy6M/artifacts/submission.patch', 'gpt56-2': 'dsh-migration-v004-gpt56-high-add3-20260912/jobs/dsh-migration-v004-gpt56-sol-high-add3/case__P9dmn43/artifacts/submission.patch', 'gpt56-3': 'dsh-migration-v004-gpt56-high-add3-20260912/jobs/dsh-migration-v004-gpt56-sol-high-add3/case__RsWH5V8/artifacts/submission.patch', 'gpt56-4': 'dsh-migration-v004-gpt56-high-add3-20260912/jobs/dsh-migration-v004-gpt56-sol-high-add3/case__QcBJFX3/artifacts/submission.patch', 'oracle': 'dsh-migration-v004-20260912/acceptance/task/solution/feature.patch', 'alternative': 'dsh-migration-v004-20260912/acceptance/task/validation/alternative-payload-projection.patch'}
image='sha256:c31d8ae990656c65a0abec4f9518356f60d7d293fd4b095240a4c1e27621d98a'
manifest={'image':image,'suite':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in suite.iterdir() if p.is_file()},'patches':{k:hashlib.sha256((root/v).read_bytes()).hexdigest() for k,v in patches.items()}}
(out/'batch-inputs.json').write_text(json.dumps(manifest,indent=2))
def run(name):
 resultdir=out/'batch'/name;resultdir.mkdir(parents=True,exist_ok=True)
 command='git update-index --refresh && git apply --index /candidate.patch && node_modules/.bin/tsdown --env.DSH_BUILD_FACE host > /case/build.log 2>&1 && node_modules/.bin/tsdown --env.DSH_BUILD_FACE client >> /case/build.log 2>&1 && python3 /suite/run.py --out /case/acceptance'
 cmd=['sudo','-n','docker','run','--rm','--name','aib-process-'+name,'--network=none','--cpus=4','--memory=8g','-v',str(root/patches[name])+':/candidate.patch:ro','-v',str(suite)+':/suite:ro','-v',str(resultdir)+':/case',image,'bash','-lc',command]
 start=time.time()
 try:
  with (resultdir/'run.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  path=resultdir/'acceptance/results.json'
  result={'candidate':name,'exit':r.returncode,'elapsed':time.time()-start,'results':json.loads(path.read_text()) if path.exists() else None}
 except Exception:result={'candidate':name,'error':traceback.format_exc()}
 (resultdir/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);return result
names=['gpt6-4','gpt56-1','alternative','oracle','gpt6-1','gpt6-2','gpt6-3','gpt56-2','gpt56-3','gpt56-4']
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(run,names):
  results.append(result);(out/'batch-results.json').write_text(json.dumps(results,indent=2))
assert all(hashlib.sha256((suite/n).read_bytes()).hexdigest()==h for n,h in manifest['suite'].items())
(out/'batch-complete.json').write_text(json.dumps({'completed':True,'inputs_unchanged':True,'candidates':len(results)}))
