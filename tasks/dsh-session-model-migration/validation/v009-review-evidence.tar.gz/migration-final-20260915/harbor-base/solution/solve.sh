#!/bin/bash
set -eu
true
