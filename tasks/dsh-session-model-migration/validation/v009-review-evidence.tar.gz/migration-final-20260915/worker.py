from pathlib import Path
import concurrent.futures, hashlib, json, os, shutil, subprocess, sys, time, traceback
import toml

remote, out = map(Path, sys.argv[1:3])
os.environ['PATH'] = str(remote / 'bin') + ':' + str(remote / '.venv/bin') + ':' + os.environ.get('PATH', '/usr/bin:/bin')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP'] = 'True'
base = 'sha256:e87af67674c9b180ee88328bffd4b4279c1324c0567ac86be943f951287a2b0a'
previous_verifier = 'sha256:2e24ed0b4adaf895aa1fb0f974d1560c674fc775c016d05fe464eac484471aae'
task = out / 'task'
state = {'status': 'building', 'results': [], 'started_at': time.time(), 'base_image': base}
def save():
    temp = out / 'final-state.tmp'
    temp.write_text(json.dumps(state, indent=2))
    temp.replace(out / 'final-state.json')

def read_json(path):
    return json.loads(subprocess.check_output(['sudo', '-n', 'cat', str(path)]))

def run(case):
    name = case['name']
    folder = out / ('harbor-' + name)
    shutil.copytree(task, folder)
    if case['patch'] is None:
        (folder / 'solution/solve.sh').write_text('#!/bin/bash\nset -eu\ntrue\n')
    else:
        shutil.copyfile(out / case['patch'], folder / 'solution/feature.patch')
    cfg = toml.loads((folder / 'task.toml').read_text())
    cfg['environment']['docker_image'] = base
    cfg['verifier']['environment']['docker_image'] = state['verifier_image']
    (folder / 'task.toml').write_text(toml.dumps(cfg))
    command = [str(remote / '.venv/bin/harbor'), 'run', '--path', str(folder), '--agent', 'oracle', '--env', 'docker',
               '--jobs-dir', str(out / 'jobs'), '--job-name', name, '--n-attempts', '1', '--n-concurrent', '1', '--max-retries', '0', '--yes']
    record = dict(case, command=command, started_at=time.time())
    try:
        with (out / ('harbor-' + name + '.log')).open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=1500)
        record['exit_code'] = result.returncode
        trials = list((out / 'jobs' / name).glob('*/result.json'))
        record['trials'] = []
        for p in trials:
            trial = read_json(p)
            row = {'path': str(p.parent), 'trial': trial['trial_name'], 'checksum': trial.get('task_checksum'),
                   'reward': (trial.get('verifier_result') or {}).get('rewards', {}).get('reward'),
                   'exception': (trial.get('exception_info') or {}).get('exception_type')}
            for fn, key in [('grading-details.json', 'grading'), ('process/results.json', 'process')]:
                f = p.parent / 'verifier' / fn
                if f.exists(): row[key] = read_json(f)
            f = p.parent / 'verifier/results.json'
            if f.exists():
                data = read_json(f)
                row['unit'] = {k: data.get(k) for k in ['numTotalTests', 'numPassedTests', 'numFailedTests']}
                row['failed'] = [a['fullName'] for s in data.get('testResults', []) for a in s['assertionResults'] if a['status'] != 'passed']
            record['trials'].append(row)
        expected = case.get('expected_reward')
        record['matches'] = len(record['trials']) == 1 and result.returncode == 0 and all(
            r['exception'] is None and (expected is None or r['reward'] == expected) for r in record['trials'])
    except Exception:
        record['error'] = traceback.format_exc()
        record['matches'] = False
    record['seconds'] = time.time() - record['started_at']
    (out / (name + '.json')).write_text(json.dumps(record, indent=2))
    return record

save()
try:
    recipe = out / 'Dockerfile'
    recipe.write_text('FROM ' + previous_verifier + '\nCOPY . /tests\nRUN chmod -R a+rX /tests && chmod -R a-w /tests\n')
    tag = 'ai-infra-bench/dsh-session-model-migration:audit-v009-20260915'
    with (out / 'build.log').open('w') as log:
        subprocess.run(['sudo', '-n', 'docker', 'build', '--network=none', '-t', tag, '-f', str(recipe), str(task / 'tests')], check=True, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    state['verifier_image'] = subprocess.check_output(['sudo', '-n', 'docker', 'image', 'inspect', '--format', '{{.Id}}', tag], text=True).strip()
    state['input_hashes'] = {str(p.relative_to(task)): hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file()}
    cases = json.loads((out / 'cases.json').read_text())
    state['status'] = 'formal_controls'
    save()
    controls, models = [c for c in cases if c.get('expected_reward') is not None], [c for c in cases if c.get('expected_reward') is None]
    for group in [controls, models]:
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(run, c) for c in group]
            for f in concurrent.futures.as_completed(futures):
                state['results'].append(f.result())
                save()
        if not all(r['matches'] for r in state['results']):
            raise RuntimeError('formal control/replay failed; inspect recorded evidence')
        state['status'] = 'model_patch_replays'
        save()
    state['status'] = 'completed'
except Exception:
    state.update(status='failed', error=traceback.format_exc())
state['finished_at'] = time.time()
save()
