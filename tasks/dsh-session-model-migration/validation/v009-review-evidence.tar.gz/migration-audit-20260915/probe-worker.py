from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, sys, time, traceback

out = Path(sys.argv[1])
image = 'sha256:2e24ed0b4adaf895aa1fb0f974d1560c674fc775c016d05fe464eac484471aae'
cases = [
    ('original-oracle', 'original/tests', 'oracle.patch'),
    ('original-stale-budget', 'original/tests', 'stale-source-budget.patch'),
    ('original-renamed-catalog', 'original/tests', 'renamed-private-catalog.patch'),
    ('challenge-oracle', 'challenge-tests', 'oracle.patch'),
    ('challenge-stale-budget', 'challenge-tests', 'stale-source-budget.patch'),
]

def run(case):
    name, tests, patch = case
    log = out / 'results' / name
    log.mkdir(parents=True)
    container = 'aib-migration-audit-0915-' + name
    cmd = ['sudo', '-n', 'docker', 'run', '--name', container, '--network=none', '--cpus=4', '--memory=8g',
           '-v', str(out / tests) + ':/tests:ro',
           '-v', str(out / 'patches' / patch) + ':/tmp/benchmark-submission/submission.patch:ro',
           '-v', str(log) + ':/logs/verifier', image, 'bash', '/tests/test.sh']
    start = time.time()
    record = dict(name=name, command=cmd, patch_sha256=hashlib.sha256((out / 'patches' / patch).read_bytes()).hexdigest(), image=image)
    try:
        with (log / 'entry.log').open('w') as f:
            result = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, timeout=1200)
        record['exit_code'] = result.returncode
        subprocess.run(['sudo', '-n', 'chmod', '-R', 'a+rX', str(log)], check=True)
        for filename, key in [('grading-details.json', 'grading'), ('process/results.json', 'process')]:
            if (log / filename).exists(): record[key] = json.loads((log / filename).read_text())
        if (log / 'results.json').exists():
            result = json.loads((log / 'results.json').read_text())
            record['unit'] = {k: result.get(k) for k in ['numTotalTests', 'numPassedTests', 'numFailedTests']}
            record['failed'] = [a for s in result['testResults'] for a in s['assertionResults'] if a['status'] != 'passed']
    except Exception:
        record['error'] = traceback.format_exc()
    finally:
        subprocess.run(['sudo', '-n', 'docker', 'rm', '-f', container], capture_output=True)
    record['seconds'] = time.time() - start
    (out / (name + '.json')).write_text(json.dumps(record, indent=2))
    return record

state = {'status': 'running', 'results': []}
def save(): (out / 'probe-state.json').write_text(json.dumps(state, indent=2))
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for r in pool.map(run, cases):
        state['results'].append(r)
        save()
state['status'] = 'completed'
save()
