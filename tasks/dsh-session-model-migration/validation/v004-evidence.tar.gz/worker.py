from pathlib import Path
import subprocess,json,sys,os,time,hashlib,shutil,toml,traceback
root=Path(sys.argv[1]);out=root/'dsh-migration-v004-20260912/acceptance';task=out/'task'
os.environ['PATH']=str(root/'bin')+':'+str(root/'.venv/bin')+':'+os.environ.get('PATH','/usr/bin:/bin')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
docker=['sudo','-n','docker'];image='ai-infra-bench/dsh-session-model-migration:verifier-v004'
state={'status':'building','started_at':time.time(),'docker':[],'harbor':[],'source_checks':[]}
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def run(cmd,log,timeout=600):
 start=time.time()
 with log.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 return {'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start,'log':str(log.relative_to(out))}
def files():return {str(p.relative_to(task)):hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file()}
try:
 save()
 base_id='sha256:e87af67674c9b180ee88328bffd4b4279c1324c0567ac86be943f951287a2b0a'
 assert subprocess.check_output(docker+['image','inspect','--format','{{.Id}}','ai-infra-bench/dsh-session-model-migration:base-4e84901e6471'],text=True).strip()==base_id
 canonical=(task/'tests/Dockerfile').read_text(); prefix=(task/'environment/Dockerfile').read_text();assert canonical.startswith(prefix)
 recipe=out/'verifier-offline.Dockerfile';recipe.write_text('FROM '+base_id+'\n'+canonical[len(prefix):])
 state['offline_build']={'base_image_id':base_id,'recipe_sha256':hashlib.sha256(recipe.read_bytes()).hexdigest(),'canonical_prefix_matches_base_dockerfile':True}
 build=run(docker+['build','--network=none','-t',image,'-f',str(recipe),str(task/'tests')],out/'image-build.log',3600);state['build']=build;save();assert build['exit_code']==0
 info=json.loads(subprocess.check_output(docker+['image','inspect',image]))[0];(out/'verifier-image.json').write_text(json.dumps(info,indent=2))
 manifest=json.loads((task/'environment/verifier-image-manifest.json').read_text());manifest.update(canonical_tag=image,image_id=info['Id'],size_bytes=info['Size'],created=info['Created']);(task/'environment/verifier-image-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 frozen=files();(out/'pre-run-inputs.json').write_text(json.dumps({'files':frozen,'image_id':info['Id'],'at':time.time()},indent=2))
 state.update(status='source-checks',image_id=info['Id']);save()
 for tag,label in [(base_id,'base'),('sha256:4b75c8abbccecc9370e27dc9c62423b603174fa1998bbc0416959c383c31e56b','solver')]:
  (out/(label+'-image-inspect.json')).write_bytes(subprocess.check_output(docker+['image','inspect',tag]))
  (out/(label+'-image-history.txt')).write_bytes(subprocess.check_output(docker+['history','--no-trunc',tag]))
 audit="""set -eu
cd /workspace/deepseek-harness
test "$(git rev-parse HEAD)" = 4e84901e6471b79ec0338099867ebb4606d12bb5
test -z "$(git status --porcelain)"
test -z "$(git remote)"
test -z "$(git for-each-ref --format='%(refname)' refs/remotes refs/tags)"
test ! -e .git/logs
test ! -e .git/FETCH_HEAD
test -z "$(git fsck --full --no-reflogs --unreachable 2>/dev/null)"
test ! -e /tests
test ! -e /solution
test ! -e /validation
node -e 'console.log(process.version)'
"""
 record=run(docker+['run','--rm','--network=none',base_id,'bash','-c',audit],out/'base-isolation.log',180);state['base_isolation']=record;assert record['exit_code']==0
 record=run(docker+['run','--rm','--network=none','sha256:4b75c8abbccecc9370e27dc9c62423b603174fa1998bbc0416959c383c31e56b','bash','-c',audit],out/'solver-isolation.log',180);state['solver_isolation']=record;assert record['exit_code']==0

 script='''set -eu
cd /workspace/deepseek-harness
git apply /candidate.patch
node node_modules/typescript/bin/tsc -b packages/api/session-controller/tsconfig.host.json packages/llm/llm-pi-ai/tsconfig.json --pretty false
'''
 (out/'source-types.sh').write_text(script)
 record=run(docker+['run','--rm','--network=none','--cpus=4','--memory=8g','-v',str(task/'solution/feature.patch')+':/candidate.patch:ro','-v',str(out/'source-types.sh')+':/source-check.sh:ro',image,'bash','/source-check.sh'],out/'source-types.log',600);state['source_checks'].append(record);save();assert record['exit_code']==0,'type check failed'
 script='''set -eu
cd /workspace/deepseek-harness
git apply /candidate.patch
node node_modules/vitest/vitest.mjs run packages/api/session-controller/tests/migration-boundaries.spec.ts packages/api/session-controller/tests/model-migration.spec.ts packages/api/session-controller/tests/session-models.host.spec.ts packages/core/agent-loop/tests/request-reconstruction.spec.ts packages/core/agent-loop/tests/loop.spec.ts packages/llm/llm-pi-ai/tests/config.spec.ts
'''
 (out/'source-tests.sh').write_text(script)
 record=run(docker+['run','--rm','--network=none','--cpus=4','--memory=8g','-v',str(task/'solution/feature.patch')+':/candidate.patch:ro','-v',str(out/'source-tests.sh')+':/source-check.sh:ro',image,'bash','/source-check.sh'],out/'source-tests.log',600);state['source_checks'].append(record);save();assert record['exit_code']==0,'source regressions failed'
 empty=out/'base.patch';empty.write_text('')
 cases=[('base',empty,0),('oracle',task/'solution/feature.patch',1)]
 cases += [(c['name'],task/'validation'/c['patch'],c['expected_reward']) for c in json.loads((task/'validation/ci-cases.json').read_text())['cases']]
 for name,artifact in [
  ('gpt6-v003',root/'dsh-migration-v003-gpt6-high-once-20260911/jobs/dsh-migration-v003-gpt6-astra-high-once/case__PUbRw5t/artifacts/submission.patch'),
  ('gpt56-v003',root/'dsh-migration-v003-gpt56-high-once-20260911/continuation-trials/case__H9sV2Wz_resume1/artifacts/submission.patch')]:
  dest=out/(name+'.patch');shutil.copy2(artifact,dest);cases.append((name,dest,0))
 cases += [('oracle-stability',task/'solution/feature.patch',1),('alternative-stability',task/'validation/alternative-payload-projection.patch',1)]
 state['status']='grading-controls';save()
 for name,patch,expected in cases:
  logs=out/'docker-results'/name;logs.mkdir(parents=True)
  record=run(docker+['run','--rm','--network=none','--cpus=4','--memory=8g','-v',str(patch)+':/tmp/benchmark-submission/submission.patch:ro','-v',str(logs)+':/logs/verifier',image,'bash','/tests/test.sh'],logs/'entrypoint.log',600)
  data=json.loads((logs/'results.json').read_text()) if (logs/'results.json').exists() else {}
  record.update(name=name,patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),reward=float((logs/'reward.txt').read_text()),expected_reward=expected,passed=data.get('numPassedTests'),total=data.get('numTotalTests'),failures=[{'name':a['fullName'],'messages':a['failureMessages']} for s in data.get('testResults',[]) for a in s['assertionResults'] if a['status']!='passed'])
  state['docker'].append(record);save()
  assert expected is None or record['reward']==expected, 'unexpected control reward: '+name
 state['status']='harbor';save()
 for name in ['oracle','early-exit','forged-report']:
  case=out/('harbor-'+name);shutil.copytree(task,case)
  if name!='oracle':shutil.copy2(task/'validation'/(name+'.patch'),case/'solution/feature.patch')
  config=toml.loads((case/'task.toml').read_text());config['environment']['docker_image']='ai-infra-bench/dsh-session-model-migration:base-4e84901e6471';config['verifier']['environment']['docker_image']=info['Id'];(case/'task.toml').write_text(toml.dumps(config))
  cmd=[str(root/'.venv/bin/harbor'),'run','--path',str(case),'--agent','oracle','--env','docker','--jobs-dir',str(out/'jobs'),'--job-name','v004-'+name,'--n-attempts','1','--n-concurrent','1','--max-retries','0','--yes']
  record=run(cmd,out/('harbor-'+name+'.log'),900)
  result=out/'jobs'/('v004-'+name)/'result.json';record.update(name=name,result=json.loads(result.read_text()) if result.exists() else None)
  trial_results=list((out/'jobs'/('v004-'+name)).glob('*/result.json'));record['trials']=[json.loads(p.read_text()) for p in trial_results]
  state['harbor'].append(record);save()
  rewards=[t.get('verifier_result',{}).get('rewards',{}).get('reward') for t in record['trials']]
  assert record['exit_code']==0 and rewards==[1.0 if name=='oracle' else 0.0], 'Harbor failed: '+name
 assert frozen==files(),'executable inputs changed'
 (out/'post-run-inputs.json').write_text(json.dumps({'matches_pre_run':True,'at':time.time()}))
 state.update(status='completed',finished_at=time.time());save()
except Exception:
 state.update(status='failed',error=traceback.format_exc(),finished_at=time.time());save();raise
