/** Portable plaintext reasoning for explicitly configured Chat routes. */
import { createHash } from 'node:crypto'
import type { Api, Context, Model } from '@earendil-works/pi-ai'

/**
 * Build detached request messages for Chat endpoints accepting reasoning_content.
 * pi-ai uses thinkingSignature as a field-name selector in this protocol; the
 * literal below is new serialization metadata, never a copied opaque signature.
 * Persisted messages and same-route native replay are left unchanged.
 */
export function projectChatReasoning(context: Context, model: Model<Api>): Context {
  const used = new Set(context.messages.flatMap(message => message.role === 'assistant'
    ? message.content.flatMap(block => block.type === 'toolCall' ? [block.id] : []) : []))
  const calls = new Map<string, string>()
  const allocate = (original: string): string => {
    const stem = `call_${createHash('sha256').update(original).digest('hex').slice(0, 48)}`
    let id = stem
    for (let suffix = 1; used.has(id); suffix++) id = `${stem}_${suffix}`
    used.add(id)
    return id
  }
  const messages = context.messages.map(message => {
    if (message.role === 'toolResult') {
      const id = calls.get(message.toolCallId)
      return id === undefined || id === message.toolCallId
        ? message : { ...message, toolCallId: id }
    }
    if (message.role !== 'assistant') return message
    if (message.api === model.api && message.provider === model.provider && message.model === model.id) {
      for (const block of message.content) {
        if (block.type === 'toolCall') calls.set(block.id, block.id)
      }
      return message
    }
    return {
      role: message.role,
      api: model.api,
      provider: model.provider,
      model: model.id,
      timestamp: message.timestamp,
      usage: message.usage,
      stopReason: message.stopReason,
      content: message.content.flatMap((block): typeof message.content => {
        if (block.type === 'thinking') {
          if (block.redacted || block.thinking.trim() === '') return []
          return [{ type: 'thinking', thinking: block.thinking, thinkingSignature: 'reasoning_content' }]
        }
        if (block.type === 'text') return [{ type: 'text', text: block.text }]
        const id = allocate(block.id)
        calls.set(block.id, id)
        return [{ type: 'toolCall', id, name: block.name, arguments: block.arguments }]
      }),
    }
  })
  return { ...context, messages }
}
