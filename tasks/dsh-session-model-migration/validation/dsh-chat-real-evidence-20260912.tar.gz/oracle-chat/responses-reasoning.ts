/** Plaintext reasoning projection for explicitly configured Responses gateways. */
import { createHash } from 'node:crypto'
import type { Api, Context, Model } from '@earendil-works/pi-ai'

/**
 * Translate foreign assistant records without borrowing provider-native identities.
 * The destination gateway accepts fresh plaintext reasoning items; opaque replay
 * metadata remains valid only for the exact route that produced it.
 * @param context - detached request history, never the durable Session events.
 * @param model - actual destination model descriptor.
 * @returns a request projection with consistently renamed foreign tool pairs.
 */
export function projectResponsesReasoning(context: Context, model: Model<Api>): Context {
  const calls = new Map<string, string>()
  const messages = context.messages.map(message => {
    if (message.role === 'toolResult') {
      const id = calls.get(message.toolCallId)
      return id === undefined ? message : { ...message, toolCallId: id }
    }
    if (message.role !== 'assistant') return message
    const native = message.api === model.api && message.provider === model.provider && message.model === model.id
    if (native) return message
    const { responseId: _responseId, responseModel: _responseModel, ...foreign } = message
    return {
      ...foreign,
      api: model.api,
      provider: model.provider,
      model: model.id,
      content: message.content.flatMap((block): typeof message.content => {
        if (block.type === 'thinking') {
          if (block.redacted || block.thinking.trim() === '') return []
          return [{
            type: 'thinking',
            thinking: block.thinking,
            thinkingSignature: JSON.stringify({
              type: 'reasoning',
              content: [{ type: 'reasoning_text', text: block.thinking }],
            }),
          }]
        }
        if (block.type === 'text') return [{ type: 'text', text: block.text }]
        const id = `call_${createHash('sha256').update(block.id).digest('hex').slice(0, 48)}`
        calls.set(block.id, id)
        return [{ type: 'toolCall', id, name: block.name, arguments: block.arguments }]
      }),
    }
  })
  return { ...context, messages }
}
