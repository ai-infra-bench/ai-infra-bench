"""Apply a source submission in a fresh verifier and validate completed results."""
from collections import Counter
import ctypes
import json
import os
from pathlib import Path
import subprocess

tests = Path(__file__).resolve().parent
root = Path(os.environ.get("DSH_ROOT", "/workspace/deepseek-harness"))
logs = Path(os.environ.get("DSH_LOGS", "/logs/verifier"))
logs.mkdir(parents=True, exist_ok=True)
logs.chmod(0o700)
report = logs / "results.json"
report.unlink(missing_ok=True)
(logs / "reward.txt").write_text("0\n")
(logs / "reward.json").unlink(missing_ok=True)
reward = 0
reason = "verifier did not complete"
code = None


def no_new_privileges():
    # Inherited by the runner and its unprivileged test workers.
    if ctypes.CDLL(None, use_errno=True).prctl(38, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "PR_SET_NO_NEW_PRIVS failed")


def apply_submission():
    """Do not transfer agent-owned executables, dependencies, Git state or links."""
    patch = Path("/tmp/benchmark-submission/submission.patch")
    if not patch.is_file() or patch.is_symlink():
        raise ValueError("missing regular submission patch")
    if patch.stat().st_size > 16 * 1024 * 1024:
        raise ValueError("submission patch exceeds 16 MiB")
    if patch.stat().st_size == 0:
        return
    result = subprocess.run(
        ["/usr/bin/git", "apply", "--numstat", "-z", str(patch)],
        cwd=root, check=True, capture_output=True,
    )
    records = iter(result.stdout.split(b"\0"))
    for record in records:
        if not record:
            continue
        name = record.split(b"\t", 2)[2]
        names = [name] if name else [next(records), next(records)]
        for raw in names:
            path = Path(os.fsdecode(raw))
            if path.is_absolute() or any(p in {"..", ".git", "node_modules"} for p in path.parts):
                raise ValueError("submission attempts to replace verifier infrastructure")
    # Refresh inode/mtime cache entries copied through Docker image layers.
    subprocess.run(["/usr/bin/git", "update-index", "--refresh"], cwd=root, check=True)
    # A fresh Git index enforces normal path/symlink safety during application.
    subprocess.run(["/usr/bin/git", "apply", "--index", str(patch)], cwd=root, check=True)
    changes = subprocess.check_output(["/usr/bin/git", "diff", "--cached", "--raw", "-z"], cwd=root)
    for record in changes.split(b"\0"):
        if record.startswith(b":") and record.split()[1] in {b"120000", b"160000"}:
            raise ValueError("submission introduces a symbolic link or submodule")


try:
    if os.getuid() != 0:
        raise ValueError("the isolated verifier parent must run as root")
    apply_submission()
    expected = Counter(json.loads((tests / "expected-tests.json").read_text()))
    env = dict(PATH="/usr/local/bin:/usr/bin:/bin", HOME="/tmp", LANG="C.UTF-8",
               DSH_REPORT=str(report), DSH_ROOT=str(root), CI="true")
    with (logs / "vitest.log").open("w") as stream:
        result = subprocess.run(
            ["/usr/local/bin/node", str(root / "node_modules/vitest/vitest.mjs"), "run", "--configLoader", "native", "--config", str(tests / "vitest.config.mjs")],
            cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=480,
            preexec_fn=no_new_privileges,
        )
    code = result.returncode
    data = json.loads(report.read_text())
    suites = data["testResults"]
    assertions = [case for suite in suites for case in suite["assertionResults"]]
    actual = Counter(case["fullName"] for case in assertions)
    complete = actual == expected and all(case["status"] == "passed" for case in assertions)
    success = (
        code == 0 and complete and data["success"] is True
        and data["numTotalTests"] == sum(expected.values())
        and data["numPassedTests"] == sum(expected.values())
        and data["numFailedTests"] == 0 and data["numPendingTests"] == 0
        and data.get("numTodoTests", 0) == 0
        and all(suite["status"] == "passed" for suite in suites)
    )
    reward = int(success)
    reason = "all required tests passed" if success else "failed, skipped, or incomplete tests"
except (OSError, ValueError, KeyError, TypeError, IndexError, StopIteration, subprocess.SubprocessError) as error:
    reason = f"incomplete verification: {type(error).__name__}: {error}"
finally:
    (logs / "reward.txt").write_text(f"{reward}\n")
    (logs / "grading-details.json").write_text(json.dumps({"reward": reward, "child_exit_code": code, "reason": reason}, indent=2) + "\n")
    print(json.dumps({"reward": reward, "child_exit_code": code, "reason": reason}))
