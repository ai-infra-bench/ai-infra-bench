import { afterEach, expect, it } from 'vitest'
import { resolveProfiles } from '@deepseek-ai/dsh-llm-pi-ai/src/config.ts'
import { resolveRouteModels } from '@deepseek-ai/dsh-llm-pi-ai/src/catalog.ts'
import { cleanup, endpoint, completion, responseText, harness, profile, turn, migrate } from './support.ts'

afterEach(cleanup)

it('accepts an installed Responses model when its protocol is inherited from the catalog', async () => {
  // The existing catalog supplies the protocol for known models without source.api.
  const profiles = { openai: { models: [{ id: 'gpt-4.1' }], baseURL: 'http://127.0.0.1:1' } }
  const catalog = resolveRouteModels({ provider: 'openai', ...profiles.openai, defaultInput: ['text'], defaultContextWindow: 65536, defaultMaxTokens: 128 })
  expect(catalog.models.map(model => model.api)).toEqual(['openai-responses'])
  expect(() => resolveProfiles(profiles)).not.toThrow()
  expect(() => resolveProfiles({ openai: { ...profiles.openai, responsesReasoningText: true } })).not.toThrow()
})
