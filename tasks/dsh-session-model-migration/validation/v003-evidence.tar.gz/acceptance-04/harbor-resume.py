from pathlib import Path
import subprocess,json,sys,os,time,hashlib,shutil,toml,traceback
root=Path(sys.argv[1]);out=root/'dsh-migration-hardening-20260911/acceptance-04';task=out/'task'
os.environ['PATH']=str(root/'bin')+':'+str(root/'.venv/bin')+':'+os.environ.get('PATH','/usr/bin:/bin')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
state=json.loads((out/'status.json').read_text());assert len(state['docker'])==13,state
assert all(r['exit_code']==0 for r in state['source_checks'])
assert all(r['expected_reward'] is None or r['reward']==r['expected_reward'] for r in state['docker'])
(out/'status-before-cli-repair.json').write_text(json.dumps(state,indent=2)+'\n')
state['launcher_failures']=state.get('harbor',[]);state['harbor']=[];state.pop('error',None);state['status']='harbor'
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for name in ['oracle','early-exit','forged-report']:
  case=out/('harbor-'+name)
  if not case.exists():
   shutil.copytree(task,case)
   if name!='oracle':shutil.copy2(task/'validation'/(name+'.patch'),case/'solution/feature.patch')
   config=toml.loads((case/'task.toml').read_text());config['environment']['docker_image']='ai-infra-bench/dsh-session-model-migration:base-4e84901e6471';config['verifier']['environment']['docker_image']=state['image_id'];(case/'task.toml').write_text(toml.dumps(config))
  cmd=[str(root/'.venv/bin/harbor'),'run','--path',str(case),'--agent','oracle','--env','docker','--jobs-dir',str(out/'jobs'),'--job-name','v003-'+name,'--n-attempts','1','--n-concurrent','1','--max-retries','0','--yes']
  start=time.time()
  with (out/('harbor-'+name+'-cli.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  results=out/'jobs'/('v003-'+name);top=results/'result.json'
  record={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'result':json.loads(top.read_text()) if top.exists() else None,'trials':[json.loads(p.read_text()) for p in results.glob('*/result.json')]}
  state['harbor'].append(record);save()
  rewards=[t.get('verifier_result',{}).get('rewards',{}).get('reward') for t in record['trials']]
  assert r.returncode==0 and rewards==[1.0 if name=='oracle' else 0.0],record
 frozen=json.loads((out/'pre-run-inputs.json').read_text())['files'];assert all(hashlib.sha256((task/k).read_bytes()).hexdigest()==v for k,v in frozen.items())
 (out/'post-run-inputs.json').write_text(json.dumps({'matches_pre_run':True,'at':time.time()}))
 state.update(status='completed',finished_at=time.time());save()
except Exception:
 state.update(status='failed',error=traceback.format_exc(),finished_at=time.time());save();raise
