set -eu
cd /workspace/deepseek-harness
git apply /candidate.patch
node node_modules/vitest/vitest.mjs run packages/api/session-controller/tests/migration-boundaries.spec.ts packages/api/session-controller/tests/model-migration.spec.ts packages/api/session-controller/tests/session-models.host.spec.ts packages/core/agent-loop/tests/request-reconstruction.spec.ts packages/core/agent-loop/tests/loop.spec.ts packages/llm/llm-pi-ai/tests/config.spec.ts
