set -eu
cd /workspace/deepseek-harness
git apply /candidate.patch
node node_modules/typescript/bin/tsc -b packages/api/session-controller/tsconfig.host.json packages/llm/llm-pi-ai/tsconfig.json --pretty false
