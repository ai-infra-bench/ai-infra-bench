from pathlib import Path
import json,hashlib,subprocess,base64
out=Path('/tmp/aib-dsh-session-method-review-20260913');task=Path('/home/tiger/lidailin/ai-infra-bench/tasks/dsh-session-model-migration')
old=json.loads((task/'validation/executable-hashes.json').read_text())
changed=[p for p,h in old.items() if hashlib.sha256((task/p).read_bytes()).hexdigest()!=h]
assert not changed,changed
context={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--short'],text=True),'executable_hashes':old,'previous_snapshot_matches':True,'skill_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('.agents/skills/ai-infra-bench-task-review').rglob('*.md')},'review_source_sha256':hashlib.sha256(Path('/home/tiger/.codex/attachments/1e992c3d-6209-47f9-b031-60afabd4e153/pasted-text.txt').read_bytes()).hexdigest()}
(out/'context.json').write_text(json.dumps(context,indent=2)+'\n')
patch=(task/'solution/feature.patch').read_text();(out/'oracle.patch').write_text(patch)
for a,b in [('llm-pi-ai: chatReasoningText must be boolean','llm-pi-ai: plaintext Chat replay option must be boolean'),('llm-pi-ai: chatReasoningText requires every resolved model to use openai-completions','llm-pi-ai: plaintext Chat replay requires every resolved model to use openai-completions')]:
 assert patch.count(a)==1
 patch=patch.replace(a,b)
(out/'wording.patch').write_text(patch)
probe=(task/'tests/process/run.py').read_text()
a="completion('Invoices inspected.',reasoning='Both values have been verified.' if chat else None)"
assert probe.count(a)==1
probe=probe.replace(a,"completion('',reasoning='Both values have been verified.' if chat else None)")
(out/'probe-run.py').write_text(probe)
(out/'create-caller.mjs').write_bytes((task/'tests/process/create-caller.mjs').read_bytes())
(out/'run-case.py').write_bytes(Path('/tmp/aib-dsh-offline-v005-20260912/run-case.py').read_bytes())
print(json.dumps({'snapshot_files':len(old),'out':str(out)}))
