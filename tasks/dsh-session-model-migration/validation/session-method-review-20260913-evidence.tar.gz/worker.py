from pathlib import Path
import subprocess,json,sys,time,traceback
out=Path(sys.argv[1]); image='sha256:54ea499b323969650ba28c996a91e075289373c4870aa2137230615cd7cf651f'; name='aib-dsh-session-review-oracle'
def status(v): (out/'status.json').write_text(json.dumps(v,indent=2)+'\n')
def call(args,log,timeout=1200):
 with (out/log).open('w') as f:return subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
start=time.time();state={'status':'running','started':start};status(state)
try:
 logs=out/'oracle-formal';logs.mkdir(exist_ok=True)
 cmd=['sudo','-n','docker','run','--name',name,'--network=none','--cpus=4','--memory=8g','-v',str(out/'oracle.patch')+':/tmp/benchmark-submission/submission.patch:ro','-v',str(logs)+':/logs/verifier','-v',str(out)+':/review:ro',image,'bash','/tests/test.sh']
 state['formal_command']=cmd;status(state)
 state['oracle_formal_exit']=call(cmd,'oracle-entrypoint.log');subprocess.run(['sudo','-n','chmod','-R','a+rX',str(logs)],check=True)
 state['oracle_formal']=json.loads((logs/'grading-details.json').read_text());status(state)
 # Restart the stopped candidate container: build/patch are retained, grading reruns
 # would try to apply the patch twice. Use a second launch with a shell wrapper instead.
 # Commit is isolated local Docker cache only; no registry/publishing.
 snapshot='aib-dsh-session-review-oracle:20260913'
 state['snapshot']=subprocess.check_output(['sudo','-n','docker','commit',name,snapshot],text=True).strip()
 probeout=out/'reasoning-only';probeout.mkdir(exist_ok=True)
 cmd=['sudo','-n','docker','run','--rm','--network=none','--cpus=4','--memory=8g','-v',str(out)+':/review:ro','-v',str(probeout)+':/probe-evidence',snapshot,'python3','-I','/review/probe-run.py','--out','/probe-evidence','--cases','chat-provider,chat-model']
 state['probe_command']=cmd;state['probe_exit']=call(cmd,'probe.log',300)
 subprocess.run(['sudo','-n','chmod','-R','a+rX',str(probeout)],check=True)
 state['probe']=json.loads((probeout/'results.json').read_text());status(state)
 state['wording_exit']=call(['python3',str(out/'run-case.py'),str(out),'review-wording',str(out/'wording.patch'),image],'wording.log')
 state['wording']=json.loads((out/'review-wording.json').read_text());state['status']='completed'
except BaseException:
 state['status']='failed';state['error']=traceback.format_exc()
finally:
 state['seconds']=time.time()-start;status(state)
 subprocess.run(['sudo','-n','docker','rm','-f',name],capture_output=True)
