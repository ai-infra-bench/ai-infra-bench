from pathlib import Path
import json,subprocess,sys,tempfile,runpy,copy
review=Path('/review');source=review/'reasoning-only-full-disk-v2/chat-provider/before-restart-migration-chat-provider-raw.zstd'
raw=subprocess.check_output([sys.executable,str(review/'decode-zstd.py'),str(source)])
rows=[json.loads(x) for x in raw.splitlines()];changed=copy.deepcopy(rows)
event=next(x for x in changed if x.get('type')=='assistant/message');old_time=event['time'];event['time']+=1
world=Path(tempfile.mkdtemp());folder=world/'.dsh/sessions/test';folder.mkdir(parents=True);f=folder/'session.jsonl.zstd';f.write_bytes(source.read_bytes());evidence=world/'evidence';evidence.mkdir()
disk=runpy.run_path('/tests/process/run.py')['disk'];before=disk(world,evidence,'before')
# Keep the header and every event, changing only an already-stored event timestamp.
payload=json.dumps(changed[0])+'\n'+ '\n'.join(json.dumps(x) for x in changed[1:])+'\n'
js="import{zstdCompressSync}from'node:zlib';import{readFileSync,writeFileSync}from'node:fs';let s=readFileSync(0,'utf8'),i=s.indexOf('\\n')+1;writeFileSync(process.argv[1],Buffer.concat([zstdCompressSync(s.slice(0,i)),zstdCompressSync(s.slice(i))]));"
subprocess.run(['node','--input-type=module','-e',js,str(f)],input=payload,text=True,check=True)
after=disk(world,evidence,'after')
old_accepts=all(key in after and after[key]['rows'][:len(value['rows'])]==value['rows'] for key,value in before.items())
full_after=[json.loads(x) for x in subprocess.check_output([sys.executable,str(review/'decode-zstd.py'),str(f)]).splitlines()]
assert old_accepts and full_after!=rows
print(json.dumps({'scope':'actual disk() and history-prefix predicate; not a full candidate reward bypass','old_checker_accepts':old_accepts,'full_log_equal':full_after==rows,'old_observed_rows':len(next(iter(before.values()))['rows']),'actual_rows':len(rows),'changed_event_seq':event['seq'],'before_time':old_time,'after_time':event['time'],'hashes_differ':next(iter(before.values()))['sha256']!=next(iter(after.values()))['sha256']},indent=2))
