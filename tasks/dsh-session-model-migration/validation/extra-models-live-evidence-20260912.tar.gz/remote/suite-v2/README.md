# Model migration: actual process and disk acceptance

This supplementary acceptance suite starts the shipped `dsh web` CLI, calls its
HTTP Session Remote, runs the real Bash tool, shuts the host down, and starts a
new host over the same JSONL/Zstandard persistence directory. The restored
session receives no seed, copied events, caller allowance, or destination
selection from the test parent.

It supplements the v0.0.4 verifier's 32 tests. It is **not yet a reward-bearing
verifier**, and does not change the recorded v0.0.4 scores/pass@4. Its parent and
candidate currently run under the same container UID; before promotion to
scoring, isolate the trusted parent, freeze a new verifier image, and rerun
artifact-transfer and completion controls through Harbor.

## Deterministic acceptance

Only model forward computation is substituted. A stateful HTTP/SSE provider
checks each real SDK request before returning the next response; routing,
TokenMeter, Agent loop, Remote validation, persistence, cold restoration and
shell execution are production implementations.

| Case | Observed behavior |
| --- | --- |
| `main` | Read two invoice files through separate Bash calls; checked migration; real host exit/restart; paired history and plaintext thinking reach Responses; another Bash call writes a correct report; destination-native call replay survives. |
| `empty-same` | Caller cap 73; migrate an empty session; restart; checked select the same destination; actual request still uses 73, not default 256. |
| `empty-third` | Same sequence, then a third destination; actual request uses 73, not default 384. |
| `reject` | A destination with insufficient context is refused without generation; after restart the original route can continue using saved tool results. |
| `defaults` | No caller cap; after migration/restart use destination default 256; another migration uses third-model default 384. |

All five also exercise an independent sibling session and compare deployment
settings/catalog and the logical persisted event prefix. Dedicated existing
unit tests retain responsibility for exact rejection-time event immutability,
races, all collision families, disabled behavior and capacity boundaries.

`create-caller.mjs` is an input producer using public `ctx.agents.create` and the
shipped minimal preset. It supplies an explicit caller allowance only in the
first host. The second overlay omits this plugin completely. It does not
implement migration, write a selection record, or reconstruct restored state.
The public Session create Remote does not accept a caller allowance at Base;
this avoids requiring a candidate-specific new creation/selection parameter.

Run inside a disposable built checkout/container:

```bash
python3 /absolute/path/process-e2e/run.py \
  --root /workspace/deepseek-harness \
  --out /tmp/process-acceptance
```

Use a fresh output directory. `--cases baseline` proves ordinary Base
boot/request/persist/restart/resume before testing the new feature. Base assets
were built with `npm run build`. Each complete candidate patch was then applied
and host/client runtime assets rebuilt with the repository's `tsdown` commands.
This is runtime bundling, **not a passing repository typecheck**: the full Oracle
`build:lib` attempt found type errors in its submitted test fixtures, recorded
separately in the run evidence.

The container owns the outer isolation boundary. `DSH_PERMISSION_MODE` is set
to `danger-full-access` because its image lacks a usable nested OS sandbox;
real shell commands still execute in each case's disposable workspace. No
production sandbox implementation is replaced.

## Live acceptance

`live-proxy.py` forwards actual requests and complete SSE responses without
rewriting history or generating scripted output. It keeps API keys on the
credential-owning machine, applies the AIDP `extra.session_id` affinity header,
and captures credential-free wire evidence. One proxy serves one acceptance
attempt; do not mix attempts in its evidence collection. It must be used only
on the private test network and stopped afterwards.

```bash
python3 live-proxy.py --env-file /private/existing.env --key-index 1 \
  --port 20235 --out /tmp/live-proxy-evidence

python3 run-live.py --root /workspace/deepseek-harness \
  --proxy http://PRIVATE_TEST_HOST:20235 \
  --source-api openai-responses --source-model gpt-6-astra \
  --destination-model gpt-5.6-sol --out /tmp/live-acceptance
```

The current credential mapping matches the existing experiment setup:
`GPT56_EXPERIMENT_API_KEYS[1]` for GPT-6 and `[0]` for GPT-5.6. Both request
`high`. The declared 65,536-token context and 16,384 output ceiling are
conservative test configuration, not measurements of the actual model limits.

The first live attempt used the supplied `v2/crawl` Completions endpoint. It
rejected GPT-6 function tools with `reasoning_effort=high` (HTTP 400), so that
cross-protocol live path is not certified. Responses-to-Responses acceptance
is recorded separately. Missing source reasoning is explicitly reported and
must not be called a passing real plaintext-reasoning migration.

Native encrypted reasoning requires stable upstream affinity. The first
Responses attempt lacked that header and failed; it is retained as a failed
attempt. The corrected GPT-6-to-GPT-5.6 attempt passed with fixed per-model affinity
across the host restart. A further reverse attempt did expose source plaintext
reasoning, but the target rejected it. Identical-payload probes confirm both
GPT-6 and GPT-5.6 reject nonempty reasoning.content on these AIDP routes, even
after adding the required summary field. See the review for the exact scope.
No automatic retries or silent rerolls are performed by this suite.

## Evidence and controls

See `../process-e2e-review-20260912.md` and the accompanying compressed evidence.
Each case records parent-observed child PIDs/exits, actual requests, Remote
results, decoded on-disk records, raw Zstandard artifacts and the report file.
Browser login tokens are redacted from host logs; credentials are never copied.

`mutate-control.py` creates two disposable, complete Oracle mutations:

- `volatile-selection`: keep the new route in memory but omit its durable event;
  the test must fail because the first generated request after restart uses A.
- `early-success-exit`: call `process.exit(0)` inside checked migration;
  the parent must fail because the Remote call and required workflow never finish.

A successful child exit or an existing output file alone cannot pass acceptance.
These controls establish ordinary behavioral sensitivity, not adversarial
resistance of this supplementary runner.
