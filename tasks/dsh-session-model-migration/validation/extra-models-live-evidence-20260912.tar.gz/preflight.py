from pathlib import Path
import ast,json,time,urllib.request,urllib.error,urllib.parse,concurrent.futures,hashlib
from dotenv import dotenv_values
OUT=Path('/tmp/aib-extra-models-live-20260912')
keys=ast.literal_eval(dotenv_values('/home/tiger/.env')['GPT56_EXPERIMENT_API_KEYS'])
def probe(model,api,key_index=1):
    function={'name':'read_probe_value','description':'Read the test value.','parameters':{'type':'object','properties':{},'required':[],'additionalProperties':False}}
    body={'model':model,'stream':True}
    if api=='responses':
        body.update(input=[{'role':'user','content':'Call read_probe_value once to obtain the value. Do not guess it.'}],tools=[{'type':'function',**function}],reasoning={'effort':'high','summary':'auto'},max_output_tokens=2048)
    else:
        body.update(messages=[{'role':'user','content':'Call read_probe_value once to obtain the value. Do not guess it.'}],tools=[{'type':'function','function':function}],reasoning_effort='high',max_tokens=2048)
    url='https://aidp.bytedance.net/api/modelhub/online/'+('responses' if api=='responses' else 'v2/crawl')
    req=urllib.request.Request(url+'?ak='+urllib.parse.quote(keys[key_index],safe=''),data=json.dumps(body).encode(),headers={'Content-Type':'application/json','extra':json.dumps({'session_id':'aib-extra-preflight-'+model+'-'+api})})
    start=time.time()
    try:
        with urllib.request.urlopen(req,timeout=150) as r:status=r.status;raw=r.read().decode();kind=r.headers.get('Content-Type')
    except urllib.error.HTTPError as e:status=e.code;raw=e.read().decode();kind=e.headers.get('Content-Type')
    except Exception as e:status=0;raw=type(e).__name__;kind=None
    for key in keys:raw=raw.replace(key,'<redacted>')
    record={'model':model,'api':api,'key_index':key_index,'url':url,'body':body,'status':status,'content_type':kind,'elapsed':time.time()-start,'response':raw}
    (OUT/(model+'-'+api+'-key'+str(key_index)+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2))
    events=[]
    for line in raw.splitlines():
        if line.startswith('data: {'):
            try:events.append(json.loads(line[6:]))
            except ValueError:pass
    result={k:v for k,v in record.items() if k not in ('body','response')}
    result.update(event_types=sorted({e.get('type','chat-chunk') for e in events}),reasoning_text_seen='reasoning_text' in raw or 'reasoning_content' in raw,function_call_seen='function_call' in raw or 'tool_calls' in raw)
    if status!=200:result['error']=raw[:1300]
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(lambda x:probe(*x),[(m,a) for m in ['ali-deepseek-v4-pro','Minimax-M3'] for a in ['responses','chat']]))
    (OUT/'preflight-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
