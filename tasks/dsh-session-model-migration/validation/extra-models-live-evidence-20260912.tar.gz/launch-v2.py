from pathlib import Path
import subprocess,json,base64,hashlib,os,signal
out=Path('/tmp/aib-extra-models-live-20260912');suite=Path('/home/tiger/lidailin/ai-infra-bench/tasks/dsh-session-model-migration/validation/process-e2e')
for name,port in [('deepseek-to-minimax-v2',20245),('minimax-to-deepseek-v2',20247)]:
    log=(out/(name+'-proxy.log')).open('w')
    process=subprocess.Popen(['python',str(suite/'live-proxy.py'),'--env-file','/home/tiger/.env','--key-index','1','--port',str(port),'--out',str(out/(name+'-proxy'))],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (out/(name+'-proxy.pid')).write_text(str(process.pid))
    print(name,process.pid)
for name in ['deepseek-to-minimax','minimax-to-deepseek']:
    os.kill(int((out/(name+'-proxy.pid')).read_text()),signal.SIGTERM)
files={p.name:base64.b64encode(p.read_bytes()).decode() for p in suite.iterdir() if p.is_file()}
(out/'suite-v2-manifest.json').write_text(json.dumps({name:hashlib.sha256(base64.b64decode(data)).hexdigest() for name,data in files.items()},indent=2))
script='''from pathlib import Path
import base64,subprocess,json
out=Path(REMOTE_ROOT)/'dsh-migration-extra-models-20260912';suite=out/'suite-v2';suite.mkdir(parents=True)
for name,data in FILES.items():(suite/name).write_bytes(base64.b64decode(data))
for name,source,destination,port in [('deepseek-to-minimax-v2','ali-deepseek-v4-pro','Minimax-M3',20245),('minimax-to-deepseek-v2','Minimax-M3','ali-deepseek-v4-pro',20247)]:
    cmd=['sudo','-n','docker','run','-d','--name','aib-extra-'+name,'--network=host','--cpus=4','--memory=8g','-v',str(out)+':/evidence','-v',str(suite)+':/suite:ro','aib-dsh-process-oracle:20260912','bash','-lc',f'python3 /suite/run-live.py --source-model {source} --source-api openai-completions --destination-model {destination} --destination-api openai-completions --proxy http://[fdbd:dc03:13:632:9d28:21c:a500:ea]:{port} --out /evidence/{name} > /evidence/{name}.log 2>&1; echo $? > /evidence/{name}.exit']
    r=subprocess.run(cmd,capture_output=True,text=True);print(json.dumps({'name':name,'code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}))
'''.replace('FILES',repr(files))
Path('/tmp/aib-dsh-migration-statement-pilot-20260911/remote-requests/129-extra-models-run-v2.request.py').write_text(script)
