import subprocess,pathlib
r=subprocess.run(['sudo', '-n', 'docker', 'build', '-t', 'ai-infra-bench/dsh-session-model-migration:verifier-v005', '--file', '/home/lidailin.1903/.local/share/ai-infra-bench-runs/cpu-20260909-hnlm9_r_/dsh-offline-v005-20260912/task/tests/Dockerfile', '/home/lidailin.1903/.local/share/ai-infra-bench-runs/cpu-20260909-hnlm9_r_/dsh-offline-v005-20260912/task/tests'])
pathlib.Path('/home/lidailin.1903/.local/share/ai-infra-bench-runs/cpu-20260909-hnlm9_r_/dsh-offline-v005-20260912/build.exit').write_text(str(r.returncode))
