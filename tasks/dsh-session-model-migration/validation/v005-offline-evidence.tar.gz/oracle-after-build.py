from pathlib import Path
import time,subprocess,sys
out=Path(sys.argv[1])
for i in range(600):
 if (out/'cached-build.exit').exists():break
 time.sleep(1)
assert (out/'cached-build.exit').read_text()=='0'
subprocess.run(['/usr/bin/python3',str(out/'run-case.py'),str(out),'oracle',str(out/'task/solution/feature.patch')],check=True)
