from pathlib import Path
import subprocess,sys,json,time,hashlib,os
out=Path(sys.argv[1]);name=sys.argv[2];patch=Path(sys.argv[3]);image=sys.argv[4] if len(sys.argv)>4 else 'ai-infra-bench/dsh-session-model-migration:verifier-v005'
logs=out/'docker-results'/name;logs.mkdir(parents=True,exist_ok=True)
cmd=['sudo','-n','docker','run','--name','aib-dsh-v005-'+name,'--network=none','--cpus=4','--memory=8g','-v',str(patch)+':/tmp/benchmark-submission/submission.patch:ro','-v',str(logs)+':/logs/verifier',image,'bash','/tests/test.sh']
start=time.time()
try:
 with (logs/'entrypoint.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 record={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest()}
 inspect=subprocess.run(['sudo','-n','docker','inspect','aib-dsh-v005-'+name],capture_output=True,text=True)
 if inspect.returncode==0:
  i=json.loads(inspect.stdout)[0];record.update(network_mode=i['HostConfig']['NetworkMode'],image_id=i['Image'])
 subprocess.run(['sudo','-n','chmod','-R','a+rX',str(logs)],check=True)
 for file,key in [('grading-details.json','grading'),('process/results.json','process')]:
  p=logs/file
  if p.exists():record[key]=json.loads(p.read_text())
 if (logs/'results.json').exists():
  j=json.loads((logs/'results.json').read_text());record['unit']={k:j[k] for k in ['numTotalTests','numPassedTests','numFailedTests']};record['failed_tests']=[a['fullName'] for s in j['testResults'] for a in s['assertionResults'] if a['status']!='passed']
 (out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
finally:
 subprocess.run(['sudo','-n','docker','rm','-f','aib-dsh-v005-'+name],capture_output=True)
