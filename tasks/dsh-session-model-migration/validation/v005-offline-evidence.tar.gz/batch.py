from pathlib import Path
import subprocess,json,sys,concurrent.futures,time,traceback,os
out=Path(sys.argv[1]);task=out/'task';image=json.loads((out/'oracle.json').read_text())['image_id']
assert json.loads((out/'oracle.json').read_text())['grading']['reward']==1
cases=[{'name':'base','patch':str(out/'base.patch'),'expected_reward':0},{'name':'oracle-repeat','patch':str(task/'solution/feature.patch'),'expected_reward':1}]
for c in json.loads((task/'validation/ci-cases.json').read_text())['cases']:cases.append({**c,'patch':str(task/'validation'/c['patch'])})
cases.append({'name':'alternative-repeat','patch':str(task/'validation/alternative-payload-projection.patch'),'expected_reward':1})
state={'status':'running','image_id':image,'started_at':time.time(),'cases':[]};(out/'batch.json').write_text(json.dumps(state,indent=2))
def run(c):
 with (out/(c['name']+'-worker.log')).open('w') as f:r=subprocess.run(['/usr/bin/python3',str(out/'run-case.py'),str(out),c['name'],c['patch'],image],stdout=f,stderr=subprocess.STDOUT)
 d=json.loads((out/(c['name']+'.json')).read_text());d['expected_reward']=c['expected_reward'];assert r.returncode==0 and d['grading']['reward']==c['expected_reward'],d
 return d
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for future in concurrent.futures.as_completed([pool.submit(run,c) for c in cases]):
   state['cases'].append(future.result());(out/'batch.json').write_text(json.dumps(state,indent=2))
 state.update(status='completed',finished_at=time.time())
except Exception:state.update(status='failed',error=traceback.format_exc(),finished_at=time.time())
(out/'batch.json').write_text(json.dumps(state,indent=2))
