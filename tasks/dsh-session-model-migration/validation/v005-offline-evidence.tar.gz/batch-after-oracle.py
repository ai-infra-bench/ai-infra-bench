from pathlib import Path
import subprocess,sys,time
out=Path(sys.argv[1])
for i in range(600):
 if (out/'oracle.json').exists():break
 time.sleep(1)
subprocess.run(['/usr/bin/python3',str(out/'batch.py'),str(out)],check=True)
