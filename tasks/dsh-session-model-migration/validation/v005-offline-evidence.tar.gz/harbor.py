from pathlib import Path
import subprocess,json,sys,os,time,hashlib,shutil,toml,traceback
root=Path(sys.argv[1]);out=root/'dsh-offline-v005-20260912';task=out/'task'
os.environ['PATH']=str(root/'bin')+':'+str(root/'.venv/bin')+':'+os.environ.get('PATH','/usr/bin:/bin')
os.environ['LITELLM_LOCAL_MODEL_COST_MAP']='True'
assert json.loads((out/'oracle.json').read_text())['grading']['reward']==1
image=json.loads((out/'oracle.json').read_text())['image_id']
state={'status':'running','started_at':time.time(),'image_id':image,'cases':[]}
def save():(out/'harbor.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for name in ['oracle','early-exit','forged-report']:
  case=out/('harbor-'+name);shutil.copytree(task,case)
  if name!='oracle':shutil.copy2(task/'validation'/(name+'.patch'),case/'solution/feature.patch')
  config=toml.loads((case/'task.toml').read_text());config['environment']['docker_image']='sha256:e87af67674c9b180ee88328bffd4b4279c1324c0567ac86be943f951287a2b0a';config['verifier']['environment']['docker_image']=image;(case/'task.toml').write_text(toml.dumps(config))
  cmd=[str(root/'.venv/bin/harbor'),'run','--path',str(case),'--agent','oracle','--env','docker','--jobs-dir',str(out/'jobs'),'--job-name','v005-'+name,'--n-attempts','1','--n-concurrent','1','--max-retries','0','--yes']
  start=time.time()
  with (out/('harbor-'+name+'-cli.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
  results=out/'jobs'/('v005-'+name);top=results/'result.json'
  record={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'result':json.loads(top.read_text()) if top.exists() else None,'trials':[json.loads(p.read_text()) for p in results.glob('*/result.json')]}
  state['cases'].append(record);save()
  rewards=[(t.get('verifier_result') or {}).get('rewards',{}).get('reward') for t in record['trials']]
  assert r.returncode==0 and rewards==[1.0 if name=='oracle' else 0.0],record
 state.update(status='completed',finished_at=time.time());save()
except Exception:
 state.update(status='failed',error=traceback.format_exc(),finished_at=time.time());save();raise
