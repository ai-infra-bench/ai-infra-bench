from pathlib import Path
import json,subprocess,tarfile,hashlib,time,sys
out=Path(sys.argv[1])
for _ in range(600):
 states=[json.loads((out/(n+'.json')).read_text()).get('status') for n in ['batch','harbor']]
 if all(s!='running' for s in states):break
 time.sleep(1)
assert states==['completed','completed'],states
assert json.loads((out/'base-smoke.json').read_text())['exit_code']==0
subprocess.run(['sudo','-n','chmod','-R','a+rX',str(out)],check=True)
frozen=json.loads((out/'runtime-input-hashes.json').read_text())['files']
assert all(hashlib.sha256((out/'task'/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
(out/'post-run-inputs.json').write_text(json.dumps({'matches_frozen_runtime_inputs':True,'files':frozen},indent=2))
manifest={}
paths=[]
for path in sorted(out.rglob('*')):
 if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:continue
 rel=str(path.relative_to(out))
 if path.name in ['evidence.tar.gz','collection-manifest.json','collection.json','collector.log']:continue
 paths.append((path,rel));manifest[rel]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/'collection-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');paths.append((out/'collection-manifest.json','collection-manifest.json'))
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for path,rel in paths:tar.add(path,arcname=rel,recursive=False)
p=out/'evidence.tar.gz';(out/'collection.json').write_text(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'files':len(paths)}))
print((out/'collection.json').read_text(),flush=True)
