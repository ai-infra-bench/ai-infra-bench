# PR #60：真实 GPU backend 校准（v1.6.0）

本轮由用户授权：在相对空闲卡完成真实GPU校准，再冻结两题，各并行运行三次新的DeepSeek，随后审核轨迹、最终代码及评分。采用Oracle-based模式，使用 `ai-infra-bench-rollout-review`（本地冻结修订b40002e）区分合同、候选缺陷、夹具错误与评分观察。没有为了调整通过率添加隐含要求。

## 合同与新增行为检查

题面未改：V2继续支持DCP的正常批量生成、eager/graph、batch和block变化；非DCP部署保持原行为。本轮新增的四个检查组依赖这些既有用户可见要求，不要求候选实现特定helper或buffer。

- `real-backend-eager`：真实GPUModelRunner、FlashAttention层/metadata builder/KV缓存初始化、采样；DCP=2的两个rank，block16/32；跨prefill、重排decode、跨块、新请求、完成和容量复用。
- `real-backend-decode-graph`：同一生命周期，使用正常FULL_DECODE_ONLY模式；确认graph replay消费新context和block数据，不以是否存在某个持久buffer评分。
- `real-backend-non-dcp`：DCP=1，同样的真实backend和CUDA数值检查，eager及graph，block16/32。
- `eagle-non-dcp-compatibility`：正常两步Eagle propose，真实Triton准备、FlashInfer CPU planning及CUDA decode；短序列和跨block长度，比较实际draft token和独立uniform-attention期望。

FlashAttention场景使用零Q/K、按物理slot确定的V，均值可以不依赖Oracle独立计算。真实metadata喂给实际paged-attention CUDA kernel，输出再经runner/sampler观察。替代的是模型权重和多rank通信，不是backend metadata builder。不能据此宣称HTTP/NCCL或完整模型精度通过。

更精确地说，FA消费者直接使用Base已有的metadata字段调用局部paged-attention kernel，并未执行完整FlashAttentionImpl.forward中的Q all-gather、当前token KV写入、context/query合并及跨rank LSE归并。它能证实当前backend builder到CUDA消费者的数据有效性，但不能认证把这些既有内部边界整体重构的所有可能实现。graph配置经正常runner capture/replay；未另外加入“禁用graph、退回eager”的负控制，因此不能仅凭数值正确断言所有graph性能退化都会被拒绝。Eagle检查则调用真实FlashInfer AttentionImpl.forward。以上是覆盖限制，不是当前已确认的候选误判。

## 校准中发现并处理的问题

1. 首版真实层夹具沿用了合成消费者的 `layer0` 名称，真实KV绑定要求可解析层索引；Base、Oracle均在初始化失败。已改为正常模型层路径；这一失败归属fixture，不计候选错误。原日志保留在 `fa-v1/`。
2. 修正夹具后，旧Oracle在eager通过，但DCP graph第二个step继续消费旧context，错误输出。两份过去标记正确的替代也复现同一问题。现Oracle刷新稳定的backend context存储；测试不检查这个具体修复方式。旧Oracle完整保留为 `historical-oracle-stale-backend.patch` 负控制，旧成绩不删除。
3. 旧r02在nonDCP的两步Eagle解码输出0，Base/Oracle在相同输入下正常，是非DCP保持性回归。三步Eagle在Base也有旧plan复用问题，因此不将三步加入此次评分，不把已有基线缺陷要求候选额外修掉。
4. FlashInfer DCP graph初始化诊断中，Base/Oracle可构造，旧r02主动拒绝；该初始化差异没有单独晋升为完整DCP FlashInfer生成评分，避免把仅构造成功误当作完整支持证明。记录为后续审查背景。

## 证据边界与版本

- Base仍为 `be3af2d29e2507f32b2190fe015cd6609b348caa`，镜像仍为 `sha256:dee094a5fca85bb9d08b507d3d23b12b51d89c31b268bc9431800efed3c961d3`。
- task版本1.5.0→1.6.0；检查点11→15，含最终complete，不是15个单独输入。
- 使用私人Docker/no-network；主GPU诊断及Harbor在物理H20卡4，独立Eagle诊断在卡5。共享卡仍有其他负载，用户明确允许相对空闲卡测试；未停止他人任务，不宣称独占或A100验证。
- 原始实验及模型成绩不变；诊断根目录 `runs/pr60-gpu-calibration-20260917/`，每轮单独冻结测试与对照，保存前后hash；已知有缺陷的初版夹具不覆盖。
- 完整Harbor控制在最终冻结版本上执行，结果执行后回填。新DeepSeek结果将另存 `runs/deepseek-pr60-pr61-r3-20260917/`，不得以旧答案重放冒充新运行。
- 本轮不执行此前暂停的评分安全探针；评分可信度验收、多卡真实collective及A100仍是明确限制，不随普通功能测试通过自动关闭。

## 最终冻结版本的完整 Harbor 校准

2026-09-17，Harbor 0.22.0、同一最终v1.6.0快照、共享H20 GPU4，10项普通功能对照全部完成，实际reward均符合预期，Harbor errors全部为0。`final-v160/frozen-inputs.json`记录执行前身份，`task-after.json`逐项一致；模型API未参与这些控制。正例全部15/15，负例只声称执行到实际首个失败点，不把未运行的后续组计为已检查。

| 对照 | Reward | 检查点 | 实际评分原因 |
|---|---:|---:|---|
| Oracle（本版修正） | 1 | 15/15 | 全部完成 |
| Base | 0 | 2/15 | 原DCP slot mapping错误 |
| deepseek-input-buffers | 1 | 15/15 | 替代实现完整通过 |
| persistent-backend-buffer-r01 | 1 | 15/15 | 历史r01完整tracked解通过 |
| backend-context-buffer-r03 | 1 | 15/15 | 历史r03完整tracked解通过 |
| alternative-agent | 0 | 11/15 | real attention graph step1输出0，期望0.61328125 |
| deepseek-explicit-capture | 0 | 11/15 | 同类过期context导致错误attention |
| incomplete-agent | 0 | 2/15 | DCP slot mapping未实现完整 |
| historical-oracle-stale-backend | 0 | 11/15 | 旧Oracle也存在同类真实graph错误 |
| non-dcp-eagle-regression | 0 | 13/15 | 第二draft token为0，应为6/9 |

所有负例都核对到实际行为断言，不是导入、临时模型目录metadata warning或环境故障。结果和精简原始评分日志导出到 `real-backend-v160-results.json` / `real-backend-v160-logs/`。旧版本的成功记录仍保留在原证据文件中；新结果不能追溯改写旧成绩。这些是校准/开发控制，不是六次新DeepSeek结果，也不是held-out模型能力估计。
