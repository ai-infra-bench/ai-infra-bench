"""Compact read-only progress and causal-error inspection; never alters rewards."""
import json
from pathlib import Path

root=Path(__file__).parent/'controls'
for result in sorted(root.glob('*-result.json')):
    row=json.loads(result.read_text())
    log=(Path(row['trial'])/'verifier/verifier.log').read_text()
    print(json.dumps({k:row[k] for k in ('case','observed_rewards','verdict','harness_errors','valid')},ensure_ascii=False))
    lines=log.splitlines()
    checks=[json.loads(line.split('=',1)[1]) for line in lines if line.startswith('DISTRIBUTED_CHECK=')]
    print('engine combinations:',len(checks),'max logprob error:',max((x['max_logprob_error'] for x in checks),default=None))
    if row['expected_reward']==0:
        starts=[i for i,line in enumerate(lines) if line.startswith('Traceback')]
        if starts:
            print('\n'.join(line[:700] for line in lines[starts[-1]:starts[-1]+45]))
        else:
            print('No traceback; inspect full log:',row['trial'])
active=[p.parent.parent.name for p in (root/'harbor').glob('*/*/verifier') if not (p.parent/'result.json').exists()]
print('active:',active)
