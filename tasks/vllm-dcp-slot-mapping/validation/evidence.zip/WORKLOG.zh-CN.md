# PR60 HND 修订与校准

用户授权：补 HND 真实端到端测试、修 Oracle、重跑相关正反例与完整 Harbor 校准。没有授权本轮新增模型运行或发布。

采用 ai-infra-bench-rollout-review：保持原始模型产物与评分不变，新诊断和新版本校准分开记录。依据上一轮 rollout-review/REPORT.zh-CN.md：公开要求支持后端布局；旧 Oracle 在 HND 下生成错误，当前 GPT 答案通过独立检查。

## v1.8.2 改动

- 完整模型生成明确指定 NHD/HND，均在新进程启动前设置；两个后端、两个模式、两个布局共8个完整引擎组合。仍用真实 TP2/DCP2、KV写入/通信、三请求错峰完成与新接入，独立CPU全词表参考，误差阈值不变。
- 新增两个HND完成检查点，必需检查点从19变21。
- Oracle 区分 paged-cache 布局和 token-major 新K/V输入布局，仅修复已确认的HND缺陷。
- 新 GPT 完整 tracked diff 加两个 untracked 测试作为正控制；原 Oracle 原样保留为 HND 负控制。
- 原有三个旧正控制移入 validation/history/v181-positive-controls，保留旧分数/补丁/哈希，不冒充新布局矩阵的正确实现。其他历史负控制保持待复验，不重试此前受限安全探针。
- instruction、镜像、资源和公开开发材料不变；不提供公开复测脚本，不添加内部修复提示。

## 校准方案

7项完整Harbor：修订Oracle、新GPT、Base、旧HND Oracle、旧FA graph缺陷、缺FI修复、非DCP Eagle回归。前两项应21/21得1，其余应因实际行为错误得0。两条独立双H20 GPU lane并行，无模型调用。冻结task和prepared输入运行前后校验哈希。

执行结果以 controls/results.json 和对应原始verifier记录为准；未完成时不宣称通过。H20不是A100认证；此前cutoff及完整评分信任边界限制保留。

## 已完成校准：2026-09-18 01:37 北京时间

七项完整 Harbor 已结束，全部符合预期，零 harness error，运行前后 prepared 输入哈希不变：

| 控制 | reward | 检查点 | 原因 |
|---|---|---|---|
| 修订 Oracle | 1 | 21/21 | 两后端、两布局、两模式均通过 |
| 保存 GPT 完整答案 | 1 | 21/21 | 同上，不改原始答案 |
| Base | 0 | 2/21 | DCP slot地址错误 |
| 旧 HND Oracle | 0 | 19/21 | FI HND eager 全词表247/256维错误，max1.62355184555>0.02 |
| 旧 FA graph 缺陷 | 0 | 11/21 | 真实attention输出0 != 0.61328125 |
| 无 FI 修复 | 0 | 14/21 | 本地CUDA输出max0.029296875>0.001 |
| 非 DCP Eagle 回归 | 0 | 13/21 | 两步草稿输出错误 |

两个正控制各八组生成检查全覆盖，max error0.0024595260620117188。旧Oracle先通过全部NHD和FA HND再被FI HND拒绝，排除环境启动故障作为本次0分原因。负控制fail-fast后未执行的后续检查不计通过；旧HND graph失败的独立诊断另存历史证据。

`export.py` 必须核对保护文件与预运行冻结哈希、原题面/环境不变、GPT四个tracked生产文件和两个untracked测试原样重放，随后导出evidence.zip及最终索引。`inspect_results.py` 只读查看每项完整结果和因果traceback。最终静态审核日志另存在本目录，不能把静态审核当成GPU或评分信任证明。

旧版材料保存在 previous-task-v181 和新版 evidence.zip 的 historical-v181；旧三个正控制是归档而非删除。没有新付费模型轮次，没有修改PR61，没有commit/push。本次使用 rollout-review skill 的行为独立性、历史分数保留、完整答案重放和最终快照校准要求。
