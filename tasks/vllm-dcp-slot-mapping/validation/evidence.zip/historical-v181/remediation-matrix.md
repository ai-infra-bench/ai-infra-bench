# Current remediation matrix — v1.8.1

| Concern | Current evidence / remediation | Status |
|---|---|---|
| Two-GPU instruction but one-GPU environment | Two GPUs reserved in Agent and verifier, shm2GiB, ordinary offline Qwen3 model/tokenizer | Correct final image recorded; no public reproducer |
| Real full-engine behavior missing | New TP2/DCP2 engine, real model/KV writes/FA/FI/collectives, eager+graph, independent CPU all-vocabulary reference | Nineteen checkpoints; current six-control results in evidence index |
| FA3 graph fixture startup incompatibility | Reproduced on original runner and unmodified Base; single-split supported configuration is publicly disclosed | Actual graph remains enabled; no unrelated kernel repair demanded |
| Oracle missing FlashInfer DCP behavior | Prior repair retained unchanged: local page planning, current interleave and shared-input preservation | Revalidated as part of current full Oracle run |
| Hidden contract and implementation dependence | Removed synthetic consumer's dependence on optional runner-populated local lengths; real backend and full-engine numerical checks unchanged | Original GPT backend-local implementation replays from old0/7of19 to new1/19of19 without source changes |
| Fairness fix must retain defect detection | Actual Harbor Base, stale-FA-graph, missing-FI and non-DCP Eagle controls | All four reject real slot, attention or draft-output defects; Oracle and original GPT pass19/19 |
| Publication clutter | One review/index, current evidence ZIP, historical ZIP and immutable old Opus archive link | Old records retained with their original version identity |
| Hardware / E2E scope | Shared H20 x2; full engine generation, not HTTP or production model quality | A100 validation remains open |
| Grading integrity | Five security controls retained but not newly executed or certified | Separate trust review remains open |
| Fresh model evidence | Original GPT result retained separately from corrected replay; user authorized one fresh GPT-5.6 Sol high per PR60/61 after calibration | Two new attempts, no automatic retries; native trajectory/source/scoring and usage retained |

See [review-report.md](review-report.md) for the qualified scorecard and [e2e-evidence.json](e2e-evidence.json) for run identities and hashes. Publication checks do not constitute a new behavioral calibration or final merge approval.
