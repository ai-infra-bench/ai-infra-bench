"""Preserve obsolete positive controls; index the v1.8.2 calibration."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).parent
W = ROOT.parents[1]
TASK = W/'worktrees/pr-60/tasks/vllm-dcp-slot-mapping'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, data): p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

old = json.loads((ROOT/'previous-task-v181/validation/ci-cases.json').read_text())
assert (TASK/'validation/historical-oracle-hnd-prefill.patch').read_bytes() == (ROOT/'previous-task-v181/solution/oracle.patch').read_bytes()
history = TASK/'validation/history/v181-positive-controls'
history.mkdir()
remaining, archived = [], []
for case in old['cases']:
    if case['expected_reward'] == 1:
        # Old scores remain historical evidence, not current-layout acceptance.
        source = TASK/'validation'/case['patch']
        assert sha(source) == case['patch_sha256']
        shutil.move(str(source),str(history/source.name))
        archived.append(case)
    else:
        case = dict(case,task_version='1.8.2',execution_status='pending-v182; historical-scores-not-current-validation')
        for key in ('observed_reward','evidence','evidence_note','results_file'):
            case.pop(key,None)
        remaining.append(case)
save(history/'historical-cases.json',{'task_version':'1.8.1','cases':archived,
    'note':'Historical classifications only. Not validated against the v1.8.2 explicit-layout matrix.'})
for name, expected, reason in (
    ('historical-oracle-hnd-prefill',0,'Unchanged v1.8.1 Oracle: real FlashInfer HND prefill produces wrong logprobs.'),
    ('gpt-hnd-complete-alternative',1,'Unmodified saved GPT-5.6 Sol high answer, including both untracked tests; backend-local length derivation and HND support.')):
    patch = TASK/'validation'/f'{name}.patch'
    remaining.append({'name':name,'patch':patch.name,'patch_sha256':sha(patch),
        'expected_reward':expected,'task_version':'1.8.2','execution_status':'pending-v182',
        'reason':reason})
save(TASK/'validation/ci-cases.json',{'schema_version':old['schema_version'],
    'status':'v182-explicit-layout-calibration-pending','cases':remaining,
    'historical_positive_controls':'history/v181-positive-controls/historical-cases.json'})
evidence = json.loads((ROOT/'previous-task-v181/validation/e2e-evidence.json').read_text())
evidence.update(task_version='1.8.2',status='v182-explicit-layout-calibration-pending',
    final_acceptance=False,current_controls=[],artifacts={'files':{}})
save(TASK/'validation/e2e-evidence.json',evidence)
print(json.dumps({'active_cases':len(remaining),'archived_previous_positives':[x['name'] for x in archived]}))
