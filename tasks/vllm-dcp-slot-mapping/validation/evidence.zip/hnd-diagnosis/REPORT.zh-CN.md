# PR60 / PR61：GPT-5.6 Sol high 运行后审查

审查日期：2026-09-18（北京时间）。范围：本轮每题一次 GPT-5.6 Sol high 的保存产物、题面、verifier、先前校准记录，以及独立本地诊断。**没有新增模型调用，没有更改 task、候选答案或原始分数，没有 commit / push。**

## 结论先行

**不能把“两题 reward=1”直接表述为“两题 task 已完成最终验收”。**

- **PR60：本轮 GPT 答案没有发现新的已确认功能缺陷，但 task 仍有一个已复现的 P1 覆盖问题。** 题面明确要求支持后端支持的 paged-KV layouts；现有完整生成测试未显式遍历 HND。Oracle 在默认路径得到 19/19，却在真实双 GPU 的 FlashInfer + HND 下生成错误，eager 和 graph 都失败。GPT 自己发现并修复了这个问题，保存的最终答案通过同一补充检查。因此不能将此发现归因为本轮 GPT 的假阳性；它证明了当前测试可以放过合同不完整的 Oracle。
- **PR61：本轮审查未发现新的已确认功能阻塞或错误评分。** 原始 18/18 通过；补充的 6 组事件交错检查也通过。可以保留当前功能实现和评分结果，但不宣称证明所有输入或完整评分信任边界。
- 两份轨迹都确实运行了测试、看到反馈并迭代，不是“没有测试就偶然拿到 1 分”。在已审阅的工具操作和最终差异中没有观察到评分文件篡改或测试输入特判。

## 1. 方法、身份和证据边界

使用本地官方仓库的 `ai-infra-bench-rollout-review` skill 及其 `differential-cases.md`、`reporting.md`，按“先还原合同，再分别判断答案与评分”执行。skill 所在仓库 HEAD 为 `3a83c84128cae23be8ab56ebb4aa3094226f4c7f`，SKILL.md 的实际 SHA256 为 `767fe719670c4a10753d7643cddbbab9c73f111c025f2d09fe03a6cf72a22f1f`；引用文件哈希见 `inventory-before.json`。

两题都是 **Oracle-based**，不是 verifier-only。本次沿用匹配快照的 Base/Oracle 校准，不重复重建镜像。PR60 之前的 6 项 Harbor 校准与 PR61 Base/Oracle 的分数见上级 `RESULTS.zh-CN.md`、`controls-pr60/results.json`、`controls-pr61/results.json`。

完整最终仓库（含 `.git`、已跟踪与未跟踪文件）、ATIF、原生 sessions、评分日志、manifest 均存在。PR60 manifest 中 `/logs/artifacts` 是空目录，但 `/workspace/repo` 的完整导出状态为 `ok`；不能将前者误当成没有最终代码。

本次逐条核对 Agent 步骤的工具调用输入、关键结果与最终答复，并审阅完整最终 diff 和新增测试。长篇重复源码打印、初始化日志通过裁剪索引定位；涉及失败、外部访问、测试命令和 HND 差异的原始结果另行核对。**不声称逐字读完所有重复输出**，原轨迹自身已有部分工具输出截断，未观察到的内容不作为证据。PR60 临时端到端脚本被 Agent 在结束前删除，其代码和运行记录仍在轨迹中；本次补充重放使用独立 verifier 的引擎输入，不把重建的临时脚本当成最终交付。

### 本轮两个模型样本

| 项目 | PR60 | PR61 |
|---|---|---|
| task | vllm-dcp-slot-mapping v1.8.1 | vllm-remote-kv-idle-overhead v1.5.0 |
| trial | task__GETsdtK | task__cQJEQc4 |
| model / effort | GPT-5.6 Sol / high | GPT-5.6 Sol / high |
| Base | be3af2d29e2507f32b2190fe015cd6609b348caa | d88f28da05b12bc7d63ebe3dcedf445ecb274343 |
| 原始 Harbor reward | 1，19/19，无失败 | 1，18/18，无失败 |
| 总耗时 | 28分19秒 | 13分58秒 |
| Agent execution | 22分00秒 | 12分12秒 |
| verifier execution | 5分52秒 | 1分17秒 |
| ATIF Agent steps | 84 | 60 |
| ATIF 顶层工具调用 | 83 | 59 |
| 最终变更 | 4 个生产文件 + 2 个新增测试文件 | 1 个生产文件 + 6 个已有测试/辅助文件 |
| 已跟踪 diff | +103 / -15；另有两个新增测试 | +220 / -56 |
| 采集/Harbor异常 | 无，必需产物完整 | 无，必需产物完整 |

Agent steps 指 `source=agent` 的 ATIF 条目，不是完整 task 次数；顶层工具调用包含 `exec` 编排和轮询，不等于 Bash 命令数或模型轮数。PR61 的一个 `exec` 可能包含多个并行命令。本轮每题只有一次模型尝试。模型未记录可验证的不可变服务端版本，不推测其具体内部快照。

Codex CLI 为 0.153.4，Harbor 0.22.0；调用和硬件配置以每题 `launch.json` 为准。PR60 实际使用共享 H20 两张卡，不是 A100 实测认证；PR61 为 CPU。镜像分别是：

- PR60：`sha256:462fc769cac14468d0c1a7128eb17116c728e12e31efaee14b9ea7fd6c3e9868`
- PR61：`sha256:fd59b9b0cbbc1c4d5400d97e1eaeb1cdd4640f71983c9a5581b84449743ac88c`

task 声明 no-network，模型请求通过此前已配置的受限模型代理；审查诊断容器使用 `--network none`。具体 task 配置、来源文件逐文件哈希、镜像、资源和启动命令保存在原始 `launch.json` 及本目录 inventory 中。没有重复保存凭据。

## 2. 题面与行为覆盖

| 题面要求 | 真实行为边界 | 当前证据 / 缺口 |
|---|---|---|
| PR60 DCP 生成、跨块、动态 batch | 请求进入真实 V2 runner，执行 KV 写入和跨卡 attention，观察逐请求 token/logprob | 真实 TP2/DCP2、三请求错峰完成和新接入；独立 CPU Transformers 全词表比较 |
| PR60 eager 和 CUDA graph | 捕获/重放真实后端与通信 | FA、FI 两后端两模式；此前局部 graph 生命周期也通过 |
| PR60 supported paged-KV layouts | 相同模型输入、改变普通布局配置，比较最终输出 | **缺少显式 NHD/HND 矩阵；本次 HND 发现 Oracle 漏修** |
| PR60 非 DCP 保持 | 普通 slot、真实后端、Eagle 草稿路径 | 当前 verifier 有回归组；本轮通过 |
| PR61 idle 开销不随等待人群线性增长 | 真正 schedule() 空闲循环 | 24 vs 384 waiters，纯远程与混合等待；Base 失败来自目标性能缺陷 |
| PR61 FCFS、可运行请求前进 | 到达/完成事件 → 真实 scheduler → 调度输出 | 混合 FSM/streaming、乱序完成、backpressure；本次新增 6 组事件诊断 |
| PR61 取消、生成完成、后续接入 | connector 回调 → schedule/update_from_output → 客户端 token/终止 | 当前 lifecycle/取消竞争/churn 检查通过；不是仅检查队列字段 |
| PR61 长运行内存 | 一个长寿命 scheduler 顺序完成短请求，测 retained Python heap | 16384 请求：本地增长495,968B，remote增长470,176B，低于公开32MiB预算 |

PR61 是 scheduler 子系统的端到端生命周期验证：connector 用可控完成事件、模型输出用确定性 token 替代，真实 scheduler、KV 分配、请求状态和客户端输出处理参与。它**不是**真实远程网络传输或完整大模型服务器认证。PR60 完整生成则确实运行两卡模型与 collectives；不能混淆两者层级。

## 3. PR60 的真实轨迹与最终代码

### 过程与测试反馈

1. Step 6–20：读取 V2/旧 runner、block table、FA/FI 和配置源码。Step 15 尝试访问 GitHub commits API，返回 `Tunnel connection failed: 403 Forbidden`；未看到成功取得远端答案。读取本地历史不等于得到目标修复。
2. Step 21–28：加入 DCP 虚拟 block/owner/local-offset 计算与 runner 配置接入；在 FA 使用 graph-stable 本地长度缓冲，在 FI 调整本地 page 计算和 interleave 配置；自建三项 slot 回归通过。发现初始化顺序问题后立即更正。
3. Step 30–34：最初用 stdin 启动多进程引擎，发生 `<stdin>` spawn 文件不存在；改为真实脚本及 main guard 后继续。这是自建测试启动方式的问题，不是隐藏评分失败。
4. Step 35–58：运行非 DCP 参考、DCP FA/FI eager/graph 与 batch 替换。记录中有实际双卡 worker 初始化和 token 序列，不仅是命令文本。
5. Step 59–69：FlashInfer HND 的输出与先前结果不同。Agent 检查缓存与未缓存 K/V 的布局，修正 ragged-prefill wrapper 的布局使用，重跑 HND graph 后输出恢复一致。这是明确的“运行 → 发现结果错误 → 修改 → 重跑”链路。
6. 最后清理临时脚本，保留 2 个测试文件，4 项自建回归通过。更广泛 attention 测试遇到离线外部模型不可用；ruff 本地缺失且 uvx 下载失败，不当成功测试计数。

### 代码判断

四个生产文件的修改分别承担 slot 地址/容量、runner 配置接入、FA graph 数据更新、FI 本地分页和 HND ragged prefill。没有发现硬编码目标请求 ID、目标 token 或评分输出；未修改 hidden tests。非 DCP 保留原内核分支。新增两个测试文件完整审阅，不存在额外生产补丁藏在未跟踪文件里的情况。

本轮原始 verifier 的四个完整模型组，最大 logprob 误差 FA 为 0.002459526，FI 为 0.002131462，均小于 0.02。再加本次 HND eager/graph 两组通过，支持该候选的本地功能正确性；不外推为所有模型、硬件和拓扑的证明。

## 4. P1：PR60 HND 漏测与 Oracle 不完整（已确认）

### 合同依据与机制

题面明确写出 `their supported paged-KV-cache layouts`。HND 是该固定 Base 中普通可配置布局，Agent 可从源码发现，也实际用该配置复现问题；这不是审查者后来添加的新需求。

`tests/verify_distributed_generation.py` 的 worker 配置运行两后端两模式，但不显式设置或遍历 `VLLM_KV_CACHE_LAYOUT`。`verify_flashinfer_dcp.py` 的局部检查会顺应当前布局，却没有独立布局循环，而且主要测试 decode，不会覆盖真实 DCP ragged-prefill 的此问题。

保存的 Oracle 在 `BatchDCPPrefillWrapper` 中给 paged-cache wrapper 和 ragged-new-tokens wrapper 都传入 `get_kv_cache_layout()`。HND 适用于 paged cache，却不等于未缓存的新 K/V 输入布局；后者是 token-major。于是模型能启动并生成 token，但数值错误。本轮 GPT 将两者区分，Oracle 尚未包含此修复。

### 实际执行，不是静态猜测

用**原完整保存仓库只读挂载**到相同最终镜像，保留全部 tracked/untracked 文件。只通过公开环境参数选择 `VLLM_KV_CACHE_LAYOUT=HND`，运行冻结的 `verify_distributed_generation.py --backend FLASHINFER`，分别不加/加 `--graph`。没有替换候选函数，没有修改数学参考或放宽阈值。

| 完整保存实现 | 当前原始 Harbor | HND eager 补充诊断 | HND graph 补充诊断 |
|---|---|---|---|
| 新 GPT 答案 | 1，19/19 | 通过，max error=0.002131462 | 通过，max error=0.002131462 |
| 已校准 Oracle | 1，19/19 | **失败**，max absolute difference=1.623551846 | **失败**，同样1.623551846 |

Oracle 第一处比较即有 247/256 维超过0.02阈值。短请求得到 `[111, 213, 204]`；同输入本轮候选得到 `[116, 140, 69]`，且通过独立 CPU 全词表参考。判断错误的依据是参考数值断言，不是“两个实现 token 不同”。Oracle 的引擎进程完成了生成，不是 CUDA 初始化、联网、超时或依赖失败。

日志：`pr60-{candidate,oracle}-hnd-{0,1}.log`；启动命令和检查脚本预运行哈希见对应 `*-before.json`；结果见 `*-result.json`。这些是局部独立诊断，不是改版完整 Harbor reward。本次没有对新版完整评分打分，也未把原分数覆盖。

### 最小修复建议

1. 在独立进程中显式覆盖 NHD/HND，至少纳入 FlashInfer 的真实 DCP prefill+decode、eager/graph 和批次变化；输入/预期仍由公开合同和独立 CPU 参考决定。
2. 修补 Oracle 的 HND 行为，保留当前 GPT 答案为不同实现的正控制；保留旧 Oracle 作为这一缺陷的反例。
3. 冻结新版本后，用旧 Oracle、修订 Oracle、保存 GPT 和 Base 做相应校准，最后对受影响实现跑完整 Harbor。无需为了定位这一个问题立即再花费模型额度。
4. 不应删除题面 layouts 要求、只允许 NHD，或把 ragged wrapper 的具体内部修改写进题面来回避问题。

## 5. PR61 轨迹、测试修改和独立挑战

### 过程与实现

Agent 把 remote in-flight 请求移出 runnable waiting 队列；只有完成事件触发重新合并。使用等待期间的顺序编号恢复 FCFS，运行/结束/取消后清理相关记录，并更新 counts、stats、未完成请求计数、失败恢复与 preemption 路径。

生产代码只改 `scheduler.py`。另外六个文件是已有上游测试/辅助函数：把“所有等待必须位于 scheduler.waiting”的旧内部表示断言改为等待总数或新的存储位置，并补充无轮询/FCFS回归。检查这些修改后，没有发现把应有的 token、错误恢复或终止行为断言删除来掩盖实现错误。候选自己的测试可以采用自己的字段；我们的隐藏评分不能因此依赖候选新增字段。

Step 23 起实际运行 focused tests，先4失败、再2失败、修改后13通过；随后 full scheduler 93通过1跳过。KV生命周期一度12失败8通过，原因包含旧队列表示假设，调整后20通过；错误传播组随后修正一处相同表示断言并重跑。async scheduler 8通过。内存自测完成5000个短请求，观测 retained 增长173,232字节。

### 一个报告口径小问题

Agent 最后自述“remote lifecycle/recovery/error 34 passed，async 8 passed”，不能直接相加。原日志可核实的是 remote prefill/recovery/invalid-block 20 项、remote decode 4 项、error propagation 2 项，合计 **26 项**，另有 async 8 项；34 很可能已经包含 async。报告应引用原始命令结果，不把 Agent 的数字当作统计真值。此问题不改变 hidden verifier 的18/18。

### 本次补充事件挑战

在固定镜像中只读使用原最终候选、Oracle、Base，给真实 scheduler 送入36个请求，分三批到达；一半需要真实进入异步等待状态后才发送完成事件，完成顺序由固定随机种子决定；交错取消 pending request，送达取消后的完成事件，检查仍可运行请求的 FCFS、每个客户端 token/终止、counts 和最终排空。断言通过稳定的 schedule/update_from_output/finish_requests 与输出边界，不读取新加的 holding map 或 order 字段。

- 3 seeds（173/409/811）× 2 capacities（1/3）= **6 组/实现**。
- 候选、Oracle、Base 都6/6通过。Base通过此正确性保存检查是合理的；它仍因 idle 性能在原完整 verifier 得0。
- 第一个诊断草稿错误地给尚未开始传输的请求发送 completion，三种实现都触发生产断言；已明确归类为**审查 fixture 错误**，不当成 Agent 或 task 缺陷。保留 `challenge61.py` 及原失败记录，另存合法事件的 `challenge61_v2.py` 和 `*-events-v2.*`，没有覆盖历史失败。
- 这个随机挑战并非穷举，也不是实际网络/模型吞吐测试；它增加事件交错证据，不提供“所有正确性均已证明”的保证。

后续可补强 connector invalid-block 的 fail/recompute 与 delayed-free 生命周期，但本轮没有复现这些维度中的错误评分，不能把建议自动升级成阻塞。

## 6. 评分、泄漏与限制

原始评分不仅有退出码，还有19/18个检查点、worker正常退出、数值/生命周期日志，未发现候选触碰 reward 或提前退出的具体行为。PR60 远程 GitHub 查询被403阻止；ruff下载也失败。没有观察到成功的答案泄漏。不能据此认证所有潜在绕过都不存在。

先前 task review 中完整评分信任审计仍为未关闭项，本次**不重试此前受限的安全探针**。root-owned Python、隔离容器或检查点数量本身也不是完备防篡改证明。H20实测不等于A100认证，已有 native donor/cutoff 限制继续保留。

`inventory-before.json` 在诊断前记录本轮候选变更、完整task文件和轨迹哈希；`review-results.json` 确认诊断后这些输入与原summary未变。Oracle来源是先前Harbor完整导出，本次只读挂载；不要将事后生成的报告哈希误写成所有Oracle文件都已预先独立哈希。

## 7. 文件与交接

- `REPORT.zh-CN.md`：本报告。
- `inventory-before.json`：两次模型样本、源代码和skill身份、预诊断哈希、计数口径。
- `pr60-final.patch` / `pr61-final.patch`：最终已跟踪差异副本；新增测试仍在原完整artifact中，不把patch误称为完整交付。
- `pr60-trajectory-index.txt` / `pr61-trajectory-index.txt`：逐步工具输入和输出摘录，明确标注裁剪位置，不能替代原始sessions/ATIF。
- `run_challenges.py`：HND差分检查和第一版事件诊断的执行记录来源。
- `challenge61_v2.py` / `run_events_v2.py`：合法事件挑战与对应执行入口。
- `*-before.json` / `*-result.json` / `*.log`：命令、局部结果和原日志。
- `review-results.json`：结构化结论、局部重放结果、诊断后哈希一致性。

**最终建议：保留两题；PR61 本轮功能审查无新增阻塞；PR60 在合入前补 HND 行为覆盖并修订 Oracle。** 本轮未修改题面、verifier、Oracle、原始分数或 GitHub 内容，也没有启动新的模型评测。
