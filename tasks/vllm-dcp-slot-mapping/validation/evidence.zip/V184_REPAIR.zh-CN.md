# GPT-6 串行审阅发现的 PR60 覆盖缺口

本轮是在 v1.8.3 第一份 GPT-6 答案得 1 分之后，对最终实现和更多真实引擎输入进行独立审阅发现的；不是根据分数自动放行。原始分数、模型轨迹和源代码均保持不变。PR61 独立队列不受影响。

## FlashInfer 部分 prefill

用 13/62/63-token 提示、block32、interleave2、max_num_batched_tokens=32、后续动态接入请求，强制出现已缓存上下文与当前 query 的 attention 结果合并。原 Oracle 的 HND eager/graph 均数值错误，完整 256 维 logprob 有 151 维超差、最大误差约 0.107432；原 GPT-6 r01 同条件通过，最大误差约 0.002830，容差为 0.02。

源码与对照表明：context-parallel gather 返回 base-2 LSE，而合并算子按自然对数处理。Oracle 应在合并前统一 LSE 单位。新增正式评分覆盖 NHD/HND × eager/graph 四组，不检查修复写在哪个函数或是否使用某个表达式，只比较真实生成与独立 CPU FP32 参考。旧套件 maxbatch128 未强制触发这个路径。

## FlashAttention interleave1 graph 启动

Oracle 和原 GPT-6 r01 在 interleave1 graph 模式初始化后、首次真实请求前出现 illegal memory access。interleave2 graph、interleave1 eager 可以运行；Base legacy runner 也可运行（但 DCP 数值不正确）。同步插桩确认各尺寸 capture 本身完成，进一步定位到 post-capture warmup：dummy run 声明跳过 attention，但执行路径仍选择 captured graph，attention 元数据却未更新。

两种独立修法在相同完整引擎输入与 CPU 全词表参考下都通过（最大误差约 0.002343）：Oracle 在明确 skip-attention dummy 时不选 graph；另一正对照保留 graph，但更新该 dummy 所需 attention 元数据。两者都不关闭真实请求的 CUDA graph，不通过全局关闭 custom allreduce 回避正常配置。新增正式评分运行 FA interleave1 NHD/HND graph 两组，不约束采用哪一种内部修法。

## 校准与样本身份

v1.8.4 保留旧 21 项并增加 3 个检查组，总计 24 项、14 个完整引擎组合。题面、环境、镜像不变。完整 Harbor 校准由 v184-calibration/calibrate 输入快照绑定，运行结果见 v184-calibration/results.json（生成前不得声称校准完成）。对照为 Base、修复 Oracle、旧 v183 Oracle、原 GPT-6 r01 加另一种 dummy 修法的人工正对照。人工正对照不是新的模型试验，也不是原样 r01。

FA 的初版 overlay 因文件同名遮蔽 flash_attn 包、临时 clone 缺 native _C.so，以及 CUDA_LAUNCH_BLOCKING 超时的诊断均保留，不当作候选语义失败。有效实验使用完整运行产物与原始镜像；只挂载诊断修改，不改历史答案。

新版本通过校准后，只续跑 PR60 剩下 r02–r04，不重新凑四份新样本。报告须写清 r01 属于 v183、后续属于校准后的版本；不把不同版本直接合并为严格同分布的 pass@k。整个过程不自动提交或推送。
