# PR60：Eagle verifier 内部接口耦合修复（v1.8.3）

本轮只修订已确认的 verifier 公平性问题，不新增模型调用，不改写历史成绩，不自动推送。使用 ai-infra-bench-rollout-review 对受影响的功能门禁复验；不是全量轨迹/安全认证。v1.8.2 的 HND 修复及八组合引擎测试保留。

## 已确认的问题

原测试直接用两个参数调用 runner.prepare_inputs。保存的 GPT-5.6 Sol/high r02 给该内部方法增加必需的 use_cudagraph 参数，并同步更新真实生产调用点；公开任务没有冻结这个内部签名。旧 fixture 因 TypeError 失败，未触达原本要检查的 Eagle 行为。

原先的首个失败理由不公平，但不意味着 r02 全部正确：独立诊断已发现其 FlashInfer HND 输出错误。旧版 r02 得0、13/21必须保留；新版评分要把接口耦合与真正的数值错误分开。

## 正式修改

- 从正常 execute_model → sample_tokens → take_draft_token_ids 驱动请求，不直接调用 prepare_inputs 或 propose，不检查签名，不加入特定答案的参数适配。
- Target/Draft 权重用确定性模型替代；生产请求更新、输入准备、采样、Eagle proposal、FlashInfer CUDA attention、草稿回传真实执行。
- 从 scheduler 消息边界提供 permissive grammar mask，使正常结构化输出链路回传草稿 token，不读取私有 batch 状态。不把此测试称为 grammar 编译或真实 Eagle 权重端到端测试。
- 精确检查 target token 和两步 draft token，按请求 ID 比较，允许内部 batch 重排。覆盖 [4,7]、跨 block 的 [15,23] 及反序 [23,15]。
- 21 个必需检查点不变；真实双卡引擎 FA/FI × NHD/HND × eager/graph 八组合及独立 CPU 全词表参考完全不变。

题面、环境、镜像、Oracle 均不变。Agent 不会得到新的公开测试、实现提示或函数约束。

## 完整 Harbor 校准

五项均通过实际 Harbor 评分入口运行，新分数如下；保存答案重放不是新的模型实验。

| 对照 | Reward | 完成检查点 | 原因 |
|---|---|---|---|
| Oracle | 1 | 21/21 | 三组 Eagle 与八种真实引擎组合全通过 |
| 原样 r01 | 1 | 21/21 | 三组 Eagle 与八种真实引擎组合全通过 |
| 原样 r02 | 0 | 19/21 | 三组 Eagle 全通过，真实 FlashInfer HND eager 数值错误 |
| Eagle 回归反例 | 0 | 13/21 | 草稿 [[1,0],[1,0]]，预期 [[1,6],[1,9]] |
| Base | 0 | 2/21 | 真实 DCP slot 地址错误 |

r02 的 HND 输出247/256维超差，最大绝对误差1.623551845550537，允许0.02；未再出现内部签名 TypeError。原始0分、13/21不覆盖，新0分、19/21是不同版本下的重评分。Oracle/r01的完整引擎最大 logprob 误差0.0024595260620117188，小于0.02。

## 版本与原始资料

- 运行目录：runs/pr60-eagle-boundary-20260918/controls/。运行前冻结 task/ 和 frozen-hashes.json；每项 *-inputs.json 记录命令、镜像、GPU 绑定、prepared 全文件哈希。
- Harbor 0.22.0，共享 H20 ×2，两组不重叠设备，最多两项评分并行；不代表 A100 验证。
- 镜像 sha256:462fc769cac14468d0c1a7128eb17116c728e12e31efaee14b9ea7fd6c3e9868；Base be3af2d29e2507f32b2190fe015cd6609b348caa。
- 修改起点 af2e23e03652f0a50d6721d6ddb9e51c96ae4d04，本地 review/pr-60。结果绑定运行前文件快照，不伪造尚不存在的提交身份。
- 原始答案来自 gpt56-eight-parallel-20260918/pr60/ 下 r01/task__kUb8Fy3 与 r02/task__y2KxLKq。导出 tracked diff 和 untracked 测试，评分后核对文件与原答案一致。重放不是新增模型作答。
- 完成导出后，validation/evidence.zip 收录完整评分输出和输入身份；旧报告、索引和证据放在其 historical-v182/，更早材料递归保留。ZIP 不包含完整模型轨迹，原始实验目录另存。

## 仍然开放的限制

本轮只校准相关五项，不把未重跑的历史控制声明为新版通过。完整评分信任、此前受限安全探针、A100 认证及已有 native donor/cutoff 限制保持开放。没有重新逐条审核八份完整模型轨迹。Eagle 是明确替代边界的 runner 集成检查；另有真实 TP/DCP 引擎测试，但不等价于所有配置、HTTP、真实模型质量或吞吐基准。

不能据此宣称绝对没有缺陷、完全防篡改或无条件可合入。PR61 未在本轮修改。
