"""Export only completed, attributable v1.8.2 functional evidence."""
import datetime
import itertools
import json
from pathlib import Path
import subprocess
import zipfile
from calibrate import ROOT,W,TASK,hashes,sha,save

folder=ROOT/'controls'
rows=json.loads((folder/'results.json').read_text())
assert len(rows)==7 and all(r['valid'] for r in rows)
matrix={}
expected_matrix=set(itertools.product(('FLASH_ATTN','FLASHINFER'),('NHD','HND'),(False,True)))
for row in rows:
    log=(Path(row['trial'])/'verifier/verifier.log').read_text()
    checks=[json.loads(line.split('=',1)[1]) for line in log.splitlines() if line.startswith('DISTRIBUTED_CHECK=')]
    if row['expected_reward']==1:
        assert len(checks)==8
        assert {(x['backend'],x['layout'],x['graph']) for x in checks}==expected_matrix
        assert all(x['requests']==3 and x['tokens']==19 and x['max_logprob_error']<=.02 for x in checks)
    matrix[row['case']]=checks
save(folder/'observed-generation-matrix.json',matrix)
protected=lambda p:p in ('instruction.md','task.toml') or p.startswith(('environment/','solution/','tests/'))
frozen=json.loads((folder/'frozen-hashes.json').read_text())
assert {k:v for k,v in frozen.items() if protected(k)}=={k:v for k,v in hashes(TASK).items() if protected(k)}
previous=ROOT/'previous-task-v181'
assert sha(previous/'instruction.md')==sha(TASK/'instruction.md')
assert hashes(previous/'environment')==hashes(TASK/'environment')
original=W/'runs/pr60-verifier-fairness-20260917/fresh-gpt56-high/pr60/jobs/pr60-gpt56-sol-high-fairness-r01/task__GETsdtK/artifacts/workspace/repo'
alternative=Path(next(r for r in rows if r['case']=='gpt-hnd-complete-alternative')['trial'])/'artifacts/workspace/repo'
paths=subprocess.check_output(['git','-C',str(original),'diff','--name-only','HEAD']).decode().splitlines()
paths+=subprocess.check_output(['git','-C',str(original),'ls-files','--others','--exclude-standard']).decode().splitlines()
replayed_hashes={p:sha(original/p) for p in paths}
assert all(sha(alternative/p)==digest for p,digest in replayed_hashes.items())
assert subprocess.check_output(['git','-C',str(original),'diff','--binary','HEAD'])==subprocess.check_output(['git','-C',str(alternative),'diff','--binary','HEAD'])
with zipfile.ZipFile(TASK/'validation/evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ('evidence.zip','ci-cases.json','e2e-evidence.json','review-report.md','remediation-matrix.md'):
        archive.write(previous/'validation'/name,'historical-v181/'+name)
    for name in ('calibrate.py','prepare.py','export.py','inspect_results.py','WORKLOG.zh-CN.md'):
        archive.write(ROOT/name,name)
    review=W/'runs/pr60-verifier-fairness-20260917/rollout-review'
    for p in review.glob('pr60-*-hnd-*'):
        if p.is_file():archive.write(p,'hnd-diagnosis/'+p.name)
    archive.write(review/'REPORT.zh-CN.md','hnd-diagnosis/REPORT.zh-CN.md')
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or any(x in p.parts for x in ('task','prepared','artifacts')):continue
        if p.suffix in ('.json','.log','.txt','.xml'):archive.write(p,str(p.relative_to(ROOT)))
by_name={r['case']:r for r in rows}
manifest=json.loads((TASK/'validation/ci-cases.json').read_text())
for case in manifest['cases']:
    if case['name'] in by_name:
        row=by_name[case['name']]
        case.update(execution_status='validated-v182-full-harbor',observed_reward=row['observed_rewards'][0],
            evidence='evidence.zip:controls/'+case['name']+'-result.json')
manifest['status']='seven-functional-controls-validated-v182; remaining-controls-not-replayed'
save(TASK/'validation/ci-cases.json',manifest)
old=json.loads((previous/'validation/e2e-evidence.json').read_text())
skill=W/'repositories/official/.agents/skills/ai-infra-bench-rollout-review'
skill_identity={'repository_head':subprocess.check_output(['git','-C',str(skill),'rev-parse','HEAD']).decode().strip(),
    'files':{name:sha(skill/name) for name in ('SKILL.md','references/differential-cases.md','references/reporting.md')}}
evidence={
    'schema_version':old['schema_version'],'task_version':'1.8.2',
    'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status':'v182-hnd-functional-repair-calibrated; separate-security-and-A100-certification-open',
    'source':old['source'],'image':old['image'],'e2e_boundary':old['e2e_boundary'],
    'review_skill':skill_identity,
    'final_acceptance':False,'functional_calibration_passed':True,'current_controls':rows,
    'explicit_generation_matrix':{'backends':['FLASH_ATTN','FLASHINFER'],'layouts':['NHD','HND'],'graph':[False,True],
        'combinations':8,'requests_per_combination':3,'tokens_per_combination':19,'vocab_size':256,'atol':0.02,'rtol':0},
    'observed_generation_matrix':'evidence.zip:controls/observed-generation-matrix.json',
    'publication':{'state':'uncommitted local v1.8.2; no push',
        'historical_opus_artifact':old['publication']['historical_opus_artifact'],
        'current_raw_evidence':'evidence.zip','run_snapshot':'evidence.zip:controls/frozen-hashes.json',
        'previous_v181':'evidence.zip:historical-v181/',
        'previous_v180':'evidence.zip:historical-v181/evidence.zip:historical-v180/'},
    'saved_gpt_replay':{'original_trial':'pr60-gpt56-sol-high-fairness-r01/task__GETsdtK',
        'original_reward':1,'original_task_version':'1.8.1','original_required':19,
        'replay_reward':1,'replay_required':21,'new_model_attempt':False,
        'tracked_and_untracked_file_hashes':replayed_hashes},
    'oracle_hnd_regression':{'historical_oracle_version':'1.8.1','historical_reward':1,
        'new_case':'historical-oracle-hnd-prefill','new_reward':0,
        'cause':'Paged HND layout incorrectly applied to token-major uncached K/V inputs.'},
    'limitations':['Shared H20 x2, not A100 certification.',
        'Existing native dependency donor/cutoff limitation remains; environment bytes unchanged.',
        'Grading-trust certification remains open; restricted security probes not rerun.',
        'Seven relevant functional controls replayed; other historical controls not newly certified.',
        'Saved answer replay is development evidence, not an additional fresh model trial.'],
    'artifacts':{'files':{}}
}
evidence['artifacts']['files']={k:v for k,v in hashes(TASK).items() if k!='validation/e2e-evidence.json'}
save(TASK/'validation/e2e-evidence.json',evidence)
save(ROOT/'export-result.json',{'controls':len(rows),'source_hashes_match':True,'saved_gpt_files_identical':True,
    'instruction_and_environment_unchanged':True,'evidence_zip_bytes':(TASK/'validation/evidence.zip').stat().st_size})
print((ROOT/'export-result.json').read_text())
