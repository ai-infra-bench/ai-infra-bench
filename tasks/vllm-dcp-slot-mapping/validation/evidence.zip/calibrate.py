"""Seven full Harbor controls for v1.8.2; no model calls, two GPU lanes."""
import ast
import concurrent.futures
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import tomllib

ROOT = Path(__file__).parent
W = ROOT.parents[1]
TASK = W/'worktrees/pr-60/tasks/vllm-dcp-slot-mapping'
HARBOR = '/root/workspace/dxz-workspace/claude-tap-agent/.venv/bin/harbor'
ENV = dict(os.environ,DOCKER_HOST='unix:///root/workspace/dxz-workspace/.docker-dxz/run/docker.sock',DOCKER_CONFIG='/root/workspace/dxz-workspace/.docker-dxz/client')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(p):return {str(x.relative_to(p)):sha(x) for x in sorted(p.rglob('*')) if x.is_file() and '__pycache__' not in x.parts}
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
spec=importlib.util.spec_from_file_location('ci',W/'worktrees/pr-60/.github/scripts/task_ci.py')
ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)

def main():
    folder=ROOT/'controls';folder.mkdir()
    frozen=folder/'task';shutil.copytree(TASK,frozen)
    save(folder/'frozen-hashes.json',hashes(frozen))
    cfg=tomllib.loads((frozen/'task.toml').read_text())
    assert cfg['task']['version']=='1.8.2'
    image=cfg['metadata']['image_digest']
    actual=json.loads(subprocess.check_output(['docker','image','inspect',cfg['environment']['docker_image']],env=ENV))[0]['Id']
    assert image==actual
    source=ast.parse((frozen/'tests/verify_dcp_slot_mapping.py').read_text())
    required=next(len(ast.literal_eval(n.value)) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED_CHECKPOINTS' for t in n.targets))
    assert required==21
    def lane(cases,gpus):
        rows=[]
        for case,expected in cases:
            prepared=folder/'prepared'/case
            assert not prepared.exists()
            agent=ci.prepare_case(frozen,image,case,prepared)
            for relative in ('environment/docker-compose.yaml','tests/docker-compose.yaml'):
                p=prepared/relative;s=p.read_text();assert s.count('count: 2')==1
                p.write_text(s.replace('count: 2',f'device_ids: ["{gpus[0]}", "{gpus[1]}"]'))
            before=hashes(prepared);name='hnd182-'+case
            cmd=[HARBOR,'run','-a',agent,'--cpus','ignore','--memory','ignore',
                 '--override-gpus','0','--yes','-p',str(prepared),'--job-name',name,'-o',str(folder/'harbor')]
            save(folder/(case+'-inputs.json'),{'command':cmd,'image':image,'gpus':gpus,'hardware':'shared H20 x2','hashes':before,'required':required})
            started=datetime.datetime.now(datetime.timezone.utc).isoformat()
            print('START',case,started,flush=True)
            with (folder/(case+'.log')).open('w') as log:
                code=subprocess.run(cmd,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=2400).returncode
            job=folder/'harbor'/name
            completed,errors,rewards=ci.result_reward(job/'result.json')
            trials=list(job.glob('*/result.json'));assert len(trials)==1
            trial=trials[0].parent
            verdict=json.loads((trial/'verifier/reward.json').read_text())
            valid=code==0 and completed==1 and errors==0 and rewards==[expected] and before==hashes(prepared)
            if expected==1:valid &= verdict['completed']==verdict['required']==required
            row={'case':case,'expected_reward':expected,'observed_rewards':rewards,'harness_errors':errors,
                 'completed':completed,'exit_code':code,'verdict':verdict,'trial':str(trial),
                 'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'inputs_unchanged':before==hashes(prepared),'valid':bool(valid)}
            save(folder/(case+'-result.json'),row);print(json.dumps(row),flush=True);rows.append(row)
        return rows
    lanes=[([('oracle',1),('base',0),('historical-oracle-stale-backend',0),('non-dcp-eagle-regression',0)],[4,5]),
           ([('gpt-hnd-complete-alternative',1),('historical-oracle-hnd-prefill',0),('historical-oracle-no-flashinfer',0)],[6,7])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(lane,*args) for args in lanes]
        rows=[row for f in futures for row in f.result()]
    save(folder/'results.json',rows)
    assert hashes(frozen)==json.loads((folder/'frozen-hashes.json').read_text())
    assert all(r['valid'] for r in rows),'Calibration mismatch: inspect raw records'

if __name__=='__main__':main()
