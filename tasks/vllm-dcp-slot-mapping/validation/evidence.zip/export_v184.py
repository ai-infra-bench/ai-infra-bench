"""Export only completed functional calibration, retaining historical evidence."""
import itertools
import json
from pathlib import Path
import zipfile
from campaign import ROOT, W, hashes, sha, save, now, protected

task = W/'worktrees/pr-60/tasks/vllm-dcp-slot-mapping'
folder = ROOT/'v184-calibration'
rows = json.loads((folder/'results.json').read_text())
assert len(rows) == 4 and all(r['valid'] for r in rows)
assert not (folder/'export-result.json').exists()
frozen = json.loads((folder/'frozen-hashes.json').read_text())
assert {k:v for k,v in frozen.items() if protected(k)} == {k:v for k,v in hashes(task).items() if protected(k)}
expected = set(itertools.product(('FLASH_ATTN','FLASHINFER'),('NHD','HND'),(False,True),('batched',)))
expected |= set(itertools.product(('FLASHINFER',),('NHD','HND'),(False,True),('chunked',)))
expected |= set(itertools.product(('FLASH_ATTN',),('NHD','HND'),(True,),('interleave1',)))
matrix = {}
for row in rows:
    log = (Path(row['trial'])/'verifier/verifier.log').read_text()
    generation = [json.loads(x.split('=',1)[1]) for x in log.splitlines() if x.startswith('DISTRIBUTED_CHECK=')]
    eagle = [json.loads(x.split('=',1)[1]) for x in log.splitlines() if x.startswith('EAGLE_NON_DCP_CASE=')]
    if row['expected_reward'] == 1:
        assert len(generation) == 14
        assert {(x['backend'],x['layout'],x['graph'],x['profile']) for x in generation} == expected
        assert len(eagle) == 3 and all(x['passed'] for x in eagle)
    if row['case'] == 'historical-oracle-v183':
        assert row['verdict']['completed'] == 20
        assert 'logprob' in log and 'AssertionError' in log
        assert len(generation) == 8
    matrix[row['case']] = {'generation':generation,'eagle':eagle}
save(folder/'observed-behavior.json',matrix)
by_name = {r['case']:r for r in rows}
manifest = json.loads((task/'validation/ci-cases.json').read_text())
for case in manifest['cases']:
    if case['name'] in by_name:
        row = by_name[case['name']]
        case.update(execution_status='validated-v184-full-harbor',observed_reward=row['observed_rewards'][0],evidence='evidence.zip:v184-calibration/'+case['name']+'-result.json')
manifest['status'] = 'four-functional-controls-validated-v184; other controls pending; no inherited scores'
save(task/'validation/ci-cases.json',manifest)
previous = ROOT/'snapshots/pr60'
with zipfile.ZipFile(task/'validation/evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ('evidence.zip','ci-cases.json','e2e-evidence.json','review-report.md','remediation-matrix.md'):
        archive.write(previous/'validation'/name,'historical-v183/'+name)
    for name in ('calibrate_v184.py','export_v184.py','V184_REPAIR.zh-CN.md'):
        archive.write(ROOT/name,name)
    for p in sorted(folder.rglob('*')):
        if not p.is_file() or any(x in p.relative_to(folder).parts for x in ('task','prepared','artifacts')):
            continue
        if p.suffix in ('.json','.log','.txt','.xml'):
            archive.write(p,str(p.relative_to(ROOT)))
e = json.loads((task/'validation/e2e-evidence.json').read_text())
e.update(recorded_at=now(),status='v184-functional-calibration-passed; security-and-A100-certification-open',functional_calibration_passed=True,current_controls=rows,observed_behavior='evidence.zip:v184-calibration/observed-behavior.json')
e['explicit_generation_matrix'] = {'combinations':14,'cases':[dict(backend=b,layout=l,graph=g,profile=p) for b,l,g,p in sorted(expected)],'vocab_size':256,'atol':0.02,'rtol':0,'reference':'CPU FP32 Transformers, same immutable weights'}
e['limitations'] = [x for x in e['limitations'] if not x.startswith(('Five relevant','v1.8.4 behavior'))]
e['limitations'].append('Four relevant full Harbor controls replayed; other historical cases pending. Curated positive contains a reviewer edit and is not an unchanged model answer. Eagle remains a substituted-model runner integration test.')
e['publication']['run_snapshot']='evidence.zip:v184-calibration/frozen-hashes.json'
e['publication']['previous_v183']='evidence.zip:historical-v183/'
e['historical_saved_answers_v183']=e.pop('saved_answers')
e['saved_answers']={'original_scores_unchanged':True,'new_model_attempts_in_calibration':0,'gpt6_r01_original':{'task_version':'1.8.3','reward':1,'completed':21,'current_full_regrade':'not executed; independent FA interleave1 challenge fails'},'curated_alternative':'Complete original GPT6 r01 plus reviewer metadata-refresh fix; not a fresh model attempt'}
e['artifacts']['files']={k:v for k,v in hashes(task).items() if k!='validation/e2e-evidence.json'}
save(task/'validation/e2e-evidence.json',e)
save(folder/'export-result.json',{'completed_at':now(),'controls':4,'protected_hashes_match':True,'evidence_zip_bytes':(task/'validation/evidence.zip').stat().st_size,'evidence_zip_sha256':sha(task/'validation/evidence.zip')})
print((folder/'export-result.json').read_text())
