"""Extra curator-only mixed-prefill challenge; NOT part of the score.

It uses a pre-existing private wrapper only for diagnosis of local context.
No full DCP reduction or model inference is claimed.
"""
import importlib.util
import json
from unittest.mock import patch
import torch
from vllm.v1.attention.backend import CommonAttentionMetadata
from vllm.v1.attention.backends import flashinfer

spec = importlib.util.spec_from_file_location('fi_cases', '/task/tests/verify_flashinfer_dcp.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = flashinfer.FlashInferMetadataBuilder.build

for block_size in (16, 32):
    for rank in (0, 1):
        cache = torch.zeros((32, 2, block_size, 1, 128), device='cuda', dtype=torch.float16)
        for base, offset in ((1, 0), (10, 100), (20, 200)):
            positions = [p for p in range(128) if (p//2)%2 == rank]
            for local, p in enumerate(positions):
                cache[base+local//block_size, 1, local%block_size, 0] = (p+1+offset)/512
        rows = []

        def mixed_build(builder, common_prefix_len, common_attn_metadata, **kwargs):
            common = common_attn_metadata
            lengths = common.seq_lens.cpu().tolist()
            blocks = common.block_table_tensor.cpu().tolist()
            slots = []
            for i, query_len in enumerate((1, 3)):
                for p in range(lengths[i]-query_len, lengths[i]):
                    local = sum((j//2)%2 == rank for j in range(p))
                    slots.append(blocks[i][local//block_size]*block_size+local%block_size
                                 if (p//2)%2 == rank else -1)
            qo = torch.tensor([0, 1, 4], dtype=torch.int32)
            mixed = CommonAttentionMetadata(query_start_loc=qo.cuda(), query_start_loc_cpu=qo,
                seq_lens=common.seq_lens, num_reqs=2, num_actual_tokens=4,
                max_query_len=3, max_seq_len=max(lengths),
                block_table_tensor=common.block_table_tensor,
                slot_mapping=torch.tensor(slots, dtype=torch.int64, device='cuda'),
                causal=True, _seq_lens_cpu=torch.tensor(lengths, dtype=torch.int32))
            metadata = original(builder, 0, mixed)
            query = torch.zeros((3, 4, 128), device='cuda', dtype=torch.float16)
            cache_for_wrapper = (cache.permute(0, 1, 3, 2, 4).contiguous()
                                 if flashinfer.get_kv_cache_layout() == 'HND' else cache)
            output = metadata.prefill.wrapper._context.run(query, cache_for_wrapper)
            prefix = lengths[1] - 3
            offset = {1:0, 10:100, 20:200}[blocks[1][0]]
            owned = [p for p in range(prefix) if (p//2)%2 == rank]
            expected = sum((p+1+offset)/512 for p in owned)/len(owned)
            torch.testing.assert_close(output.float(), torch.full_like(output.float(), expected),
                                       rtol=0, atol=0.001)
            rows.append(dict(lengths=lengths, prefix=prefix, expected=expected,
                             observed=output[0,0,0].item()))
            # Restore ordinary decode planning for the separately scored check.
            return original(builder, common_prefix_len, common, **kwargs)

        with patch.object(flashinfer.FlashInferMetadataBuilder, 'build', mixed_build):
            module.check_flashinfer(rank=rank, graph=False, block_size=block_size)
        print('PREFILL_CONTEXT=' + json.dumps(dict(rank=rank, block_size=block_size,
                                                  rows=rows)), flush=True)
