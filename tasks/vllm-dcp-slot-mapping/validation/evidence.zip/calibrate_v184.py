"""Freeze and run full Harbor controls for the rollout-derived correction."""
import concurrent.futures,importlib.util,json,subprocess,shutil,tomllib
from campaign import ROOT,W,save,sha,hashes,support,now
TASK=W/'worktrees/pr-60/tasks/vllm-dcp-slot-mapping'
OUT=ROOT/'v184-calibration'
HARBOR='/root/workspace/dxz-workspace/claude-tap-agent/.venv/bin/harbor'
spec=importlib.util.spec_from_file_location('taskci',W/'worktrees/pr-60/.github/scripts/task_ci.py')
ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)

def main():
    assert not OUT.exists()
    OUT.mkdir();frozen=OUT/'task';shutil.copytree(TASK,frozen)
    before=hashes(frozen);save(OUT/'frozen-hashes.json',before)
    cfg=tomllib.loads((frozen/'task.toml').read_text());assert cfg['task']['version']=='1.8.4'
    image=cfg['metadata']['image_digest']
    assert json.loads(subprocess.check_output(['docker','image','inspect',cfg['environment']['docker_image']],env=support.docker_env()))[0]['Id']==image
    def case(name,expected,gpus):
        prepared=OUT/'prepared'/name
        assert not prepared.exists()
        agent=ci.prepare_case(frozen,image,name,prepared)
        for relative in ('environment/docker-compose.yaml','tests/docker-compose.yaml'):
            p=prepared/relative;s=p.read_text();assert s.count('count: 2')==1
            p.write_text(s.replace('count: 2',f'device_ids: ["{gpus[0]}", "{gpus[1]}"]'))
        identity=hashes(prepared)
        job='v184-'+name
        cmd=[HARBOR,'run','-a',agent,'--cpus','ignore','--memory','ignore','--override-gpus','0','--yes','-p',str(prepared),'--job-name',job,'-o',str(OUT/'harbor')]
        save(OUT/(name+'-inputs.json'),dict(command=cmd,image=image,gpus=gpus,hardware='shared H20; at most two calibration processes per pair',hashes=identity,started_at=now()))
        print('START',name,now(),flush=True)
        with (OUT/(name+'.log')).open('w') as log:
            code=subprocess.run(cmd,env=support.docker_env(),stdout=log,stderr=subprocess.STDOUT,timeout=2700).returncode
        completed,errors,rewards=ci.result_reward(OUT/'harbor'/job/'result.json')
        trials=list((OUT/'harbor'/job).glob('*/result.json'));assert len(trials)==1
        trial=trials[0].parent;verdict=json.loads((trial/'verifier/reward.json').read_text())
        valid=code==0 and completed==1 and errors==0 and rewards==[expected] and hashes(prepared)==identity
        if expected==1:valid &= verdict['completed']==verdict['required']==24
        row=dict(case=name,expected_reward=expected,observed_rewards=rewards,completed=completed,harness_errors=errors,exit_code=code,verdict=verdict,trial=str(trial),inputs_unchanged=identity==hashes(prepared),valid=bool(valid),finished_at=now())
        save(OUT/(name+'-result.json'),row);print(json.dumps(row),flush=True);return row
    def negatives():
        return [case('base',0,[4,5]),case('historical-oracle-v183',0,[4,5])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        fs=[pool.submit(case,'oracle',1,[4,5]),pool.submit(case,'curated-gpt6-dummy-refresh-alternative',1,[6,7]),pool.submit(negatives)]
        rows=[fs[0].result(),fs[1].result(),*fs[2].result()]
    save(OUT/'results.json',rows)
    assert hashes(frozen)==before
    assert all(r['valid'] for r in rows)
if __name__=='__main__':main()
