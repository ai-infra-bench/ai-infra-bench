**PR #71 task review — 当前版本需要修改后再验收。**

评审对象是 `vllm-streaming-session-continuation` 2.0.0，PR HEAD 为 `43b76921788d39729decb68b2498882d884c181e`。任务场景可以保留，但当前 verifier 存在已复现的直接绕过和多项错误放行；Oracle 也有可观察的跨段状态污染。不能依据现有 reward 1 或旧版 rollout 记录批准当前任务。

**评审身份与范围**

| 项目 | 本次使用的值 |
|---|---|
| PR | https://github.com/ai-infra-bench/ai-infra-bench/pull/71 |
| 任务 worktree | `/tmp/pr71-task-review.Cdv3wh/task`，detached HEAD，任务文件未修改 |
| 任务 Base | `0118cdcc02ae16a137645e2289bf41f5e3da9d80` |
| Oracle 来源 | `3abe7e7b4942d479f2c43188b8cf414e3a21dd38`；实际测试应用本 PR 的 `solution/oracle.patch` |
| cutoff | `2026-01-23T22:53:10Z` |
| 镜像 | `sha256:7089f7eb9e06fff0a086aa0c8ad919aa20fc5f1ec6911a954e81e3316f35846e` |
| 实际硬件 | NVIDIA A100-SXM4-40GB；真实引擎每次使用一张卡，GPU 6 或 7 |
| 网络 | Docker `--network none` |
| 评审规则来源 | `/root/.codex/worktrees/40e7/ai-infra-bench/.agents/skills/ai-infra-bench-task-review`，HEAD `d3b0557d8c22902f6c045cb86f1403de8cd52fd6`，skill 文件无修改 |
| skill hash | `8fe577cbbf18cabee73dd49f510a9f2aa102bd07b5b4bb99e0c4327da666410b` |
| rubric hash | `db7cfadedac4df9b796fc2fa390080a68587cfc4ab6d1b237a2dd308602a8721` |
| playbook hash | `f43a6c1055bfe70a6ad9a8c79ab1ce166e90a1ba56101f498be50e06ea4615f8` |

本次完成题面、全部任务文本/配置/代码/patch、镜像身份与源码历史、完整 Docker 评分入口、针对性的真实 GPU 公共 API probe 和仓库 validator 检查。没有修改任务文件、提交、推送或发布 GitHub 评论；没有重跑 Harbor，也没有深审旧 agent rollout。原工作区已有的 PR61/PR63 未跟踪文件未改动。

**1. [P0] 候选可以伪造 observations 后直接成功退出，未执行测试仍得 1 分。**

位置：`tests/trusted_score.py:53-66`，尤其是候选可写 observations、向候选传递文件路径，以及将 `check(raw, workload)` 的返回值直接记成所有阶段完成。

反例在 `vllm.v1.engine.async_llm` 导入时写入符合格式的 JSON，然后调用 `os._exit(0)`。公开生成 API、模型和 GPU 均未执行，原版 `/tests/test.sh` 仍输出 `completed=true`、三个阶段全部通过、`reward=1`。该容器使用 `--runtime runc` 且未分配 GPU。

仅提前退出但不写 observations 的 `SystemExit(0)` 和 `os._exit(0)` 都得到 0。这说明存在缺失文件检测，但合法格式的候选自报结果仍足以冒充全部验证完成。root supervisor、`-I -S` 和只读测试目录没有提供独立的行为证据。

复现源文件：`forged_exit_async_llm.py`。原始证据：`evidence/forged_exit/report.json`、`reward.txt`、`worker.log`。修复需要重新设计结果来源和完成性核验；额外增加候选可生成的标记、摘要或字段不足以解决问题。

**2. [P1] 没有核对实际续接内容；真实引擎丢弃第二块之后的全部输入仍得 1 分。**

位置：`tests/trusted_score.py:25-38` 与 `tests/verify_streaming_public_api.py:24-29,46-64`。检查主要是非空、request ID、finished 标记，以及 burst 与 delayed 两次候选输出相等。没有独立预期 token 序列，也没有核对每个输入块是否参与了生成。

在 Oracle 中只添加三行控制逻辑，使输入循环处理第一个 chunk 后继续消费、直接忽略后面的 chunks，真实 A100 引擎仍通过三个评分阶段。Oracle 的 bunched 输出为 `[5,5,7,7,12,12]`，反例只输出 `[5,5]`；spaced 同样丢掉后续输出，两次相等使 verifier 继续判成功。

另一个完全不加载模型、每个输入块固定返回 `[4,4]` 的实现，也在无 GPU 容器中得 1。这个反例没有读取测试环境变量或篡改测试；它正常走测试的公共调用，只提供错误的常量实现。

并发会话目前没有与各自独立执行结果比较；ID 复用也没有与全新会话比较。因此这些测试只能证明存在某些输出，不能证明没有跨会话污染或旧状态残留。需要在明确续接规则后独立计算预期结果，并选取能区分丢块、顺序错误、旧上下文残留的输入。

复现源文件：`drop_chunks_async_llm.py`、`constant_async_llm.py`。证据：`evidence/drop-chunks/`、`evidence/constant/`，对应 reward 均为 1。

**3. [P1] 题面承诺保留普通非流式请求，但完全禁用这条路径仍得 1 分。**

位置：`instruction.md:5`；`tests/verify_streaming_public_api.py:7-14,32-64` 的所有请求都通过 async generator 提交。

反例保留 Oracle 的全部真实引擎逻辑，只在 `AsyncLLM.generate` 遇到非 async-generator prompt 时抛出 `ValueError`。完整 GPU 评分入口仍得 1。普通字符串 prompt 请求会被直接拒绝，明确违反题面最后的回归要求。

需要增加普通请求的真实回归，至少覆盖独立普通请求，以及流式会话结束后普通请求仍可正常生成。这里的测试要求可以直接从当前题面推出。

复现源文件：`break_nonstream_async_llm.py`。证据：`evidence/nonstream-broken/`。

**4. [P1] Oracle 的 stop_reason 会污染下一段，当前 verifier 不检查这类公开输出状态。**

位置：`solution/oracle.patch:116-121` 的 session 更新没有清除旧 stop reason；`tests/verify_streaming_public_api.py:15-16` 只记录 token IDs、request ID 和 finished，忽略 completion metadata。

独立公共 API probe 使用未修改的 Oracle、真实 GPU 和任务生成的小模型。第一段因显式 stop token 5 结束；第二段没有配置该 stop token，正常生成 token 7 后因长度结束，公开结果却仍携带 `stop_reason=5`：

```json
[
  {"tokens": [5], "finish_reason": "stop", "stop_reason": 5},
  {"tokens": [7], "finish_reason": "length", "stop_reason": 5}
]
```

这是跨段请求状态未刷新，在公共输出上可直接观察。Base 的 `CompletionOutput` 文档也明确规定，因其他原因结束时 `stop_reason` 应为 None；对应文档片段保存在 `evidence/probes/completion-output-contract.txt`。修复 Oracle 后，应增加分别在上一段运行中、上一段完成后提交 continuation 的行为测试，核对每一段实际结束原因，不要求固定内部清理函数。

复现脚本与日志：`evidence/probes/check_stop_reasons.py`、`evidence/probes/oracle-stop-reasons.log`。上游也有[相关提案 #57584](https://github.com/vllm-project/vllm/pull/57584)，本次查询状态为 open、未合并；本结论依据本地真实运行，不把该提案当成已合并修复。

**5. [P1] 公开输入约定未给出，测试却硬性要求 Oracle 新增的类型；续接语义也需要补清楚。**

位置：`instruction.md:1-3` 与 `tests/verify_streaming_public_api.py:3,10,14`。

题面只要求 public asynchronous generation interface 和有序输入 chunks。Base 中不存在 `vllm.v1.engine.async_llm.StreamingInput`，题面也没有声明该类型、导入位置或 chunk 的字段；测试却在收集任何行为之前就固定导入和构造它。当前 Base 的实际失败正是这个 ImportError。因此 Base=0 尚不能作为目标生命周期行为被有效区分的证据。

要保留固定的公共接口，题面应给出最小调用示例或 agent 可见的公共接口定义。可以明确 `AsyncLLM.generate` 接收什么、每块有哪些公开字段；无需提供 Oracle 的队列、helper、私有字段或算法。

另一个缺口是“valid context”“renewed prompt”和“per-segment request state”缺乏可操作定义。没有说明新 chunk 是增量输入还是完整替换、上一段哪些生成 token 进入下一段上下文、采样参数与预算如何生效。Oracle 实际丢弃上一段最后一个采样 token 的上下文贡献，这个选择不是从当前题面自然唯一确定的。建议用一个短 token 序列例子定义有效上下文，并明确适用的输入形式、采样参数和关闭语义。

附加 probe 证实：两段分别给 `max_tokens=1` 和 `3`、开启 `ignore_eos`，Oracle 返回 `[5,7]`，共 2 个 token；同引擎普通请求预算 3 正常返回 3 个。这说明后续段预算没有覆盖最初值。但当前题面没有明确预算按段还是按会话，因此应先确定契约，再据此决定修 Oracle 与测试，不能直接把预设的 4-token 期望作为隐含评分条件。

上游[提案 #37843](https://github.com/vllm-project/vllm/pull/37843)讨论并尝试修正这一行为，查询结果为 closed、`merged=false`；讨论也提到了预算语义的区分。该提案不是已合并修复的证据。原始运行记录在 `evidence/probes/oracle-semantics.log`。

**6. [P2] 发布验证材料不完整，当前正式 CI 也没有运行 GPU 评分。**

在 PR worktree 执行 `python3 .github/scripts/task_ci.py validate vllm-streaming-session-continuation`，得到 `missing validation/ci-cases.json`。需要补符合当前仓库格式的控制清单及对应材料。

现有 `validation/e2e-evidence.json` 只有概括的 reward=1，没有当前可执行文件 hash、Base/反例/正确替代实现记录、正式运行标识或原始日志。PR 描述仍称版本 1.2.2，而 task.toml 已为 2.0.0；旧 rollout 结论不能直接覆盖当前公共 API verifier。

GitHub [run 35427057116](https://github.com/ai-infra-bench/ai-infra-bench/actions/runs/35427057116)实际停在 discover：双端点比较把分支尚未包含的其他任务认成删除，GPU validation 被跳过。这与 `ci-cases.json` 缺失是不同问题。PR 三点 diff 实际只增加本任务 21 个文件，不能根据这条 CI 日志声称 PR 删除了 async PP 任务。日志保存于 `evidence/github-ci-failure.log`。

**三项评审结论**

| 评审项 | 结论 |
|---|---|
| 题面 | 场景真实、文字简洁；公开输入格式、上下文续接和预算语义需要补齐。无需增加 PP/NCCL 一类与本题无关的术语解释。 |
| 环境 | 固定镜像上真实 A100 路径可运行；源码 HEAD、13,237 个历史提交、无 remotes/未来 Oracle 对象、运行时 import 路径及 native hash 已核对。原生库来自 cutoff 后 v0.15.1，需补语义兼容和 cutoff 分类说明或对应 Base 构建产物，当前不能声明 exact-source 原生环境已验收。 |
| verifier | 阻断：存在直接绕过和多个实测错误 reward；题面与 verifier 尚未双向对齐。 |

环境说明：`environment/lock/README.md` 本身明确记录了 native donor 晚于 cutoff 的近似。不能仅因基础工具发布时间较晚就判环境违规，但也不能把实际参与模型/KV 执行的 vLLM native 文件无条件当成与行为无关的通用工具。本轮验证了字节锁一致和路径可运行，没有证明其与 Base 编译产物的语义等价。部分 worker 日志还出现了继承 root 环境造成的 usage telemetry 权限错误；本次未导致评分失败，属于环境收尾项。

**目标行为与覆盖情况**

`有序输入流 → 公开 AsyncLLM 接口 → 请求/调度/session 状态与 runner → 下一段输入和真实模型执行 → 公开 RequestOutput 与会话结束`。

当前 Oracle 确实运行真实 tokenizer、模型、CUDA 和引擎；问题在于评分证据不足以要求候选也满足这些行为。组件行为测试可以替换不决定生命周期的模型算术，保留真实 session/调度/runner 状态转换；公开 API 端到端测试继续运行真实小模型，并使用与候选实现独立的语义期望。

| 题面行为 | 当前实际覆盖 | 缺口 |
|---|---|---|
| 所有 chunks 按序影响同一会话 | 两次候选输出相等且非空 | 丢掉所有后续块仍过；无独立内容或数量核验 |
| 有效上下文保留、失效输出移除 | 没有对应独立对照 | 需先定义上下文规则，再核对后续实际输入或能区分上下文的输出 |
| per-segment 状态一致 | 固定同一组 SamplingParams | stop_reason 污染已复现；预算语义未明确 |
| 并发会话互不影响 | 各有输出，request ID 正确 | 不比较每个会话与独立运行的结果 |
| 延迟、关闭输入 | 使用 0.03/0.05/0.15 秒 sleep | 未证明 continuation 跨过了“前一段已经完成”状态；时间延迟不等于因果条件 |
| 单块后关闭、ID 复用 | 两次同 ID 请求都产生非空输出 | 不比较复用会话与全新会话，可能遗漏旧状态污染 |
| 普通请求回归 | 未覆盖 | 直接禁用仍得 1 |
| 公开接口自由度 | 固定新增 StreamingInput 类型 | 题面和 Base 未给出该约定 |

独立因果 probe 还在“收到第一段实际输出后才关闭输入”时观察到：async generator 正常结束，但唯一的公开输出 `finished=false`。当前测试强制最后一条输出 `finished=true`。应先统一公开关闭契约，再对这一时序补测试；现有固定 sleep 的通过结果不能证明此路径正确，也不应在契约含糊时把特定终止表示直接作为唯一合法实现。

**本次实际运行的完整评分结果**

以下均运行本 PR 原版 `/tests/test.sh`，没有修改评分代码。它们是固定镜像中的完整 Docker 评分入口结果，不是 Harbor trial。

| 实现 | GPU | reward | 实际解释 |
|---|---|---:|---|
| Base | A100 | 0 | 导入缺少 StreamingInput，尚未进入行为场景 |
| Oracle | A100 | 1 | 当前三个阶段通过；独立 probe 仍发现问题 |
| 固定 token、无模型实现 | 无 | 1 | 错误放行 |
| Oracle + 丢弃后续 chunks | A100 | 1 | 错误放行，只返回第一块对应的 token |
| Oracle + 禁用普通请求 | A100 | 1 | 错误放行，遗漏显式回归要求 |
| 伪造 observations + os._exit(0) | 无 | 1 | 错误放行，未执行公共 API 检查 |
| 裸 SystemExit(0) | 无 | 0 | 因没有 observations 被拒绝 |
| 裸 os._exit(0) | 无 | 0 | 因没有 observations 被拒绝 |

本轮没有声称已验证一个完全满足修订契约的正确替代实现。公开契约需要先补清楚，且已有阻断项；这不是完整公平性验收通过的报告。

**复现入口**

直接绕过可用以下命令重跑。把 `forged_exit_async_llm.py` 替换为 `constant_async_llm.py` 可以复现无模型固定输出误放。

```bash
docker run --rm --runtime runc --network none --user root \
  --cpus 4 --memory 12g --env NVIDIA_VISIBLE_DEVICES=void \
  --mount type=bind,src=/tmp/pr71-task-review.Cdv3wh/task/tasks/vllm-streaming-session-continuation/tests,dst=/tests,readonly \
  --mount type=bind,src=/tmp/pr71-task-review.Cdv3wh/forged_exit_async_llm.py,dst=/workspace/repo/vllm/v1/engine/async_llm.py,readonly \
  sha256:7089f7eb9e06fff0a086aa0c8ad919aa20fc5f1ec6911a954e81e3316f35846e \
  bash -c 'bash /tests/test.sh && cat /logs/verifier/reward.txt'
```

真实引擎反例先通过 `/solution/solve.sh` 应用 PR 原版 Oracle，再只替换 `vllm/v1/engine/async_llm.py` 为对应反例文件，然后运行原版 `/tests/test.sh`。公共 probe 使用同一 Oracle 和 scorer 创建的 GPT-2 模型，脚本和完整日志均在 `evidence/probes/`。全部反例文件与 probe 的 hash 记录在 `evidence/probe-hashes.sha256`；镜像检查和完整 history 也已归档。

**已核对的关键文件 hash**

| 文件 | SHA-256 |
|---|---|
| instruction.md | `8a62e60fe4d0ae3c368b11d730ce1313f7c7e3e50eaea7d2addc75c6783f5c4f` |
| task.toml | `2d43a0300854ee6227f9ca6e932f6c8430beaf06af54dde101ef8d4c83e70ead` |
| environment/Dockerfile | `3bad5b9bf5c68fe98ab87b6f72deaeefd239c650512d2fcdd403c647f23ddece` |
| solution/oracle.patch | `0601b8c98e9f6f9bc0620b5658f8726031899d9b7d3b3dc8b22b23ed69f921be` |
| tests/test.sh | `fef397ceb72bc0041e7be13fe01b5199d029fcb0b3c9f2c6a6f019cf831c2397` |
| tests/trusted_score.py | `b585e3bf04585db4c351c4185aef1364f65e3b6c7d5cc75e834e0fca6717ad3d` |
| tests/verify_streaming_public_api.py | `7581435b7fd5fe2f63b15aaf7b030a625783d7b171c99454c67c5732825d5cd6` |

建议修复顺序：明确最小公共 API 与续接规则；增加独立输出/输入语义对照和可信完成核验；补真实生命周期、普通请求及状态刷新回归并修 Oracle；加入不同正确实现与上述错误对照；补齐 CI 清单、版本与证据，再运行最终评分入口和 Harbor。保留专业开发者 query 的语气，新增文字只用于消除实质歧义。
