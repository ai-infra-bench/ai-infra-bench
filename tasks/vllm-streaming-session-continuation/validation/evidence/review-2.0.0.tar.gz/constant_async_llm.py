"""Negative control: consumes streams but never executes a model or retains context."""

from dataclasses import dataclass

from vllm.outputs import CompletionOutput, RequestOutput


@dataclass
class StreamingInput:
    prompt: object
    sampling_params: object = None


class AsyncLLM:
    @classmethod
    def from_engine_args(cls, *args, **kwargs):
        return cls()

    def shutdown(self):
        pass

    async def generate(self, prompt, sampling_params, request_id, **kwargs):
        async for chunk in prompt:
            yield RequestOutput(
                request_id=request_id,
                prompt=None,
                prompt_token_ids=None,
                prompt_logprobs=None,
                outputs=[CompletionOutput(
                    index=0,
                    text="Hello Hello",
                    token_ids=[4, 4],
                    cumulative_logprob=None,
                    logprobs=None,
                )],
                finished=False,
            )
        yield RequestOutput(
            request_id=request_id,
            prompt=None,
            prompt_token_ids=None,
            prompt_logprobs=None,
            outputs=[],
            finished=True,
        )
