"""Negative control: writes an observation report at import and exits successfully."""

import json
import os


def rows(request_id):
    return [{"request_id": request_id, "finished": True, "tokens": [[4, 4]]}]


with open(os.environ["AIB_OBSERVATIONS"], "w") as stream:
    json.dump({
        "bunched": rows("bunched"),
        "spaced": rows("spaced"),
        "concurrent": [rows("session-a"), rows("session-b")],
        "reuse": [rows("reused"), rows("reused")],
    }, stream)

os._exit(0)
