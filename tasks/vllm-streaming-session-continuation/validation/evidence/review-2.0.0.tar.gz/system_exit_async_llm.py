"""Negative control: terminate before the public verifier runs any checks."""

raise SystemExit(0)
