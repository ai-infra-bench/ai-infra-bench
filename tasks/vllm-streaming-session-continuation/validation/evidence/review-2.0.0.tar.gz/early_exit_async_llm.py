"""Negative control: terminate before the public verifier runs any checks."""

import os

os._exit(0)
