"""Exercise only the scorer's reference seed selection, not library randomness."""
import inspect
import runpy
import secrets

reference_seeds = iter((2651101967022555681, 686053689780348139))
normal_randbits = secrets.randbits

def select_reference_seed(bits):
    if inspect.currentframe().f_back.f_code.co_filename == '/tests/trusted_score.py':
        return next(reference_seeds)
    return normal_randbits(bits)

secrets.randbits = select_reference_seed
runpy.run_path('/tests/trusted_score.py', run_name='__main__')
