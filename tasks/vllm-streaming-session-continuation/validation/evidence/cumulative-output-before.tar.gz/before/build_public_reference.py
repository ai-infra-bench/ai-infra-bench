"""Run inside the pinned image with python3 -I -S, before candidate code."""
import json
from pathlib import Path
import sys
import sysconfig

sys.path.extend(['/tests', sysconfig.get_path('purelib'), sysconfig.get_path('platlib')])
from reference import build_reference

path = Path('/tmp/pr71-public-probe-model')
path.mkdir()
workload, expected = build_reference(path, 686053689780348139)
Path('/tmp/pr71-public-probe-workload.json').write_text(json.dumps({
    'prompt': workload['cases']['single_multitoken']['chunks'][0],
}))
Path('/root/pr71-public-probe-reference.json').write_text(
    json.dumps(expected['single_multitoken'][0]))
