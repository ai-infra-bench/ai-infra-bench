import asyncio
import json
from pathlib import Path
import sys

from vllm.engine.arg_utils import AsyncEngineArgs
from vllm.sampling_params import RequestOutputKind, SamplingParams
from vllm.v1.engine.async_llm import AsyncLLM


async def main():
    workload = json.loads(Path('/tmp/pr71-public-probe-workload.json').read_text())
    engine = AsyncLLM.from_engine_args(AsyncEngineArgs(
        model='/tmp/pr71-public-probe-model', dtype='float32', max_model_len=128,
        max_num_seqs=4, enforce_eager=True, gpu_memory_utilization=0.05,
        kv_cache_memory_bytes=64 * 1024 * 1024,
    ))
    results = {}
    try:
        for kind in (RequestOutputKind.DELTA, RequestOutputKind.CUMULATIVE):
            params = SamplingParams(max_tokens=4, temperature=0, ignore_eos=True,
                                    output_kind=kind)
            rows = []
            async for out in engine.generate(workload['prompt'], params, kind.name):
                rows.append({'finished': out.finished, 'outputs': [
                    {'tokens': list(item.token_ids), 'text': item.text,
                     'finish_reason': item.finish_reason, 'stop_reason': item.stop_reason}
                    for item in out.outputs]})
            results[kind.name] = rows
    finally:
        engine.shutdown()
    Path(sys.argv[1]).write_text(json.dumps(results, indent=2) + '\n')


if __name__ == '__main__':
    asyncio.run(main())
