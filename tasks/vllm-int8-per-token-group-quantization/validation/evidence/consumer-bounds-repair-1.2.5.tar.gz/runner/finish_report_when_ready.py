from pathlib import Path
import time,subprocess,sys
R=Path(__file__).parent
while 'PR17_COMPLETE' not in (R/'pr17-shape-fixed.log').read_text():time.sleep(15)
subprocess.run([sys.executable,str(R/'final_report.py')],check=True)
