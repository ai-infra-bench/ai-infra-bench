from pathlib import Path
import json,hashlib,subprocess,sys,datetime
R=Path(__file__).parent;targets=json.loads((R/'targets.json').read_text());summary={}
for key,v in targets.items():
 T=Path(v['task']);e=json.loads((T/'validation/e2e-evidence.json').read_text());assert e['status']=='validated'
 checks=json.loads((R/(key+'-final-checks.json')).read_text());assert not any(checks.values())
 for name,h in e['freeze']['files'].items():assert hashlib.sha256((T/name).read_bytes()).hexdigest()==h,name
 paras=(T/'instruction.md').read_text().strip().split('\n\n');assert len(paras)==3 and all('\n' not in p for p in paras)
 assert hashlib.sha256((T/'solution/oracle.patch').read_bytes()).hexdigest()==v['before_hashes']['solution/oracle.patch']
 subprocess.run([sys.executable,str(R/'check_portable.py'),key],check=True)
 case='alternate-distinct-profile-accessors' if key=='pr8' else 'positive-lower-bound-rejected'
 replay=next(row for row in e['harbor']['runs'] if row['case']==case)
 final=e['harbor']['final_oracle'];assert final['actual_reward']==1
 summary[key]=dict(task=str(T),version=e['task_version'],harbor_runs=e['harbor']['run_count'],challenges=e['independent_challenges']['run_count'],saved_astra_source_reward=replay['actual_reward'],replay_scope='saved tracked and untracked source applied as control; standard candidate native rebuild for PR17; no new model rollout',final_oracle_job=final['job_id'],final_oracle_trial=final['trial_id'],executable_files=len(e['freeze']['files']),instruction_paragraphs=len(paras),oracle_patch_unchanged=True,checks=checks,excluded_attempts=len(e['excluded_attempts']),superseded_attempts=len(e.get('superseded_control_attempts',[])),portable=json.loads((R/(key+'-portable-check.json')).read_text()))
 if key=='pr17':summary[key]['final_oracle_min_speedup']=final['verifier_result']['stages']['performance_vs_frozen_baseline']['min_speedup']
(R/'final-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
t8=Path(summary['pr8']['task']);t17=Path(summary['pr17']['task']);a=summary['pr8'];b=summary['pr17']
text=f'''# PR8 / PR17 修订与 task-review 结果

两项均已完成本地修订和 ai-infra-bench-task-review 复核。以下仅统计最终评分代码及匹配控制补丁的有效运行；中间修订、取消的旧批次与启动失败单独保留，没有更改历史模型得分。

| Task | 版本 | 完整 Harbor 验证 | 独立 challenge 状态 | 最终 Oracle | 严格审计 |
| --- | --- | ---: | ---: | ---: | --- |
| PR8 | {a['version']} | {a['harbor_runs']} | {a['challenges']} | 1 | 0 错误、0 警告 |
| PR17 | {b['version']} | {b['harbor_runs']} | {b['challenges']} | 1 | 0 错误、0 警告 |

## PR8：修复容量观察点和配置 fixture

评分现在执行真实 scheduler 的 compute_encoder_budget 和 runner 的 MultiModalBudget，允许 registry 使用不同的 prompt / embedding 内部接口。容量 fixture 使用真实 SchedulerConfig 构造：评分采用合法的一 token batch，独立 challenge 采用两 token batch，均保留生产构造函数生成的容量下限，按 max(batch limit, embedding rows) 检查容量。剩余运行时预算为零的调度测试继续保留。独立 challenge 也移除了仅用于日志的额外 registry 默认接口调用。

保存的 Astra 源码控制得到 1；单独破坏 scheduler 或 runner 容量的控制均得到 0。不同合法缓存布局、实际编码写入、缓存复用、连续读取、空窗口和 lookahead 检查仍有效。完成报告和旧观测重放控制已同步到最终结果结构，并因缺少或不匹配本次输入的真实观测得到 0。

[题目说明]({t8}/instruction.md) · [完整复核]({t8}/validation/final-review.md) · [机器可核验的证据]({t8}/validation/e2e-evidence.json)

## PR17：补齐可配置 INT8 区间的行为检查

新增 18 个 FP16 / BF16 / FP32 区间用例，包括 [1,100]、[50,100] 和 [3,7]，由独立运行的冻结 Triton 内核给出数值参考。原生 API 接收自定义上下界，现有 Python 便捷接口没有被强加新的 bounds 参数。独立 challenge 使用不同区间和输入几何。评分阶段结果结构已与原有完成检查一致，Oracle 和合法替代实现通过完整评分。

保存的 Astra 源码经正常重建后，因拒绝合法 [1,100] 输入得到 0；仅加入相同限制的独立负例也得到 0。Oracle、独立原生替代解、兼容别名和重命名私有 helper 的实现都通过。最终 Oracle 的最低加速为 {b['final_oracle_min_speedup']:.3f}×；五个公开工作负载、40 次 warmup、5 组每组 400 次计时和每项至少 1.5× 的门槛保持不变。

[题目说明]({t17}/instruction.md) · [完整复核]({t17}/validation/final-review.md) · [机器可核验的证据]({t17}/validation/e2e-evidence.json)

## 描述与证据范围

两份 instruction.md 均为三个完整自然段，按使用场景、期望行为和运行要求组织，没有逐行硬换行或加入评分器内部步骤。PR8 对接口自由的措辞作了整理；PR17 原有三段描述已经自然，保留原文。任务镜像、环境配方、依赖锁和两份 Oracle patch 和评分解释器启动方式均未因本轮修订而改变。

本轮没有重新调用 Astra / Opus 生成答案，也没有 commit、push 或更新 PR。源码控制重放不是原始 root filesystem 的完整恢复。原模型轨迹和原始分数保持不变。中间的结果结构接入错误、旧配置 fixture 尝试和 Docker 地址池耗尽均保留在原目录及证据中，未计入最终通过结果。PR17 的两个数值负例在额外 GPU 上完整运行，并确认在性能阶段之前因目标行为失败；性能通过结论来自正常性能控制和最终 Oracle。

实际 task 路径、所有当前文件 SHA256、job / trial ID、原始日志及可移交证据包的核验结果见 [final-summary.json]({R}/final-summary.json)。使用的 skill 版本为 {json.loads((R/'skill-provenance.json').read_text())['head']}。
'''
(R/'RESULT.md').write_text(text)
print('ALL_COMPLETE',json.dumps({k:{n:v[n] for n in ['version','harbor_runs','challenges','saved_astra_source_reward']} for k,v in summary.items()}),flush=True)
