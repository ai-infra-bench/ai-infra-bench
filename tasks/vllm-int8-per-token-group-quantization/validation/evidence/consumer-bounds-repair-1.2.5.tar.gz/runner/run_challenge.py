"""Curator-only independent challenge in a fresh image; records actual native identity."""
from pathlib import Path
import json,subprocess,os,sys,hashlib,fcntl,datetime
R=Path(__file__).parent;key,case,tag=sys.argv[1:4]
T=Path(json.loads((R/'targets.json').read_text())[key]['task']);out=R/'challenges'/key/tag/case
case_locks=R/'challenge-output-locks';case_locks.mkdir(exist_ok=True)
case_lock=open(case_locks/(key+'--'+tag+'--'+case+'.lock'),'a+')
fcntl.flock(case_lock,fcntl.LOCK_EX)
if (out/'record.json').exists():
 saved=json.loads((out/'record.json').read_text())
 assert saved['status']=='expected_outcome_observed' and saved['actual']==saved['expected']
 assert saved['image']==json.loads((T/'environment/image-manifest.json').read_text())['image_id']
 assert all(hashlib.sha256((T/p).read_bytes()).hexdigest()==h for p,h in saved['patches'].items())
 for check in saved['checks']:
  assert hashlib.sha256((T/'validation/challenge'/check['script']).read_bytes()).hexdigest()==check['script_sha256']
  assert hashlib.sha256(Path(check['log']).read_bytes()).hexdigest()==check['sha256']
 if key=='pr17':
  source=Path(sys.argv[4]);native=json.loads((source/'manifest.json').read_text())
  assert native==saved['native'] and hashlib.sha256((source/'_C.abi3.so').read_bytes()).hexdigest()==native['sha256']
 print('REUSE_VERIFIED_CHALLENGE',key,case,saved['actual'],str(out),flush=True)
 raise SystemExit(0)
out.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,DOCKER_HOST='unix:///data/yinchen/task-hardening-20260908/runtime-tools/docker-daemon-v2.sock');env['PATH']='/data/yinchen/task-hardening-20260908/runtime-tools/bin:'+env['PATH']
image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']
cases={c['name']:c for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']}
patches=[]
if case=='oracle':patches=['solution/oracle.patch'];expected=1
elif case=='base':expected=0
else:
 c=cases[case];expected=c['expected_reward']
 if c.get('apply_after')=='oracle':patches.append('solution/oracle.patch')
 patches.append('validation/'+c['patch'])
record=dict(scope='independent challenge in fresh pinned-image container; not Harbor or model rollout',case=case,expected=expected,image=image,patches={p:hashlib.sha256((T/p).read_bytes()).hexdigest() for p in patches})
lock=None;cid=None
try:
 flags=[];mounts=[]
 if key=='pr17':
  gpu=os.environ.get('CHALLENGE_GPU','GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329');lock=open('/data/yinchen/vllm-pr8-controls/.phaseD-gpu-locks/'+gpu+'.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  flags=['--gpus','"device='+gpu+'"'];record['gpu']=gpu
  native=Path(sys.argv[4]);manifest=json.loads((native/'manifest.json').read_text());assert hashlib.sha256((native/'_C.abi3.so').read_bytes()).hexdigest()==manifest['sha256']
  run=Path(manifest['source_run']);rr=json.loads((run/'run-record.json').read_text());assert rr['case']==case and rr['status']=='completed_result_checked'
  for p in patches:assert rr['executable_files'][p]==record['patches'][p]
  assert manifest['image']==image
  mounts=['--mount',f'type=bind,src={native},dst=/native,readonly'];record['native']=manifest
 cmd=['docker','run','-d','--network','none',*flags,'--cpus','4','--memory','16384m','--user','root','--workdir','/app' if key=='pr8' else '/workspace/repo','-e','PYTHONDONTWRITEBYTECODE=1','-e','TRITON_CACHE_DIR=/tmp/challenge-triton','--mount',f'type=bind,src={T},dst=/task,readonly',*mounts,'--entrypoint','sleep',image,'infinity']
 cid=subprocess.check_output(cmd,env=env,text=True).strip();record.update(command=cmd,container=cid)
 for p in patches:subprocess.run(['docker','exec','--user','agent',cid,'git','apply','/task/'+p],env=env,check=True,capture_output=True)
 if key=='pr17':subprocess.run(['docker','exec',cid,'cp','/native/_C.abi3.so','/workspace/repo/vllm/_C.abi3.so'],env=env,check=True)
 scripts=['challenge_encoder_cache.py','challenge_encoder_capacity.py'] if key=='pr8' else ['challenge_int8_quant.py']
 results=[]
 for script in scripts:
  command=['docker','exec','--user','nobody',cid,'python3','-I','/task/validation/challenge/'+script]
  logfile=out/(script+'.log')
  with logfile.open('w') as f:proc=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  text=logfile.read_text()
  marker={'challenge_encoder_cache.py':'CHALLENGE_ENCODER_CACHE=PASS','challenge_int8_quant.py':'CHALLENGE_INT8_QUANT=PASS'}.get(script)
  actual=int(proc.returncode==0 and (marker is None or text.splitlines().count(marker)==1))
  results.append(dict(script=script,script_sha256=hashlib.sha256((T/'validation/challenge'/script).read_bytes()).hexdigest(),command=command,exit=proc.returncode,actual=actual,log=str(logfile),sha256=hashlib.sha256(logfile.read_bytes()).hexdigest()))
 record['checks']=results
 record['actual']=int(all(check['actual'] for check in results))
 assert record['actual']==expected,results
 record['status']='expected_outcome_observed'
finally:
 if cid:subprocess.run(['docker','rm','-f',cid],env=env,capture_output=True)
 if lock:lock.close()
 record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['log_sha256']=hashlib.sha256((out/'challenge.log').read_bytes()).hexdigest() if (out/'challenge.log').exists() else None
 (out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(key,case,record.get('actual'),flush=True)
