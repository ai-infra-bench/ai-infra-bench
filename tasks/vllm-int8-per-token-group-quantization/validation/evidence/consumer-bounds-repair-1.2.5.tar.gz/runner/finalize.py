"""Publish only observed results; keep historical rewards and incomplete rollouts separate."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tomllib,tarfile,os,tempfile
R=Path(__file__).parent;key=sys.argv[1]
T=Path(json.loads((R/'targets.json').read_text())[key]['task']);repo=T.parents[1]
S=Path('/data/yinchen/streaming-modular-task-review-20260912T051251Z/skill-repo/.agents/skills/ai-infra-bench-task-review')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((R/(key+'-freeze.json')).read_text());assert all(digest(T/p)==h for p,h in freeze.items())
cases={c['name']:c for c in json.loads((T/'validation/ci-cases.json').read_text())['cases']}
expected={'base':0,'oracle':1,**{k:v['expected_reward'] for k,v in cases.items()}}
old=json.loads((R/'before'/key/'validation/e2e-evidence.json').read_text());image=json.loads((T/'environment/image-manifest.json').read_text())['image_id']

def parse_result(text):
 import re
 for m in re.finditer(r'^\{',text,re.M):
  try:
   d=json.JSONDecoder().raw_decode(text[m.start():])[0]
   if isinstance(d,dict) and d.get('verdict') in ['PASS','FAIL']:return d
  except ValueError:pass
 raise ValueError('missing verifier result')

excluded=json.loads((R/'excluded-startup-runs.json').read_text()) if key=='pr17' else json.loads((R/'excluded-pr8-preparation.json').read_text())
for item in excluded:item['run_root']=item.get('run',item.get('run_root'))
superseded=json.loads((R/'superseded-pr8-config-runs.json').read_text()) if key=='pr8' else json.loads((R/'obsolete-pr17-cancellation.json').read_text())['runs']
superseded=[item for item in superseded if item['run_root'] not in {x['run_root'] for x in excluded}]
excluded_roots={x['run_root'] for x in excluded+superseded}
rows=[]
records=sorted((R/'runs'/key).glob('*/*/run-record.json'))
for path in records:
 if str(path.parent) in excluded_roots:continue
 rec=json.loads(path.read_text());assert rec['status']=='completed_result_checked',(path,rec['status'])
 case=rec['case'];out=path.parent;jobp=Path(rec['raw_result']);job=json.loads(jobp.read_text());trials=list(jobp.parent.glob('*/result.json'));assert len(trials)==1
 trial=json.loads(trials[0].read_text());verifier=trials[0].parent/'verifier';reward=trial['verifier_result']['rewards']['reward']
 assert reward==expected[case]==float((verifier/'reward.txt').read_text())
 assert job['stats']['n_errored_trials']==0 and trial['exception_info'] is None and rec['harbor_exit']==0
 assert rec['image_id_observed']==image
 required=[p for p in freeze if p.startswith(('tests/','environment/')) or p in ['task.toml','solution/solve.sh'] or p=='instruction.md']
 if case=='oracle' or cases.get(case,{}).get('apply_after')=='oracle':required.append('solution/oracle.patch')
 if case in cases:required.append('validation/'+cases[case]['patch'])
 assert all(rec['executable_files'].get(p)==freeze[p] for p in required),(path,'runtime hash mismatch')
 differences=[p for p,h in freeze.items() if rec['executable_files'].get(p)!=h]
 result=parse_result((verifier/('verification.json' if key=='pr8' else 'verification.log')).read_text())
 if reward:assert result['verdict']=='PASS'
 if case in ['early-system-exit','early-os-exit']:
  assert 'CONTROL_REACHED:'+case in json.dumps(result), (case, 'termination boundary marker missing')
 if key=='pr8' and case in ['scheduler-capacity-from-context','runner-capacity-from-context']:
  assert result.get('reason')=='behavioral_observation_mismatch' and result.get('mismatched_stages')==['registry_capacity']
 if key=='pr17' and case in ['base','wrong-public-operator-name']:
  assert 'native_operator_missing' in json.dumps(result)
  assert result['worker_result']['worker_output']['swapped_alias'] is (case=='wrong-public-operator-name')
 if key=='pr17' and reward:
  assert len(result['stages']['configured_ranges']['cases'])==18
  native=json.loads((out/'native/manifest.json').read_text())
  assert digest(out/'native/_C.abi3.so')==native['sha256']
  assert all(t['candidate_observation']['native_sha256']==native['sha256']
             for t in result['stages']['performance_vs_frozen_baseline']['timing'])
 if key=='pr8' and case in ['empty-window-admission','forged-completion','stale-observations','lookahead-omission']:
  assert result.get('reason')=='fresh_behavioral_observation_mismatch'
  if case=='empty-window-admission':assert result['observed']['empty']!=result['expected']['empty']
  if case=='lookahead-omission':
   assert result['observed']['lookahead']!=result['expected']['lookahead']
   assert all(result['observed'][k]==v for k,v in result['expected'].items() if k!='lookahead')
 if key=='pr17' and case=='reciprocal-overflow':assert result['worker_result']['reason']=='precision_boundary_mismatch'
 if key=='pr17' and case=='empty-batch-launch':
  worker=result['worker_result'];assert worker['reason']=='worker_exit_nonzero'
  actual=worker['worker_output'];assert actual['error'].startswith('empty-leading:')
  assert 'invalid configuration argument' in actual['error']
  assert set(actual['stages'])=={'operator_surface','correctness','public_dispatch','configurable_arguments'}
 if key=='pr17' and case in ['positive-lower-bound-rejected','range-must-include-zero']:
  assert result['worker_result']['reason']=='worker_exit_nonzero'
  assert 'float16-1-100:' in result['worker_result']['worker_output']['error']
 if key=='pr17' and case=='slow-candidate-occupancy':assert result['reason']=='performance_below_threshold'
 if key=='pr17' and case=='early-native-timing-exit':assert 'CONTROL_REACHED:early-native-timing-exit' in (out/'curator-native-timing-control.txt').read_text()
 raw={str(p):digest(p) for p in out.rglob('*') if p.is_file() and 'prepared' not in p.parts and 'native' not in p.parts}
 row=dict(case=case,scope='full Harbor run',run_root=str(out),expected_reward=expected[case],actual_reward=reward,image_id=image,gpu_uuids=rec['gpu_uuids'],job_id=job['id'],trial_id=trial['id'],task_checksum=trial['task_checksum'],errored_trials=0,harbor_exit_code=0,grading_and_selected_patch_hashes_match=True,non_grading_snapshot_differences=differences,verifier_result=result,raw_artifacts=raw)
 rows.append(row)
assert set(expected)<={r['case'] for r in rows}
final=next(r for r in rows if r['case']=='oracle' and Path(r['run_root']).parent.name==('frozen-final-real-config-retry' if key=='pr8' else 'frozen-final'))
assert final['actual_reward']==1 and not final['non_grading_snapshot_differences']
challenges=[]
for p in sorted((R/'challenges'/key).glob('*/*/record.json')):
 if key=='pr8' and p.parent.parent.name!='real-config':continue
 d=json.loads(p.read_text())
 if any(digest(T/n)!=h for n,h in d['patches'].items()):continue
 assert d['status']=='expected_outcome_observed' and d['actual']==d['expected']
 assert d['image']==image and all(digest(T/n)==h for n,h in d['patches'].items())
 for check in d['checks']:
  assert digest(Path(check['log']))==check['sha256']
  assert 'ModuleNotFoundError' not in Path(check['log']).read_text()
 if key=='pr17' and d['case'] in ['positive-lower-bound-rejected','range-must-include-zero','reciprocal-overflow','empty-batch-launch']:
  import re
  log=Path(d['checks'][0]['log']).read_text()
  match=next(re.finditer(r'^\{',log,re.M))
  detail=json.JSONDecoder().raw_decode(log[match.start():])[0]
  failed={'positive-lower-bound-rejected':'custom_range','range-must-include-zero':'custom_range','reciprocal-overflow':'tiny_fp32','empty-batch-launch':'empty_inputs'}[d['case']]
  assert set(detail['failures'])=={failed},(d['case'],detail['failures'])
 d['record_path']=str(p);challenges.append(d)
needed={'base','oracle','alternate-dense-cache','alternate-direct-mask-count','alternate-request-initialized-count','alternate-distinct-profile-accessors','scheduler-capacity-from-context','runner-capacity-from-context'} if key=='pr8' else {'base','oracle','alternate-native-kernel','compatible-operator-alias','renamed-private-triton-helper','reciprocal-overflow','empty-batch-launch','range-must-include-zero','positive-lower-bound-rejected'}
assert needed<={r['case'] for r in challenges}
cfg=tomllib.loads((T/'task.toml').read_text());version=cfg['task']['version']
review=dict(mode='hardening',statement='passed; three natural prose paragraphs with the necessary behavioral and performance contract',environment='passed; source cutoff, dependency recipe and image unchanged; image identity and agent-user canary checked before each Harbor run',verification='passed for declared behavioral scope and preserved counterexamples',semantic_boundary=(T/'validation/semantic-boundary.md').read_text())
evidence=dict(schema_version='vllm_harbor_task_validation.v1',status='validated',validation_status='local_full_controls_and_independent_challenges_passed',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),task=cfg['task']['name'],task_version=version,source=old['source'],image=old['image'],artifacts={'files':{p:{'sha256':h} for p,h in freeze.items()}},freeze={'files':freeze,'final_oracle_run':final['run_root']},review=review,skill=json.loads((R/'skill-provenance.json').read_text()),provenance_gates=dict(current_hashes_match=True,final_oracle_passed=True,zero_harbor_errors=True,grading_and_selected_patch_hashes_match=True,historical_rewards_preserved=True),harbor=dict(runs=rows,run_count=len(rows),final_oracle=final,all_expected_outcomes=True,errored_trials=0),independent_challenges=dict(runs=challenges,run_count=len(challenges),all_expected_outcomes=True),prior_review_superseded=('validation/history/1.2.7-before-consumer-profile-repair.json' if key=='pr8' else 'validation/history/1.2.4-before-range-coverage-repair.json'),publication=dict(status='local_changes_not_committed_or_pushed'),excluded_attempts=excluded,superseded_control_attempts=superseded,limitations=['No new model rollout was run. Saved Astra final tracked and untracked source was replayed as a normal control, with a normal verifier native rebuild for PR17; this is not a replay of the entire original root filesystem. Historical scores and reports are unchanged.','Historical incomplete final native/source archives remain a separate rollout-review limitation.','New PR8 workloads reject fixed completion and stale observation replay; this does not certify isolation against arbitrary native process compromise.','Only current-version runs are counted. Any non-grading snapshot differences are recorded per run. Superseded-version runs are retained locally and are not counted as current validation. The final frozen Oracle matches every executable hash.'])
# Portable evidence stores raw logs/results/configs and runner sources. Native
# artifacts remain separately identified by their manifests and absolute paths.
archive=T/'validation/evidence'/('consumer-bounds-repair-'+version+'.tar.gz');archive.parent.mkdir(exist_ok=True)
with tarfile.open(archive,'w:gz') as tar:
 seen=set()
 for row in rows:
  for name in row['raw_artifacts']:
   p=Path(name)
   if p not in seen:tar.add(p,arcname=str(p.relative_to(R)));seen.add(p)
 for attempt in excluded+superseded:
  for p in Path(attempt['run_root']).rglob('*'):
   if p.is_file() and 'prepared' not in p.parts and ('native' not in p.parts or p.name=='manifest.json'):tar.add(p,arcname=str(p.relative_to(R)))
 for row in challenges:
  p=Path(row['record_path']).parent
  for f in p.iterdir():
   if f.is_file():tar.add(f,arcname=str(f.relative_to(R)))
 for p in R.glob('*.py'):tar.add(p,arcname='runner/'+p.name)
 tar.add(R/'CONTRACT.md',arcname='CONTRACT.md')
 tar.add(R/'performance-invariance.json',arcname='performance-invariance.json')
 if key=='pr17':tar.add(R/'performance-final-invariance.json',arcname='performance-final-invariance.json')
 tar.add(R/'skill-provenance.json',arcname='skill-provenance.json')
 tar.add(R/(key+'-freeze.json'),arcname=key+'-freeze.json')
 for name in (['pr8-real-config-proof.log','superseded-pr8-config-runs.json'] if key=='pr8' else ['obsolete-pr17-cancellation.json','additional-negative-gpu-record.json']):
  if (R/name).exists():tar.add(R/name,arcname=name)
 for attempt in excluded:
  if attempt.get('log'):tar.add(attempt['log'],arcname=str(Path(attempt['log']).relative_to(R)))
evidence['portable_raw_evidence']={'archive':str(archive.relative_to(T)),'sha256':digest(archive),'includes':'raw Harbor records/results/logs, independent challenge logs, curator runners; native binaries remain in separately identified local native directories'}
(T/'validation/e2e-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
fix=('Capacity planning now executes the real scheduler compute_encoder_budget and runner MultiModalBudget consumers, controlling only media production and processor-cache creation. SchedulerConfig is constructed for real; the grading batch limit is one and the independent challenge batch limit is two, with expected capacity max(batch limit, embedding rows). The registry default coordinate system is no longer a scoring requirement. The saved Astra source with distinct prompt/embedding accessors passes, while independent scheduler-only and runner-only regressions are rejected. All existing cache, write/read, empty-window, speculative lookahead and parent observation checks remain.' if key=='pr8' else 'Eighteen configured-range observations across FP16/BF16/FP32 now compare the real native operator against the executable frozen Triton kernel. Independent challenge inputs use different positive bounds and geometry. Both the saved Astra source and an isolated added nonpositive-lower-bound restriction are rejected. The Python convenience wrapper does not acquire a new bounds-keyword obligation; existing precision, empty-input, native dispatch, fallback and performance checks remain. The Oracle, corrected native alternative, frozen reference and all timing functions are unchanged.')
text=f'''# {key.upper()} task review — {version}

The task can be retained after this repair. {fix}

Gate 1 passes: the description is three continuous prose paragraphs. Public requirements establish the behavior before the verifier and Oracle. Gate 2 passes: source, dependencies, Docker recipe and image are unchanged; each run checked image identity and an agent-user canary. Gate 3 passes for the declared behavioral boundary: {len(rows)} full Harbor runs and {len(challenges)} independent challenges met their expected outcomes; zero Harbor errors in those completed control runs. {len(excluded)} failed preflight or environment-start attempts are preserved separately and excluded from grading conclusions. The final frozen Oracle scored 1.

The exact source boundary and allowed producer substitutions are documented in semantic-boundary.md. Current executable SHA256 values, image identity, per-run job/trial IDs, actual rewards and raw evidence are in e2e-evidence.json. Only current-version runs are counted. Any non-grading snapshot differences are listed per run. Grading inputs and selected patches match; the final Oracle has no executable differences.

No new model rollout, commit, push or PR update was performed in this repair. Saved Astra source is a preserved implementation control, not a fresh model run. Historical scores remain unchanged, and missing historical final code/native archives still prevent complete rollout certification. This task review does not turn fixed report checks into a claim of isolation from arbitrary native process compromise.
'''
if key=='pr17':text += '\nAn intermediate configured-range result-shape error rejected the Oracle and native alternative before numerical comparison. That batch was superseded after correcting the stage payload, and every full Harbor control in the current result set was rerun. The intermediate results and cancelled work remain separately identified in the evidence.\n'
(T/'validation/final-review.md').write_text(text);(T/'validation/review-report.md').write_text(text);(R/(key+'-RESULT.md')).write_text(text)
checks={}
for name,cmd in [('strict',[sys.executable,str(S/'scripts/audit_task_artifacts.py'),str(T),'--strict-evidence']),('task-ci',[sys.executable,str(repo/'.github/scripts/task_ci.py'),'validate',T.name]),('diff-check',['git','diff','--check','--',str(T.relative_to(repo))])]:
 if name=='diff-check':
  # Include this task's untracked files without modifying the user's Git index.
  with tempfile.TemporaryDirectory(prefix=key+'-index-',dir=R) as scratch:
   env=dict(os.environ,GIT_INDEX_FILE=str(Path(scratch)/'index'))
   subprocess.run(['git','read-tree','HEAD'],cwd=repo,env=env,check=True,capture_output=True)
   subprocess.run(['git','add','-N','--',str(T.relative_to(repo))],cwd=repo,env=env,check=True,capture_output=True)
   proc=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True)
 else:proc=subprocess.run(cmd,cwd=repo,capture_output=True,text=True)
 (R/(key+'-'+name+'.log')).write_text(proc.stdout+proc.stderr);checks[name]=proc.returncode
 print(key,name,proc.returncode,proc.stdout[-500:],proc.stderr[-300:],flush=True)
(R/(key+'-final-checks.json')).write_text(json.dumps(checks,indent=2)+'\n')
if any(checks.values()):
 evidence['status']='final_audit_failed';evidence['validation_status']='requires_correction';evidence['failed_final_checks']=checks
 (T/'validation/e2e-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
 failure_text='FINAL REVIEW INCOMPLETE: '+json.dumps(checks)+'\n\n'+text
 (T/'validation/final-review.md').write_text(failure_text);(R/(key+'-RESULT.md')).write_text(failure_text)
 raise AssertionError(checks)
print('FINALIZED',key,len(rows),len(challenges),flush=True)
