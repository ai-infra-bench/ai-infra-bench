"""Launch final Harbor Oracle only after the frozen full control matrix passes."""
from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).parent
task=root/'repo/tasks/vllm-int8-per-token-group-quantization'
expected={'base':0,'oracle':1}
expected.update({c['name']:c['expected_reward'] for c in json.loads((task/'validation/ci-cases.json').read_text())['cases']})
deadline=time.time()+3600
while time.time()<deadline:
    entries=[(p.parent,r) for p in (root/'direct-matrix-v2').glob('*/summary.json') for r in json.loads(p.read_text())]
    if len(entries)==19:
        assert {r['case'] for _,r in entries}==set(expected)
        for directory,r in entries:
            assert r['matched'] and r['reward']==expected[r['case']],r
            assert (directory/r['case']/'verifier/build-stage.txt').is_file(),r
            if r['case'] in ('oracle','alternate-native-kernel'): assert r['independent_probe_exit']==0,r
        for p,h in json.loads((root/'executable-freeze.json').read_text()).items():
            assert hashlib.sha256((task/p).read_bytes()).hexdigest()==h,p
        for case in ('base','early-system-exit','early-os-exit','early-native-timing-exit'):
            r=json.loads((root/'harbor-v2'/case/'run-record.json').read_text())
            assert r['status']=='completed_result_checked',r
        (root/'final-oracle-gate.json').write_text(json.dumps({'matrix_cases_passed':19,'hashes_match':True,'timestamp':time.time()},indent=2)+'\n')
        subprocess.run(['python3',str(root/'run_harbor.py'),'--case','oracle','--gpu','GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329','--output',str(root/'harbor-v2/oracle')],check=True)
        break
    time.sleep(10)
else:
    raise TimeoutError('Full matrix did not finish before final Oracle gate deadline')
