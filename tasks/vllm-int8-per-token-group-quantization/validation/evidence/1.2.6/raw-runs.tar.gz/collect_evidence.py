"""Summarize actual records and preserve raw logs without duplicating binaries."""
from pathlib import Path
import datetime
import hashlib
import json
import tarfile

root = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def grading(log):
    text = log.read_text()
    data = json.loads(text[text.index("{"):])
    worker = data.get("worker_result", {})
    payload = worker.get("worker_output", {})
    stages = data.get("stages", payload.get("stages", worker.get("stages", {})))
    perf = stages.get("performance_vs_frozen_baseline", {})
    return dict(verdict=data.get("verdict"),
                reason=data.get("reason") or payload.get("reason") or worker.get("reason"),
                error=data.get("error") or payload.get("error") or worker.get("error"),
                worker_exit=worker.get("worker_exit"),
                completed_stages=list(stages),
                precision_cases={k: len(v) for k, v in stages.get("precision_boundaries", {}).items()},
                configured_range_cases=len(stages.get("configured_ranges", {}).get("cases", [])),
                min_speedup=perf.get("min_speedup"),
                timing=[{k: c[k] for k in ("shape", "group_size", "candidate_cuda_ms", "frozen_triton_ms", "speedup")}
                        for c in perf.get("timing", [])],
                early_exit_output=worker.get("stdout") or worker.get("worker_stdout"),
                log_sha256=sha(log))


def probe(path):
    lines = [line[6:] for line in path.read_text().splitlines() if line.startswith("PROBE=")]
    if len(lines) != 1:
        return dict(complete=False, log_sha256=sha(path))
    data = json.loads(lines[0])
    return dict(complete=True, case_counts={k: len(v) for k, v in data.items()},
                max_int8_delta=max((c["max_delta"] for c in data.get("int8", [])), default=None),
                log_sha256=sha(path))


summary = dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               remote_root=str(root), direct=[], harbor=[])
records = [(p.parent, r) for p in sorted((root / "direct-matrix-v2").glob("*/summary.json")) for r in json.loads(p.read_text())]
for partition, record in records:
    d = partition / record["case"]
    item = dict(record)
    item["build_passed"] = (d / "verifier/build-stage.txt").is_file()
    if (d / "verifier/verification.log").is_file():
        item["grading"] = grading(d / "verifier/verification.log")
    if (d / "independent-probe.log").is_file():
        item["independent_probe"] = probe(d / "independent-probe.log")
    summary["direct"].append(item)
for d in sorted((root / "harbor-v2").iterdir()):
    if not d.is_dir() or not (d / "run-record.json").is_file():
        continue
    r = json.loads((d / "run-record.json").read_text())
    item = {k: r.get(k) for k in ("case", "status", "expected_reward", "image_id_observed", "gpu_uuids", "harbor_exit", "observed_trials", "error")}
    item["run_record_sha256"] = sha(d / "run-record.json")
    item["input_artifacts"] = r.get("executable_files")
    logs = list(d.glob("jobs/*/*/verifier/verification.log"))
    if logs:
        item["grading"] = grading(logs[0])
        item["build_passed"] = (logs[0].parent / "build-stage.txt").is_file()
    results = list(d.glob("jobs/*/result.json"))
    if results:
        item["job_result"] = json.loads(results[0].read_text())
    trials = list(d.glob("jobs/*/*/result.json"))
    if trials:
        raw = json.loads(trials[0].read_text())
        item["trial_input_checksum"] = raw.get("task_checksum")
    if (d / "native/manifest.json").is_file():
        item["native"] = json.loads((d / "native/manifest.json").read_text())
    if (d / "curator-native-timing-control.txt").is_file():
        item["native_exit_proof"] = (d / "curator-native-timing-control.txt").read_text()
    if (d / "compiler-cache-seed.json").is_file():
        cache = json.loads((d / "compiler-cache-seed.json").read_text())
        item["compiler_cache"] = {k: cache[k] for k in ("phase", "timestamp", "result", "native_library_injected", "build_directory_injected")}
        item["compiler_cache"]["record_sha256"] = sha(d / "compiler-cache-seed.json")
    summary["harbor"].append(item)
task = root / "repo/tasks/vllm-int8-per-token-group-quantization"
summary["task_snapshot_hashes"] = {str(p.relative_to(task)): sha(p) for p in task.rglob("*") if p.is_file()}
summary["tooling"] = {str(p.relative_to(root)): sha(p) for p in root.glob("*.py")}
summary["tooling"]["external_run_case.py"] = sha(Path("/data/yinchen/task-hardening-20260908/run_case.py"))
summary["tooling"]["external_local_nvidia_docker.py"] = sha(Path("/data/yinchen/harbor-local-gpu-v022/local_nvidia_docker.py"))
summary["tooling"]["external_docker_compose"] = sha(Path("/data/yinchen/vllm-mm-cache-case/controller-tools/docker-compose"))
(root / "result-summary.json").write_text(json.dumps(summary, indent=2) + "\n")

paths = [p for name in ("direct-matrix-v2", "harbor-v2", "repo") for p in (root / name).rglob("*")
         if p.is_file() and "prepared" not in p.parts and p.suffix != ".so" and "__pycache__" not in p.parts]
paths += [p for p in root.iterdir() if p.is_file() and p.suffix in (".log", ".json", ".jsonl", ".py")
          and p.name != "raw-runs-manifest.json"]
archive = root / "raw-runs.tar.gz"
with tarfile.open(archive, "w:gz") as tar:
    for p in sorted(set(paths)):
        tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
(root / "raw-runs-manifest.json").write_text(json.dumps(dict(sha256=sha(archive), size_bytes=archive.stat().st_size,
    exclusions=["native shared libraries retained on remote host", "duplicate prepared task copies", "compiler cache payloads"],
    files={str(p.relative_to(root)): sha(p) for p in sorted(set(paths))}), indent=2) + "\n")
print(json.dumps({"direct": len(summary["direct"]), "harbor": len(summary["harbor"]), "raw_bytes": archive.stat().st_size}))
