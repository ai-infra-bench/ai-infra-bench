"""External Harbor driver; captures actual native and early-exit evidence."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("--case", required=True)
p.add_argument("--gpu", required=True)
p.add_argument("--output", type=Path, required=True)
args = p.parse_args()
root = Path(__file__).parent
task = root / "repo/tasks/vllm-int8-per-token-group-quantization"
args.output.parent.mkdir(parents=True, exist_ok=True)
env = dict(os.environ)
env["PATH"] = "/data/yinchen/task-hardening-20260908/runtime-tools/bin:" + env["PATH"]
env["DOCKER_CONFIG"] = str(root / "docker-config")
env["PYTHONDONTWRITEBYTECODE"] = "1"
cmd = ["python3", "/data/yinchen/task-hardening-20260908/run_case.py",
       "--task", str(task), "--case", args.case, "--gpu-uuid", args.gpu,
       "--output", str(args.output),
       "--harbor", "/data/yinchen/task-hardening-20260908/runtime-tools/bin/harbor"]
captured = marker = False
with (args.output.parent / (args.output.name + ".driver.log")).open("w") as log:
    proc = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
    while proc.poll() is None:
        trials = list(args.output.glob("jobs/*/*/trial.log"))
        if trials:
            container = trials[0].parent.name.lower() + "__env-main-1"
            if not captured:
                ready = subprocess.run(["docker", "exec", container, "test", "-f", "/logs/verifier/build-stage.txt"],
                                       capture_output=True, env=env)
                if ready.returncode == 0:
                    native = args.output / "native"
                    native.mkdir(exist_ok=True)
                    result = subprocess.run(["docker", "cp", container + ":/workspace/repo/vllm/_C.abi3.so", str(native / "_C.abi3.so")],
                                            env=env, capture_output=True)
                    if result.returncode == 0:
                        sha = hashlib.sha256((native / "_C.abi3.so").read_bytes()).hexdigest()
                        inspected = json.loads(subprocess.check_output(["docker", "inspect", container], env=env))[0]
                        fields = {k: inspected["HostConfig"].get(k) for k in ("NetworkMode", "DeviceRequests", "NanoCpus", "Memory")}
                        (native / "manifest.json").write_text(json.dumps(dict(case=args.case, sha256=sha, image=inspected["Image"], runtime=fields), indent=2) + "\n")
                        captured = True
            if args.case == "early-native-timing-exit" and not marker:
                proof = subprocess.run(["docker", "exec", container, "cat", "/tmp/int8-native-timing-control.txt"],
                                       capture_output=True, text=True, env=env)
                if proof.returncode == 0 and "CONTROL_REACHED:early-native-timing-exit" in proof.stdout:
                    (args.output / "curator-native-timing-control.txt").write_text(proof.stdout)
                    marker = True
        time.sleep(0.25 if captured and args.case == "early-native-timing-exit" else 1)
assert proc.returncode == 0, (args.case, proc.returncode)
record = json.loads((args.output / "run-record.json").read_text())
assert record["status"] == "completed_result_checked", record
assert captured, "Native build evidence was not captured"
if args.case == "early-native-timing-exit":
    assert marker, "Native timing exit boundary was not observed"
print(json.dumps(dict(case=args.case, status=record["status"], trials=record["observed_trials"])), flush=True)
