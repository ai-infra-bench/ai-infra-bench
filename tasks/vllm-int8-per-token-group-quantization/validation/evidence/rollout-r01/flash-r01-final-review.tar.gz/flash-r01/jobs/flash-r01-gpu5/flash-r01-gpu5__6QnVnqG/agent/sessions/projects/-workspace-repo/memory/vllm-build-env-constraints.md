---
name: vllm-build-env-constraints
description: "How to build vLLM's _C extension in this container without OOM, and where deps live"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8e7193af-dbc1-4ce5-9bff-c8976bfbe08a
  modified: 2026-09-17T19:15:32.802Z
---

Container has a 32 GiB cgroup memory limit (`/sys/fs/cgroup/memory.max`), even though
`free` reports ~1 TB host RAM. `MAX_JOBS>8` during `pip install --no-build-isolation
--no-deps -e .` gets nvcc processes OOM-killed ("Killed" in build output).

Dependencies are pre-staged and pointed at by env: `VLLM_CUTLASS_SRC_DIR=/opt/vllm-deps/cutlass`,
`VLLM_FLASH_ATTN_SRC_DIR=/opt/vllm-deps/flash-attn`, `FLASH_MLA_SRC_DIR=/opt/vllm-deps/flashmla`,
`TORCH_CUDA_ARCH_LIST=8.0`. Do not unset them or the build tries to fetch from GitHub.

Faster iteration: pip uses a fresh temp build dir (`/tmp/tmp*.build-temp`) per invocation, so a
full `pip install` recompiles everything (~2+ h). To rebuild just the `_C` target after editing
`csrc/`, reuse the existing configured build dir:
`cmake --build /tmp/tmp<...>.build-temp --target _C -j 8`, then copy the produced
`_C.abi3.so` over `vllm/_C.abi3.so` (that is what setup.py does for the editable install).
Only ~26 ninja edges remain for `_C` and an incremental rebuild after a source edit is ~2 min.

**Why:** the OOM limit and the temp-dir churn are invisible from `free`/`nproc` and silently
turn a 2-minute incremental rebuild into a multi-hour full rebuild.
**How to apply:** keep MAX_JOBS<=8; build `_C` directly in the persistent temp dir when iterating.
