---
name: vllm-build-env-a100
description: "How to build vLLM's _C extension in this workspace (A100, 32GB cgroup) without OOM"
metadata: 
  node_type: memory
  type: project
  originSessionId: 53945887-0d68-4439-b6b1-a041ae492262
  modified: 2026-09-17T21:38:06.534Z
---

Workspace `/workspace/repo` (vLLM source, editable install, A100-SXM4-40GB, TORCH_CUDA_ARCH_LIST=8.0).

The container has a **32 GB cgroup memory limit** despite 1 TB of host RAM, so the default
`MAX_JOBS` (256 CPUs) OOM-kills the big Marlin/MoE nvcc jobs. Use `MAX_JOBS=8` (→ `-j=4`) for the
standard `pip install --no-build-isolation --no-deps -e .`; that full build takes ~2 h because
`vllm-flash-attn` alone is 237 of the 308 objects.

**How to apply:** for fast iteration on `csrc/`, configure cmake once in a persistent dir
(`cmake /workspace/repo -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DVLLM_TARGET_DEVICE=cuda
-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc -DFETCHCONTENT_BASE_DIR=/workspace/repo/.deps -G Ninja ...`
— mirror the args in `setup.py:cmake_build_ext.configure`), then
`cmake --build . --target _C -j 4` and `cmake --install . --prefix /workspace/repo --component _C`.
The `_C` target is only 53 objects (~25 min cold, seconds when warm). ccache is enabled but starts
empty. Also: Triton in this env cannot compile fp8e4nv kernels for sm_80, so the fp8 Triton
reference paths in `tests/kernels/quantization/test_per_token_group_quant.py` and
`test_block_int8.py::test_w8a8_block_int8_matmul` fail for pre-existing, unrelated reasons.
