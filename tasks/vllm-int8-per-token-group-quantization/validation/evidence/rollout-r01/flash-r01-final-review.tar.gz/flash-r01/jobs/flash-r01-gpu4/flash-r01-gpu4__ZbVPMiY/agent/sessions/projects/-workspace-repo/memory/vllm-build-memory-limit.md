---
name: vllm-build-memory-limit
description: "The container caps memory at 32 GB, so vLLM's CUDA build must use the default MAX_JOBS (8) or it gets OOM-killed."
metadata: 
  node_type: memory
  type: project
  originSessionId: 94d83fc9-122a-4025-b7c6-9f5f31a77c64
  modified: 2026-09-17T21:54:29.134Z
---

The dev container for this vLLM checkout has a cgroup memory limit of 32 GB
(`/sys/fs/cgroup/memory.max` = 34359738368) even though `free -g` reports ~1 TB
of host RAM. Raising the build parallelism (`MAX_JOBS=48`, i.e. 24 concurrent
nvcc jobs) makes nvcc get SIGKILLed ("Killed") while compiling the
`marlin_moe_wna16` / flash-attn sources.

**Why:** `free` reports host memory, not the container limit, so the usual
"lots of RAM, crank MAX_JOBS" heuristic silently blows up.

**How to apply:** Run `pip install --no-build-isolation --no-deps -e .` with the
environment default `MAX_JOBS=8` (4 parallel jobs, ~8 GB peak) and leave it be —
a full build takes roughly 1.5 h. To rebuild only `_C` (much faster, ~30 min at
`-j 6`) configure CMake yourself with the same flags setup.py uses, `ninja _C`,
then `cmake --install . --prefix <repo> --component _C`. Sources for cutlass /
flash-attn / flashmla come from `/opt/vllm-deps` via `VLLM_CUTLASS_SRC_DIR`,
`VLLM_FLASH_ATTN_SRC_DIR`, `FLASH_MLA_SRC_DIR`; there is no network access.
