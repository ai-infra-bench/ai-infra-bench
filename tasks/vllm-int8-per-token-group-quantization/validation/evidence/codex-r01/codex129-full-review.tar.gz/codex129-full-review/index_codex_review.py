import json,pathlib,hashlib,collections,ast
def render(x):
 if isinstance(x,str):
  try:return render(json.loads(x))
  except Exception:
   try:return render(ast.literal_eval(x)) if x.startswith("[{\'type\'") else x
   except Exception:return x
 if isinstance(x,list):return "\n".join(render(i) for i in x)
 if isinstance(x,dict):
  if "text" in x:return render(x["text"])
  if "output" in x:return json.dumps({k:v for k,v in x.items() if k!="output"})+"\n"+render(x["output"])
 return json.dumps(x,ensure_ascii=False)
root=pathlib.Path('work/rollout70/codex-gpt6-medium-r01/jobs');out=pathlib.Path('work/rollout70/codex-visible-review');out.mkdir(exist_ok=True)
seen={};index=[]
for g in range(4):
 p=next((root/f'codex-gpt6-medium-r01-gpu{g}').glob('*/agent/sessions/**/*.jsonl'));blocks=[];counts=collections.Counter();ref=[]
 for n,l in enumerate(p.read_text().splitlines(),1):
  d=json.loads(l)
  if d['type']!='response_item': continue
  v=d['payload'];typ=v['type'];counts[typ]+=1
  if typ=='reasoning':
   assert not v.get('summary');continue
  v={k:x for k,x in v.items() if k not in ('encrypted_content','internal_chat_message_metadata_passthrough','id','status')}
  s=json.dumps(v,ensure_ascii=False,indent=1)
  # Render text literally so commands and returned outputs are readable.
  if typ=='message':s=f"{v.get('role')}: "+'\n'.join(x.get('text','') for x in v.get('content',[]))
  elif typ=='custom_tool_call':s=v.get('name','')+'\n'+v.get('input','')
  elif typ.endswith('_output'):s=render(v.get('output',''))
  elif typ=='function_call':s=v.get('name','')+'\n'+v.get('arguments','')
  h=hashlib.sha256(s.encode()).hexdigest();label=f'gpu{g}:L{n} {typ} {v.get("call_id","")}'
  if h in seen:s='EXACT DUPLICATE: '+seen[h];ref.append(dict(line=n,original=seen[h],sha256=h))
  else:seen[h]=label
  blocks.append(f'\n===== {label} =====\n{s}\n')
 chunks=[];s=''
 for b in blocks:
  if len(s)+len(b)>34000 and s:chunks.append(s);s=''
  s+=b
 if s:chunks.append(s)
 for i,s in enumerate(chunks):(out/f'gpu{g}-{i:02}.txt').write_text(s)
 index.append(dict(gpu=g,source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),counts=counts,empty_reasoning_summaries=counts['reasoning'],chunks=len(chunks),exact_duplicates=ref))
(out/'index.json').write_text(json.dumps(index,indent=2));print([(x['gpu'],x['chunks'])for x in index])
