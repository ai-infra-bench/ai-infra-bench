import concurrent.futures,json,os,pathlib,subprocess,time
R=pathlib.Path('/data/codex-pr70-rollouts-20260918'); out=R/'codex129-full-review';out.mkdir(exist_ok=False)
os.environ['DOCKER_HOST']='unix:///data/docker-bench/docker.sock'
image='sha256:5dc453932b016a3b73fb9316cce43f251275197b7a6295bc970e3de7a2718593'
python='/tmp/codex-pr63-hardening-20260918/harbor-venv/bin/python'
def run(g):
 name=f'codex-pr70-codex129-replay-gpu{g}'
 subprocess.run(['docker','run','-d','--name',name,'--network','none','--gpus',f'device={g}','--cpus','8','--memory','32g','--entrypoint','bash',image,'-lc','sleep infinity'],check=True)
 snapshot=next((R/'codex-gpt6-medium-r01/jobs'/f'codex-gpt6-medium-r01-gpu{g}').glob('*/agent/final-state'))
 target=out/f'gpu{g}'
 with (out/f'gpu{g}-launcher.log').open('w') as log:
  p=subprocess.Popen([python,str(R/'next/tools/curator/pr70-rollout/replay_saved.py'),'--container',name,'--snapshot',str(snapshot),'--base-manifest',str(R/'base-file-manifest.json'),'--task',str(R/'next/tasks/vllm-int8-per-token-group-quantization'),'--output',str(target)],stdout=log,stderr=subprocess.STDOUT)
  seeded=False
  while p.poll() is None:
   if not seeded:
    ready=subprocess.run(['docker','exec',name,'bash','-lc','test -s /logs/verifier/native-build.stdout.log && test -f /logs/verifier/frozen-reference-stage.txt'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
    if ready:
     subprocess.run([python,str(R/'seed-functional-cache.py'),name,str(out/f'gpu{g}-cache.json')],check=True,stdout=log,stderr=subprocess.STDOUT);seeded=True
   time.sleep(5)
  rc=p.returncode
  audit=subprocess.run([python,str(R/'next/tools/curator/pr70-rollout/audit_generated.py'),'--inventory',str(target/'inventory.json'),'--image',image,'--output',str(out/f'gpu{g}-generated')],stdout=log,stderr=subprocess.STDOUT)
  (out/f'gpu{g}-status.json').write_text(json.dumps(dict(replay_exit=rc,audit_exit=audit.returncode,container=name)))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,range(4)))
