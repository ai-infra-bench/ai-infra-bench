from pathlib import Path
import json,hashlib,tarfile,datetime
R=Path(__file__).parent;targets=json.loads((R/'targets.json').read_text());reports={};changed={};checks={}
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for key in ['pr8','pr17']:
 T=Path(targets[key]['task']);e=json.loads((T/'validation/e2e-evidence.json').read_text());c=json.loads((R/(key+'-final-checks.json')).read_text())
 assert e['status']=='validated' and not any(c.values()),(key,e['status'],c)
 assert all(digest(T/n)==h for n,h in e['freeze']['files'].items())
 archive=T/e['portable_raw_evidence']['archive'];assert digest(archive)==e['portable_raw_evidence']['sha256']
 count=0
 with tarfile.open(archive,'r:gz') as tar:
  for run in e['harbor']['runs']:
   for p,h in run['raw_artifacts'].items():
    name=str(Path(p).relative_to(R));f=tar.extractfile(name);assert f is not None
    assert hashlib.sha256(f.read()).hexdigest()==h,(key,name);count+=1
  for run in e['independent_challenges']['runs']:
   name=str((Path(run['record_path']).parent/'challenge.log').relative_to(R));assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==run['log_sha256'];count+=1
 checks[key]={'archive_sha256':digest(archive),'archived_raw_files_verified':count,'final_checks':c}
 reports[key]=e
 before=R/'before'/key
 old={str(p.relative_to(before)):digest(p) for p in before.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 new={str(p.relative_to(T)):digest(p) for p in T.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 changed[key]={'task':str(T),'modified':{n:{'before':old[n],'after':h} for n,h in new.items() if n in old and old[n]!=h},'added':{n:h for n,h in new.items() if n not in old},'removed':[n for n in old if n not in new]}
(R/'archive-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
(R/'changed-files.json').write_text(json.dumps(changed,indent=2)+'\n')
status={'updated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publication':'local only; no commit, push or PR update','model_rollout':'none; historical scores unchanged'}
for key,e in reports.items():status[key]={'completed':True,'version':e['task_version'],'harbor_runs':e['harbor']['run_count'],'challenges':e['independent_challenges']['run_count'],'final_oracle_reward':e['harbor']['final_oracle']['actual_reward'],'checks':checks[key]}
(R/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
a,b=reports['pr8'],reports['pr17']
text=f'''# PR8 / PR17 修复与验证结果

两项任务已修改，并完成当前版本的本地 task review、完整 Harbor 控制验证和独立 challenge。两份 instruction.md 均为 3 个不硬换行的自然段。未提交、推送或更新 PR；本轮没有新跑 Opus，历史成绩不变。

| Task | 当前版本 | 完整 Harbor | 独立 challenge | 最终 Oracle | 严格审计 / CI / 含未跟踪文件的空白检查 |
| --- | --- | --- | --- | --- | --- |
| PR8 | {a['task_version']} | {a['harbor']['run_count']} | {a['independent_challenges']['run_count']} | 1 | 全部通过 |
| PR17 | {b['task_version']} | {b['harbor']['run_count']} | {b['independent_challenges']['run_count']} | 1 | 全部通过 |

所有计入的运行均符合各自预期，Harbor 异常数为 0。先前环境启动失败、GPU 锁预检冲突及被替换版本的运行另行保存，不冒充有效评分结果。严格审计均为 0 错误、0 警告。两份可移交证据包已重新打开，逐文件复核原始结果和 challenge 日志哈希；详情见 archive-verification.json。

PR8：评分父进程根据新生成的输入独立计算预期值，并检查真实调度、编码写入、缓存和分段读取产生的原始观测；已复现的固定完成报告和旧成功观测重放均得 0。Oracle 和 dense-cache 替代解现在允许不需要 embedding 的窗口在零预算或低缓存容量下继续，同时保留已有 speculative lookahead 语义。新增低资源、lookahead 遗漏负例被正确拒绝，合法缓存布局和 embedding-count 实现仍得 1。补丁空白清理前后应用的源码哈希相同，见 pr8-patch-equivalence.json。此次行为验证不宣称防御任意原生进程操纵。

PR17：原生替代解在 scale 倒数溢出时改用除法，避免合法 FP32 小数值输入产生巨大 INT8 误差。父进程将原生和公开路径的 6 组小数值输出与单独运行的冻结 Triton 结果比较，scale 容差采用 FP32 次正规数 ULP 下限。进一步补查并修正了 Oracle 的空输入非法 CUDA launch，增加 3 组空张量的形状、dtype、device 及后续 CUDA 运算检查。原倒数溢出实现和原空输入 Oracle 保留为独立负例；独立 challenge 使用不同输入验证对应缺陷。原性能工作负载、计时函数和每组 1.5× 门槛均未改变，见 pr17-performance-invariance.json。

验证入口、Docker 配方及构建/计时脚本未变，见 execution-invariance.json。具体文件变更和哈希见 changed-files.json。当前 task review 与历史 rollout 交付物检查分开：历史最终源码/原生文件归档不完整的问题，不能通过本轮控制验证宣布解决。

任务路径：

- PR8: {targets['pr8']['task']}
- PR17: {targets['pr17']['task']}

逐任务 review 结论见 pr8-RESULT.md、pr17-RESULT.md；各任务 validation/e2e-evidence.json 保存最终文件哈希、镜像身份、job/trial ID、真实奖励、原始结果路径和证据包 SHA256。
'''
(R/'RESULT.md').write_text(text)
print('BOTH TASKS FINALIZED',json.dumps(status,ensure_ascii=False))
