from pathlib import Path
import json,subprocess,sys,time
R=Path(__file__).parent
while True:
 check=R/'pr17-final-checks.json'
 if check.exists():
  try:checks=json.loads(check.read_text())
  except json.JSONDecodeError:time.sleep(1);continue
  assert not any(checks.values()),checks
  break
 time.sleep(5)
subprocess.run([sys.executable,str(R/'finish_report.py')],check=True)
