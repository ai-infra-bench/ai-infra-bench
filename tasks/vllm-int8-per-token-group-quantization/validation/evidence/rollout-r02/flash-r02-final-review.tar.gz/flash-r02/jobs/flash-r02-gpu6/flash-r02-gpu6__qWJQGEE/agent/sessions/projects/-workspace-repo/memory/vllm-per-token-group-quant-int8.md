---
name: vllm-per-token-group-quant-int8
description: "Native CUDA per_token_group_quant_int8 op added to vLLM _C, reusing the generic 8-bit kernel"
metadata: 
  node_type: memory
  type: project
  originSessionId: bd2e2575-b684-4936-ae5a-902f21d9109c
  modified: 2026-09-17T23:12:01.876Z
---

`torch.ops._C.per_token_group_quant_int8(input, output_q, output_s, group_size, eps,
int8_min, int8_max)` is implemented in
`csrc/quantization/fp8/per_token_group_quant.cu` by dispatching the existing
`per_token_group_quant_8bit_kernel` with `DST_DTYPE=int8_t`. The public Python
`per_token_group_quant_int8` in `vllm/model_executor/layers/quantization/utils/int8_utils.py`
routes to it when `current_platform.is_cuda()` and dtype is int8; ROCm/other
platforms keep the Triton `_per_token_group_quant_int8` fallback.

**Why:** the Triton kernel was the bottleneck for INT8 per-token-group quant on A100.
**How to apply:** the int8 path uses the kernel's `SCALE_RECIP=true` template flag so
the scale is `absmax * (1.0f/int8_max)` — the same reciprocal-multiply the Triton/ATen
reference uses — making scales bit-identical. Quantized values still differ from Triton
by at most 1 step, only for group elements that saturate at the int8 bound (Triton's
division rounds them down, native clamps them to the true bound).
