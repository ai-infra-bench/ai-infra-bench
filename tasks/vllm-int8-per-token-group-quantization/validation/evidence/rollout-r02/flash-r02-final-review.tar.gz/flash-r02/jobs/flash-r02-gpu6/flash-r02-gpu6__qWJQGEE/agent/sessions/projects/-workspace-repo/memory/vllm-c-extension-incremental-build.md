---
name: vllm-c-extension-incremental-build
description: "How to incrementally rebuild vLLM's _C CUDA extension in this container without rebuilding flash-attn"
metadata: 
  node_type: memory
  type: project
  originSessionId: bd2e2575-b684-4936-ae5a-902f21d9109c
  modified: 2026-09-17T23:11:58.721Z
---

The container ships a prebuilt `vllm/_C.abi3.so` but no CMake build tree, so the
first build is a full ~25 min compile. To make later rebuilds incremental, keep a
persistent build dir at `/workspace/repo/build` configured once with:

```
TORCH_CUDA_ARCH_LIST=8.0 cmake . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DVLLM_TARGET_DEVICE=cuda -DCMAKE_C_COMPILER_LAUNCHER=ccache \
  -DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_CUDA_COMPILER_LAUNCHER=ccache \
  -DVLLM_PYTHON_EXECUTABLE=$(which python3) -DVLLM_PYTHON_PATH="$(python3 -c 'import sys;print(":".join(sys.path))')" \
  -DFETCHCONTENT_BASE_DIR=/workspace/repo/.deps -DNVCC_THREADS=2 \
  -DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc \
  -DCMAKE_JOB_POOL_COMPILE:STRING=compile -DCMAKE_JOB_POOLS:STRING=compile=4
```

Then `TORCH_CUDA_ARCH_LIST=8.0 cmake --build build -j 4 --target _C` and copy
`build/_C.abi3.so` over `vllm/_C.abi3.so`. Building only the `_C` target avoids
recompiling flash-attn/flashmla; sm80-only arch cuts the target count to ~53.
`vllm/` is an editable install pointing at the repo, so no reinstall is needed.

See [[vllm-per-token-group-quant-int8]].
