---
name: vllm-c-build-workflow
description: "How to rebuild vLLM's _C extension in /workspace/repo without a 1h full build"
metadata: 
  node_type: memory
  type: project
  originSessionId: 73272fae-8591-4d00-a9b3-e44031875383
  modified: 2026-09-17T22:49:48.914Z
---

In the `/workspace/repo` vLLM container there is no pre-existing CMake build tree, so
rebuilding `_C` from scratch is required after touching `csrc/`. A plain
`python3 setup.py build_ext --inplace` also builds `_moe_C`, flash-attn, flashmla and
cumem, which is wasted time.

**Why:** only the `_C` target is usually needed, and the container has no network access
so anything relying on a fresh git clone would fail.

**How to apply:** configure once and build just the one target:
`cmake /workspace/repo -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DVLLM_TARGET_DEVICE=cuda
-DVLLM_PYTHON_EXECUTABLE=/usr/bin/python3 -DVLLM_PYTHON_PATH=... -DFETCHCONTENT_BASE_DIR=/workspace/repo/.deps
-DNVCC_THREADS=2 -DCMAKE_JOB_POOL_COMPILE:STRING=compile -DCMAKE_JOB_POOLS:STRING=compile=4
-DCMAKE_CUDA_COMPILER=/usr/local/cuda/bin/nvcc` in `build/temp.linux-x86_64-cpython-312`, then
`cmake --build . --target _C -j 4` and `cmake --install . --prefix /workspace/repo --component _C`.
The env already provides `VLLM_CUTLASS_SRC_DIR=/opt/vllm-deps/cutlass`,
`TORCH_CUDA_ARCH_LIST=8.0`, `MAX_JOBS=8`; the container is limited to 8 CPUs / 32 GiB.
A full `_C` build takes ~30 min at `-j 4` with `NVCC_THREADS=2`.
