import _hashlib,hmac,importlib.util,json,secrets,socket,struct,gc,tracemalloc
spec=importlib.util.spec_from_file_location('_checkpoint','/tmp/_checkpoint.so')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
a,b=socket.socketpair(socket.AF_UNIX,socket.SOCK_DGRAM);key=secrets.token_bytes(32)
m.configure(key,b.fileno(),_hashlib.hmac_digest)
def sample():
 nonce=secrets.token_bytes(16);m.snapshot(nonce);p=a.recv(256)
 assert len(p)==56 and p[32:48]==nonce and hmac.compare_digest(p[:32],hmac.digest(key,p[32:],'sha256'))
 return struct.unpack('>Q',p[48:])[0]
for _ in range(8): sample()
baseline=sample();data=bytearray(4*1024*1024);allocated=sample()
tracemalloc.get_traced_memory=lambda:(0,0)
independent=sample();del data;reclaimed=sample()
assert 4*1024*1024 <= allocated-baseline < 4*1024*1024+65536
assert abs(independent-allocated)<65536
assert abs(reclaimed-baseline)<65536
try:m.configure(key,b.fileno(),_hashlib.hmac_digest)
except RuntimeError:sealed=True
else:sealed=False
assert sealed
print(json.dumps({'allocated_delta':allocated-baseline,'after_fake_tracemalloc_delta':independent-baseline,'after_release_delta':reclaimed-baseline,'configuration_sealed':sealed}))
