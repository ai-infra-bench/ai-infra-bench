from pathlib import Path
import subprocess,shutil,json
ROOT=Path('/data/codex-pr61-hardening-20260919')
source=ROOT/'task-final'
for case in ('oracle','event-ready-heap-alternative'):
 target=ROOT/'challenge-tasks'/case
 shutil.copytree(source,target)
 original=(target/'tests/verify_blocked_waiting.py').read_text()
 challenge='''
# Review-only new workload: reused identities and varied payloads across resets.
GROUPS = ('independent-reused-identities',)
def run_suite(peer, emit):
    for mode in (True, False, True):
        peer.call('reset', capacity=2, budget=16, connector=mode)
        for generation in range(3):
            identities = ['reused / a', 'request-λ', 'tail-' + str(generation)]
            peer.call('add', items=[{'id': identity, 'prompt': 17 + index * 7,
                                     'remote': mode and index == 0, 'cached': 16}
                                    for index, identity in enumerate(identities)])
            got = {key: [] for key in identities}
            terminals = set()
            for step in range(40):
                tokens = {key: 2000 + index * 97 + len(got[key]) for index, key in enumerate(identities)}
                output = peer.call('tick', ready=[identities[0]] if mode and step == 3 else [], tokens=tokens)
                for key, values, terminal in output['outputs']:
                    require(key in got and key not in terminals, 'identity reused before its prior output ended')
                    got[key].extend(values)
                    if terminal: terminals.add(key)
                if len(terminals) == 3: break
            expected = {key: [2000 + index * 97 + k for k in range(3)] for index, key in enumerate(identities)}
            require(got == expected and terminals == set(identities), f'reuse lost tokens: {got}')
            empty(peer)
    emit(GROUPS[0])
'''
 (target/'tests/verify_blocked_waiting.py').write_text(original+challenge)
 if case!='oracle':shutil.copyfile(target/'validation'/f'{case}.patch',target/'solution/oracle.patch')
 s=(ROOT/'run_final.py').read_text().replace("TASK = Path('/data/codex-pr61-hardening-20260919/task-final')",f"TASK = Path('{target}')").replace("RUNS = Path('/data/codex-pr61-hardening-20260919/final-runs')",f"RUNS = Path('{ROOT}/challenge-runs/{case}')").replace("container = 'codex-pr61-final-' + name",f"container = 'codex-pr61-challenge-{case}-' + name")
 script=ROOT/f'run-challenge-{case}.py';script.write_text(s)
 subprocess.run(['python3',str(script),'oracle'],check=True)
