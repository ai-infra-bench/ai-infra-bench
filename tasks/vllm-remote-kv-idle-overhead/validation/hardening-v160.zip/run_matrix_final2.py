import concurrent.futures,json
from pathlib import Path
import run_final2 as runner
manifest=json.loads((runner.TASK/'validation/ci-cases.json').read_text())
expected={'base':0,'oracle':1}
for item in manifest['cases']: expected[Path(item['patch']).stem]=item['expected_reward']
first=['oracle','event-ready-heap-alternative','bounded-history-cache','batched-history-reclamation','reordered-token-map','undrained-kv-block-ids']
cases=first+[name for name in expected if name not in first]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 futures={pool.submit(runner.run_case,name,'codex-pr61-review:base-20260919'):name for name in cases}
 for future in concurrent.futures.as_completed(futures):
  name=futures[future]
  try:future.result()
  except BaseException as exc: print(json.dumps({'case':name,'driver_error':repr(exc)}),flush=True)
  p=runner.RUNS/name/'result.json'
  if p.exists():
   result=json.loads(p.read_text());value=result.get('verdict') or {}
   print(json.dumps({'checked':name,'expected':expected[name],'observed':value.get('reward'),'matches':value.get('reward')==expected[name]}),flush=True)
