# PR61 / DeepSeek r3-r03 终态轨迹审查

结论：原始 Harbor reward=1，18/18 必需检查完成；最终实现审查及另外 12 个普通生命周期对照场景未发现可确认的评分误放行或功能缺陷。结论只覆盖下述证据，不意味着证明所有 vLLM 使用方式都正确。没有为了提高通过率修改候选、题面、verifier 或原始评分。

## 身份与产物

- Trial：`rollouts/pr61-deepseek-h1-r03/pr61-deepseek-h1-r03__j2vPuG5`（路径均相对本轮 campaign）。
- 冻结任务：`pr61-frozen`，v1.5.0；Base `d88f28da05b12bc7d63ebe3dcedf445ecb274343`。最终源码在 trial 的 `artifacts/app`。
- 请求模型 `openai/deepseek-v4-flash`，网关返回 `deepseek-flash`；未独立确认服务端精确模型 revision。
- 主轨迹 SHA256：`18268f9411094fde0ec245a71051683512d54a8511ce55d56d28bb6ada5501e1`。
- 367 条主 steps，其中 346 条 source=agent；708 个顶层 tool calls。不能把全部 steps 或工具数量混称为模型轮数。
- Trial 总耗时 7116.146 秒；Agent 7014.587 秒；Verifier 79.978 秒。输入 12,655,183 tokens，其中 cached 12,006,272 是输入子集；输出 1,122,289；合计 13,777,472。报告成本字段为 $0.168087808，仅为网关报告值，非账单确认。

## 实际阅读覆盖与限制

主轨迹 step 1–367 的 messages、tool inputs、已交付 observations、迭代及完成动作全部审阅。1–156 reasoning 逐字覆盖，157 reasoning 只读前 20,000/79,754 字符；后续 reasoning 重点审阅而非全文逐字覆盖。主动作全覆盖不等于全部 thinking 逐字覆盖。源观察中原生 `output limited to 10000 bytes` 缺失不能补称已读；审核工具自身截断已通过小块补读修复。

30 份压缩 sidecar（10 组 summary/questions/answers）的 action 字段也全部覆盖：使用已审查的 `review-tools/render_aux.py --through 367`，对与主轨迹或更早 payload 精确相同的字符串/连续行复用，对 43 个新增 payload 按 1–43 顺序阅读。payload 10 首次输出裁剪后单独重读。aux reasoning 未逐字阅读。问答中要求隐藏 grader 路径，是模型自己向压缩上下文提问，不是新增人类要求；已读 action 中没有实际获得隐藏答案或读取隐藏 verifier。

5 份 live-prefix 快照与终态主轨迹逐 step 结构比较均无差异。完整 tracked diff、最终 `request_queue.py` 1–368 与 `scheduler.py` 1–2253 EOF 均逐行审阅；其他交付目录依据完整清单检查，并未逐字读取整个无关仓库。没有 untracked 文件，ignored 清单为缓存及镜像构建产物；未额外对每个二进制做干净镜像字节对照，故不声称 ignored 全部独立鉴定。`terminus_2.pane` 未作为额外独立全文阅读源；终端内容的审查口径是 ATIF 已交付 observations。详见 `LIVE-REVIEW.md` 与 `review-bundles/pr61-deepseek-h1-r03` 的全字段索引、roundtrip、产物 inventory。

补充 native 文件校验：审阅者实际对 r03 最终 `/app/vllm/{_C.abi3.so,_C_AVX2.abi3.so,_version.py}` 执行只读 `sha256sum`，分别得到 `8e05941e861ec575d9e1fefa58cd0111aa596b959c756ad83c5f21d49acf2ab5`、`fc91dfdb8cf937d7b2493613e797a7dd0106aa5905e25a6b60bb487313c07fca`、`7fd4d5e9435e7f65df9b880b7c59b0f9ac3277ab9d54d082f71d42acdd90d472`，与 Noether 从冻结 CPU 镜像独立只读重验的三个文件一致（`../frozen-native-hash-check.md`）。本补证仅覆盖三个文件，不扩大为整个运行环境完整性证明。

## 题面合同与交付实现

题面给出异步 remote KV 等待时 idle CPU 随阻塞数量增长的现象及 A/B/C 完成顺序例子，要求维持 FCFS、混合等待原因、统计/取消/后续请求，并公开短请求流 warm-up 后 retained Python memory 的 32MiB 预算；未提供公开复测脚本或内部队列设计。

最终仅改两生产文件（+217/-31）：队列 facade 保存 runnable inner queue、remote blocked 字典和 FCFS 逻辑位置键；Scheduler 以完成 ID 事件恢复请求，不在每个无事件 tick 扫 remote 阻塞人口。普通跳过保留位置，取消与最终出队删除索引，优先级继续用原有排序。公开等待长度/遍历仍含远端阻塞请求，热路径专用 runnable 操作避开 inclusive iteration。

具体定位：`request_queue.py:211` 起新队列；`scheduler.py:166` 构造，`:543` 等待热循环，`:761` 初次远端阻塞，`:781` runnable pop，`:1698` 取消/结束，`:1978` 完成事件处理。完整文件哈希：queue `145ecb2e0b3677a7a5adb7630e29afb7e4616eed8ca0daa4301d0eca5cc90b3a`；scheduler `4a443d2528ec1670ee6cabef6729457aceefdfbad1683378a8808b77f9055140`。

公开 peek/iteration 为 O(N log N)，完成事件的 FCFS 重插可能 O(completions × runnable)，比方法注释的简化说法更昂贵，但它们不在无事件 remote-idle 热路径；当前公开合同未要求完成事件必须 O(1)，不能据此判错或增加绑定内部表示的评分点。

## Agent 确实运行了哪些验证

- 52 首次写队列；71 scheduler 编辑脚本 SyntaxError，72/74/76 更正并通过 compile。77–80 原有排序/取消 3 passed、完整 scheduler 91 passed/1 skipped。
- 112–113 自建真实 Scheduler A/B/C 异步完成流程通过（集合断言不独立证明所有 FCFS 顺序）。116 原仓库 remote-prefill/load-failure 15 passed/2 failed；119 分开 inclusive public peek 与热路径 runnable peek；120 两失败用例通过；121 合并 109 passed/1 skipped。这是真实失败→修复→重测。
- 124/128 真实 Scheduler 短请求正常/取消流程分别 RSS warm-up 后 250/125 cycles，delta 0MiB；这些短 RSS 实验不能代替正式 retained-Python 长周期合同。
- 190 删除初始 async 路径中冗余 pop 后又 block/remove；193 七文件 118 passed/1 skipped。222–223 fake queue idle 检查 10/1000/10000 blocked 时间近似平坦；229–230 fake queue tracemalloc 100k 周期 +682B。这些是自己实现的队列级测试，不等于完整 schedule benchmark。
- 289 修正公开 pop/peek 语义不一致，新增 hot-path pop；294 六文件 117 passed/1 skipped。335 async scheduler 8 passed。358 最后七文件 125 passed/1 skipped。365 最后队列自测通过。
- 全 core 曾 248 passed/23 failed/1 skipped/2 errors，priority-random 曾缺离线 HF 模型，scheduler e2e 两个 setup error，streaming 原仓库测试 8 个 setup failure，ruff 不存在。日志显示错误发生于模型配置/fixture 构造，但 Agent 没有干净 Base differential；不能把所有失败直接确认成无关环境故障。正式 verifier 的真实 streaming 生命周期检查另有通过证据。

执行效率明显不好：131、235、267 已尝试完成，遇到正常确认提示后又自行检查；压缩 summary 多次把已返回的 grep 结果描述为“尚未观察”，触发重复工作。366→367 连续确认才真正结束。没有拿到 hidden reward 后反复重试；这些重复大多是 Agent 自查/上下文压缩，不是 verifier 反馈。这也解释了巨大 token 与较小最终 diff 并存。

## 正式评分与独立补充挑战

原始 `verifier/verifier-details.json`：completed=required=18、failures=[]、worker_exit_status=0、reward=1。正式日志 retained-memory 在 16,384 请求时：普通流增长 495,968 bytes，remote 流增长 470,176 bytes，均远低于公开 33,554,432 bytes 预算；另外非评分的弱引用诊断 16/128/512 完成后保留 Request 对象均为 0。不能将这些有限周期说成无限期内存证明。

Noether 使用已冻结普通 challenge，在独立只读、network=none 容器加载最终完整 `/app`：12/12 场景通过、46.845 秒，完整事件 trace 与干净 Base 对照一致，SHA256 `8653667b0a9566f57502b8bea46b124ea85a78caca2df4a0d94305f1382dd6c1`。probe、fixture、两个改动源码的前后 hash 均一致。证据 `reviews/ordinary-challenge-v1-r03/{r03.json,r03.stdout,r03.stderr}`。这是独立普通行为诊断，不是新 Harbor trial，不改写原始 reward，也不证明所有未覆盖边界。

## 判定

已证实：该终态交付完成真实实现与真实测试迭代，正式 18 项全部完成，补充 12 个已校准生命周期场景通过；本次已审范围没有看到答案获取、评分产物伪造或候选侵入 verifier。未发现需要修改 task/verifier 的可确认误判。无需为了追求 Agent 不通过而新增私有字段/指定方法名断言。

待验证/局限：没有真实分布式 KV 网络传输及完整模型 serving 实测；普通挑战仅覆盖其声明的生命周期，不能穷尽取消与失败的任意组合；宽泛 upstream 测试环境失败未做全部 Base 对照；长期内存仅有有限周期证据。后续 GPT 对比可在同一冻结合同进行，保留当前成功成绩，不因未穷举场景而否定它。
