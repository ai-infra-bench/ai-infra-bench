# PR #61：基于真实轨迹补全 verifier（v1.4.0）

本轮保持选题、开发者题面、Base、Oracle、环境镜像不变，只补充有合同依据的行为检查和诊断记录。**不是为了降低通过率，也不宣布已达到合入标准。** 没有启动新模型、改写原始轨迹或 reward，也没有修改 PR #60 正在执行的快照。

## 依据和版本

- 批准模式：Oracle-based；使用 `ai-infra-bench-rollout-review` 及 differential-cases/reporting，技能修订 `b40002e149e5d2e0896ca2cc3573a84f1f0b4091`。
- 修订前 task：v1.3.0，PR #61 head `f3e676b7178b707f2ad139c20229627786249a43`。
- 修订后：v1.4.0，16 checkpoints（其中最后一个为 suite completion；不是16个独立输入）。
- Base：`d88f28da05b12bc7d63ebe3dcedf445ecb274343`。
- 镜像保持 `sha256:fd59b9b0cbbc1c4d5400d97e1eaeb1cdd4640f71983c9a5581b84449743ac88c`，未改环境或重新构建。
- 来源：`deepseek-pr60-pr61-r2-20260917` 中三次新 DeepSeek 尝试；不要与9月16日同名 r01/r02/r03 混用。
- 原始三次 reward 都是1、13/13，永远保留原值。用新 verifier 重放不是新的模型通过率实验。

## 具体增加什么

| 检查 | 合同与正常入口 | 观察什么 | 不约束什么 |
|---|---|---|---|
| preemption-backlog-local | 题面的 existing FCFS / normal generation / subsequent admission；Base 公开 `reset_prefix_cache(reset_running_requests=True)` 和上游 `test_scheduler_reset_prefix_cache` 可发现该语义 | 一个已输出token的老请求、3或11个后续等待请求；两次真实reset后老请求先恢复；完整token序列、计数、最终完成顺序不变 | 不检查 queue/helper 名称、排序key、数据结构 |
| preemption-backlog-remote | 同上，并先走真实异步remote等待和 `finished_recving` 事件 | 远端来源请求已恢复运行后被抢占，仍遵守上述顺序和输出契约 | 不直接设置内部status，不要求特定事件队列 |
| completion-churn | 题面的 normal generation and completion / admission of subsequent requests | 同一个scheduler连续16/128/512个不同请求；本地和remote各一组；每次正确token、单个terminal、计数清零，空tick不复活旧请求 | 不要求队列立即为空或立即释放所有对象 |

抢占检查不是把 Oracle 输出当唯一规范：原有 FCFS 的老请求先于后来可运行请求；请求先开始生成、随后公开reset强制释放running KV并重新排队，不能让后来者无故超越。使用普通模型输出完成整个生命周期，而非只断言某个新内部容器内容。Base 自带测试覆盖无积压reset，本轮补的是非空backlog及重复reset。

行为决定路径是 Request/add_request → 真实 Scheduler、KV管理和公开reset → SchedulerOutput → 确定性 ModelRunnerOutput → 客户端token与结束通知。仅替代模型算术和传输生产者；不是 HTTP/RDMA/GPU端到端测试。

## 为什么对象保留暂不直接扣分

独立补验发现 r02 的 remote 请求、r03 的 local/remote 请求在完成16/128/512个后仍全部存活，已超过之前12/96的短探针。正确对照及r01在这些输入下为0。但是，“对照为0”并不产生“所有合法解法必须立即为0”的合同。

原题没有针对历史请求状态的缓存容量或GC时限，指定例如“超过8个对象就失败”仍是隐藏阈值。本版因此将弱引用存活量打印为 `RESOURCE_LIFECYCLE_DIAGNOSTIC`，明确 `scored=false`；它提示人工审核，不改变reward。完成、输出或新请求接入真的失败则由行为断言扣分。这里的非扣分遥测不是修复了模型的资源泄漏，也不能证明缓存有界。

未来要把资源保留升级为必过项，应先确立用户可见的长期服务资源契约，再设计对有界缓存、批量回收、延迟GC都公平的负载/预算测试，并补这些正确替代控制。不能因想让r03失败而选择阈值。题面此次完全不变，不向agent泄露内部原因或公开复测脚本。

## 新负对照的来源

`preemption-backlog-regression.patch` 是本轮 r02 (`NDtMrjy`) 完整 tracked final diff，包括模型自己新增的上游测试。它原来通过13/13，却在真实backlog抢占后先运行 `queued-0`。它是开发校准负例，不是独立held-out样本。完整捕获的 `/app`（包括ignored文件）另外只读重放；patch控制不冒充完整文件系统快照。

## 验证与可复现记录

最小独立对照使用 Base、Oracle、event-ready-heap正确替代和三份完整saved `/app`，在同一固定镜像中测试新增场景；候选目录只读，运行前后哈希核验。然后冻结所有可执行输入，经实际 `tests/test.sh` 完整重放候选，并用 Harbor 0.22.0 跑无模型费用的 Base/Oracle/正负控制。完整评分串行执行，避免多个idle比例测试相互干扰。

直接容器诊断/评分使用私人Docker、network=none、runc、2CPU/8GiB。Harbor控制沿用本机已有运行方式 `--cpus ignore --memory ignore`，不声称独占CPU或硬资源限额；它与前述直接容器是分别记录的实验。运行命令和输入manifest保存在各控制目录。

机器结果与精简原始日志保存在 `rollout-hardening-v140-results.json` 和 `rollout-hardening-v140-logs/`。每个结果绑定运行前输入，不将文档更新后的hash冒充执行版本。历史 `repair-calibration-2026-09-17.json` 仍对应v1.3.0；新的结果以本轮文件为准。运行原目录为 curator workspace 的 `runs/deepseek-pr60-pr61-r2-20260917/verifier-hardening-pr61-v140-final/`。

### 已完成结果

8个真实 Harbor 控制均完成、无 Harbor exception，实际与预期一致：

| 控制 | reward | 实际原因/覆盖 |
|---|---:|---|
| Base | 0 | 原始idle线性增长，比例13.27；新增保留行为用例单独均通过 |
| Oracle | 1 | 完整16/16 |
| event-ready-heap正确替代 | 1 | 完整16/16，内部表示不同 |
| dropped-client-output | 0 | 真实streaming客户端输出缺失 |
| all-remote-only-shortcut | 0 | 混合等待idle仍线性，比例12.53 |
| incomplete-agent-implementation | 0 | idle仍线性，比例13.03 |
| historical-oracle-starves-stream | 0 | 无远端事件时streaming续传停滞 |
| preemption-backlog-regression | 0 | 已完成12/16后被新增FCFS检查拒绝，不是初始化失败 |

三份完整只读 `/app` 经新 `tests/test.sh` 重放：r01=1（16/16）、r02=0（12/16）、r03=1（16/16）。r02单独新增用例重放时，本地和remote路径都失败，故不是仅某一种connector夹具导致。r03的功能通过与对象保留诊断并存，**不能把新1/0/1写成三份答案的全面正确性结论**。

运行前后hash全部一致。新版本没有新增模型尝试，原三轮reward仍为1/1/1。提交/推送状态：本轮只在本地修改，未commit、push或更改PR状态。

五个既有评分攻击/提前退出控制此轮未重新执行；不沿用旧成绩声称已完成新一轮评分安全验收。当前改动不重试或替代此前被停止的安全探针。完整评分可信度、资源生命周期扣分合同、任何新模型实验和最终合入审核仍需单独确认。
