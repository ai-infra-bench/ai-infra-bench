# Task review — 2026-09-14

Historical review retained for provenance. Current lifecycle coverage, differential controls, and the upstream pytest dependency limitation are documented in [the 1.2.0 review](instruction-e2e-review-2026-09-16.md).

Verdict: the task can be retained and passes all three review gates on the final rebuilt image. Review snapshot: PR #61 base `42d586d729d0a2a27c67a1efc1944c84d2875a41` plus the uncommitted hardening diff; Base `d88f28da05b12bc7d63ebe3dcedf445ecb274343`; review skill from official `main` on 2026-09-14.

| # | Dimension | Score / status | Key evidence or gap | Next action |
| ---: | --- | --- | --- | --- |
| 1 | Is the task realistic and clear? | 2 | One-paragraph first-person report describes idle overhead and required lifecycle behavior without file or test hints. | None. |
| 2 | Is correctness independent of the source PR? | 2 | Contract requires bounded idle work and externally visible scheduler semantics, not a named queue or historical patch. | None. |
| 3 | Can the agent solve the task in the environment? | 2 | The final Dockerfile rebuild exposes the exact clean Base to the declared agent user with terminal/test tooling and no curator artifacts or future Git source. | None. |
| 4 | Are the statement and tests aligned in both directions? | 2 | Tests cover scaling, promotion, FCFS order, mixed FSM/remote/streaming reasons, accounting, abort, and regression behavior. Remote completion is delivered through the public production output boundary rather than injected into scheduler internals. | None. |
| 5 | Do tests exercise the actual behavior-determining path? | 2 | Production Scheduler transitions and `update_from_output` connector-event delivery run with a contract-valid verifier-owned connector; external KV service/model download are the documented substitutions. | None. |
| 6 | Can different correct implementations pass? | 2 | A materially different private-queue-name implementation scores 1; no internal container or callback count is required. | None. |
| 7 | Are incorrect implementations rejected for the right reasons? | 2 | Base and callback-only patch fail the intended population-scaling check after reaching the scheduler path. | None. |
| 8 | Is the Oracle independently validated? | 2 | Oracle passes mixed blocking-reason ordering and the correct-alternative challenge in addition to the original performance invariant. | None. |
| 9 | Is the grading result trustworthy? | 2 | A parent-owned scorer requires all five ordered, HMAC-chained native checkpoints. Full Harbor replay rejects `SystemExit(0)`, `os._exit(0)`, forged stdout, direct checkpoint calls, and callback theft; only the correct alternative scores 1. | None within demonstrated boundary. |
| 10 | Is acceptance reproducible and the handoff clear? | 2 | Final image identity, executable hashes, build/provenance checks, Harbor Base/Oracle/controls, limitations, and raw-result locations are recorded. | None. |

Gates 1 (statement), 2 (environment), and 3 (verification) pass. On the final authenticated-checkpoint verifier, Harbor Base/Oracle produced `0/1`; the seven-case Harbor matrix produced `1/0/0/0/0/0/0` for the correct alternative, incomplete implementation, `SystemExit(0)`, `os._exit(0)`, forged stdout, forged checkpoint, and stolen callback. Two saved 1000-turn DeepSeek candidates that implemented bounded event-driven promotion pass; their earlier failures were caused by a verifier probe that bypassed the production completion hook.
