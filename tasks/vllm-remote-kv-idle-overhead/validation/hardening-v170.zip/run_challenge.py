from pathlib import Path
import shutil,subprocess
ROOT=Path('/data/codex-pr61-v170-20260919')
for name in ('oracle','event-ready-heap-alternative'):
 target=ROOT/'challenge-tasks'/name;shutil.copytree(ROOT/'final-task',target)
 if name!='oracle':shutil.copyfile(target/'validation'/f'{name}.patch',target/'solution/oracle.patch')
 p=target/'tests/verify_blocked_waiting.py'
 extra='''
GROUPS = ('independent-pressure-variants',)
def run_suite(peer, emit):
    rng = random.Random(44560)
    for trial in range(12):
        prompts = [rng.choice([17, 32, 47, 64, 81, 96]) for _ in range(3)]
        budgets = [rng.randint(1, 7) for _ in prompts]
        blocks = max((p + b - 2) // 16 + 1 for p,b in zip(prompts,budgets)) + 1 + trial % 3
        peer.call('reset', capacity=2, budget=rng.choice([16, 32, 128]), blocks=blocks)
        ids = [f'case/{trial}-α-{i}' for i in range(3)]
        peer.call('add', items=[{'id':rid, 'prompt':prompt, 'max_tokens':budget,
                                'remote': i != trial % 4, 'cached':16}
                               for i,(rid,prompt,budget) in enumerate(zip(ids,prompts,budgets))])
        seen = {rid:[] for rid in ids}; ended=set()
        for step in range(200):
            tokens={rid:1201+index*73+len(seen[rid]) for index,rid in enumerate(ids)}
            result=peer.call('tick', auto_ready=True, tokens=tokens)
            for rid,values,terminal in result['outputs']:
                require(rid in seen and rid not in ended, f'duplicate or unknown output: {result}')
                seen[rid].extend(values)
                if terminal:ended.add(rid)
            if len(ended)==3:break
        wanted={rid:[1201+index*73+n for n in range(budgets[index])] for index,rid in enumerate(ids)}
        require(seen==wanted and ended==set(ids), f'pressure challenge failed: blocks={blocks}, prompts={prompts}, budgets={budgets}, seen={seen}')
        empty(peer)
    emit(GROUPS[0])
'''
 p.write_text(p.read_text()+extra)
 script=(ROOT/'run_final.py').read_text().replace("TASK = Path('/data/codex-pr61-v170-20260919/final-task')",f"TASK = Path('{target}')").replace("RUNS = Path('/data/codex-pr61-v170-20260919/final-runs')",f"RUNS = Path('{ROOT}/challenge-runs/{name}')").replace("'codex-pr61-v170-final-'",f"'codex-pr61-v170-challenge-{name}-'")
 runner=ROOT/f'challenge-{name}.py';runner.write_text(script)
 subprocess.run(['python3',str(runner),'oracle'],check=True)
