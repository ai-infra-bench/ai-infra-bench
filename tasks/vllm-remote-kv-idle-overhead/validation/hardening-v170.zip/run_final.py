#!/usr/bin/env python3
"""Replay original task entrypoint on isolated, offline review containers."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

HERE = Path('/root/.codex/worktrees/899f/ai-infra-bench/review-pr61-evidence')
TASK = Path('/data/codex-pr61-v170-20260919/final-task')
RUNS = Path('/data/codex-pr61-v170-20260919/final-runs')
DOCKER = ['docker', '-H', 'unix:///data/docker-bench/docker.sock']


def command(args, **kwargs):
    return subprocess.run(args, check=True, text=True, **kwargs)


def run_case(name, image):
    folder = RUNS / name
    folder.mkdir(parents=True, exist_ok=False)
    logs = folder / 'verifier'
    logs.mkdir()
    patch = None
    if name == 'oracle':
        patch = TASK / 'solution/oracle.patch'
    elif name != 'base':
        patch = TASK / 'validation' / f'{name}.patch'
    container = 'codex-pr61-v170-final-' + name
    args = DOCKER + ['run', '-d', '--name', container, '--network', 'none',
                     '--cpus', '4', '--memory', '16g', '--user', '0:0',
                     '-v', f'{TASK / "tests"}:/tests:ro',
                     '-v', f'{logs}:/logs/verifier',
                     '--entrypoint', '/bin/bash']
    if patch:
        args += ['-v', f'{patch}:/control.patch:ro']
    args += [image, '-c', 'sleep infinity']
    started = time.monotonic()
    result = {'name': name, 'image': image,
              'patch_sha256': hashlib.sha256(patch.read_bytes()).hexdigest() if patch else None,
              'entrypoint': '/tests/test.sh', 'cpus': 4, 'memory': '16g', 'network': 'none'}
    command(args, stdout=subprocess.PIPE)
    try:
        if patch:
            command(DOCKER + ['exec', '--user', 'agent', '-w', '/app', container,
                              'git', 'apply', '/control.patch'], stdout=subprocess.PIPE)
        with (folder / 'stdout.log').open('w') as log:
            done = subprocess.run(DOCKER + ['exec', '--user', '0:0', container,
                                           'bash', '/tests/test.sh'], stdout=log,
                                  stderr=subprocess.STDOUT, timeout=960)
        result['entrypoint_exit'] = done.returncode
        result['elapsed_seconds'] = round(time.monotonic() - started, 3)
        if (logs / 'verifier-details.json').is_file():
            result['verdict'] = json.loads((logs / 'verifier-details.json').read_text())
        else:
            result['verdict'] = None
        (folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
    finally:
        command(DOCKER + ['rm', '-f', container], stdout=subprocess.PIPE)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', default='codex-pr61-review:base-20260919')
    parser.add_argument('cases', nargs='+')
    args = parser.parse_args()
    for case in args.cases:
        run_case(case, args.image)
