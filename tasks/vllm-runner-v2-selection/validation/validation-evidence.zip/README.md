# Validation evidence

See records/pooling-evidence.json and records/review-report.md for task 1.1.2 results. Older evidence is under records/history. Raw logs, launchers and checksums are under runs. manifest.json records source and member hashes. Archived documents are historical snapshots, so their original relative links may refer to the pre-archive layout.
