from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,time
root=Path(__file__).parent
task=Path('/tmp/ai-infra-pr56-hardening/tasks/vllm-runner-v2-selection')
cases=[('base',None,0),('alternative','validation/alternative-agent-implementation.patch',1),('forged-checkpoints','validation/forged-checkpoints.patch',0),('missing-prompt-embeds','validation/missing-prompt-embeds-check.patch',0)]
(root/'control-input-hashes.json').write_text(json.dumps({str(p.relative_to(task)):hashlib.sha256(p.read_bytes()).hexdigest() for p in task.rglob('*') if p.is_file() and (p.suffix=='.patch' or 'tests' in p.parts)},indent=2)+'\n')
def run(case):
 label,patch,expected=case; name='pr56-tools-'+label;out=root/'controls'/label;out.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 subprocess.run(['docker','run','-d','--name',name,'--network','none','--gpus','device=4','--cpus','4','--memory','16g','--user','root','--entrypoint','sleep','-v',str(task/'tests')+':/tests:ro','-v',str(task/'validation')+':/validation:ro','pr56-hardening:offline-final','infinity'],check=True,stdout=subprocess.DEVNULL)
 try:
  if patch:subprocess.run(['docker','exec','-u','agent',name,'git','apply','/'+patch],check=True)
  with (out/'verifier.log').open('w') as f:result=subprocess.run(['docker','exec',name,'bash','/tests/test.sh'],stdout=f,stderr=subprocess.STDOUT,timeout=590)
  reward=subprocess.check_output(['docker','exec',name,'cat','/logs/verifier/reward.txt'],text=True).strip()
  subprocess.run(['docker','cp',name+':/logs/verifier/worker.log',str(out/'worker.log')],check=True)
  item=dict(case=label,expected=expected,reward=reward,exit_code=result.returncode,seconds=round(time.monotonic()-start,2));(out/'result.json').write_text(json.dumps(item,indent=2)+'\n');print(item,flush=True);return item
 finally:subprocess.run(['docker','stop','-t','2',name],capture_output=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(run,cases))
(root/'controls.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(x['reward']==str(x['expected']) and x['exit_code']==0 for x in results)
