import tempfile
from pathlib import Path
import yaml
from harbor.environments.docker.docker import DockerEnvironment

class NvidiaDockerEnvironment(DockerEnvironment):
    def __init__(self,*args,gpu_device='3',**kwargs):
        self._overlay=tempfile.TemporaryDirectory(prefix='pr56-tools-gpu-')
        original=Path(kwargs['environment_dir'])/'docker-compose.yaml'
        doc=yaml.safe_load(original.read_text()) if original.exists() else {'services':{'main':{}}}
        main=doc['services']['main'];main['shm_size']='2gb'
        main.setdefault('deploy',{}).setdefault('resources',{}).setdefault('reservations',{})['devices']=[{'driver':'nvidia','device_ids':[gpu_device],'capabilities':['gpu']}]
        self._gpu_task_compose=Path(self._overlay.name)/'task-gpu.yaml'
        self._gpu_task_compose.write_text(yaml.safe_dump(doc))
        super().__init__(*args,**kwargs)
    @property
    def _environment_docker_compose_path(self):return self._gpu_task_compose
    @property
    def capabilities(self):return super().capabilities.model_copy(update={'gpus':True})
