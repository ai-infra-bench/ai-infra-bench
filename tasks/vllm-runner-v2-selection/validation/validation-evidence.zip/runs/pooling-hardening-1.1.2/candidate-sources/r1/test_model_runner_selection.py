# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from copy import deepcopy
from types import SimpleNamespace

import pytest

import vllm.envs as envs
from vllm.config import VllmConfig
from vllm.platforms import current_platform


@pytest.fixture
def config(monkeypatch):
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    monkeypatch.setattr(current_platform, "is_cuda_alike", lambda: True)
    monkeypatch.setattr("vllm.utils.platform_utils.is_uva_available", lambda: True)
    # Exercise selection without downloading weights or initializing a GPU.
    config = object.__new__(VllmConfig)
    config.model_config = SimpleNamespace(
        architecture="Qwen3ForCausalLM",
        runner_type="generate",
        is_moe=False,
        is_multimodal_model=False,
        quantization=None,
        has_inner_state=False,
        enable_prompt_embeds=False,
        logprobs_mode="raw_logprobs",
        enable_return_routed_experts=False,
        logits_processors=None,
    )
    config.quant_config = None
    config.parallel_config = SimpleNamespace(
        prefill_context_parallel_size=1,
        pipeline_parallel_size=1,
        enable_dbo=False,
    )
    config.compilation_config = SimpleNamespace(
        pass_config=SimpleNamespace(enable_sp=False),
    )
    config.cache_config = SimpleNamespace(kv_sharing_fast_prefill=False)
    config.speculative_config = None
    config.ec_transfer_config = None
    return config


@pytest.mark.parametrize(
    "override, expected", [(None, None), ("0", False), ("1", True)]
)
def test_runner_environment(monkeypatch, override, expected):
    monkeypatch.delenv("VLLM_USE_V2_MODEL_RUNNER", raising=False)
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    assert envs.VLLM_USE_V2_MODEL_RUNNER is expected


@pytest.mark.parametrize(
    "override, expected", [(None, True), ("0", False), ("1", True)]
)
def test_qwen3_selection(config, monkeypatch, override, expected):
    if override is not None:
        monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", override)
    config._select_model_runner()
    assert config.use_v2_model_runner is expected


@pytest.mark.parametrize(
    "field, value",
    [
        ("architecture", "LlamaForCausalLM"),
        ("architecture", "Qwen3MoeForCausalLM"),
        ("architecture", "Qwen3_5ForConditionalGeneration"),
        ("runner_type", "pooling"),
        ("is_moe", True),
        ("is_multimodal_model", True),
        ("quantization", "fp8"),
    ],
)
def test_outside_automatic_rollout(config, monkeypatch, field, value):
    setattr(config.model_config, field, value)
    config._select_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    config._select_model_runner()
    assert config.use_v2_model_runner


@pytest.mark.parametrize(
    "path, value, error",
    [
        ("model_config.has_inner_state", True, "hybrid/mamba"),
        ("model_config.enable_prompt_embeds", True, "prompt embeddings"),
        ("model_config.logprobs_mode", "raw_logits", "logprobs mode"),
        ("model_config.logprobs_mode", "processed_logits", "logprobs mode"),
        ("model_config.logits_processors", ["custom"], "custom logits processors"),
        ("model_config.enable_return_routed_experts", True, "routed experts"),
        ("parallel_config.prefill_context_parallel_size", 2, "prefill context"),
        ("parallel_config.enable_dbo", True, "dual batch overlap"),
        ("compilation_config.pass_config.enable_sp", True, "sequence parallelism"),
        ("cache_config.kv_sharing_fast_prefill", True, "KV sharing"),
        ("ec_transfer_config", object(), "EC transfer"),
        ("speculative_config", SimpleNamespace(method="ngram"), "speculative method"),
    ],
)
def test_unsupported_falls_back_or_raises(config, monkeypatch, path, value, error):
    target = config
    *parents, field = path.split(".")
    for parent in parents:
        target = getattr(target, parent)
    setattr(target, field, value)
    config._select_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match=f"VLLM_USE_V2_MODEL_RUNNER=1.*{error}"):
        config._select_model_runner()
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0")
    config._select_model_runner()
    assert not config.use_v2_model_runner


@pytest.mark.parametrize("method", ["eagle", "eagle3", "mtp"])
def test_supported_speculation(config, method):
    config.speculative_config = SimpleNamespace(method=method)
    config._select_model_runner()
    assert config.use_v2_model_runner


def test_eagle3_pipeline_parallel(config, monkeypatch):
    config.speculative_config = SimpleNamespace(method="eagle3")
    config.parallel_config.pipeline_parallel_size = 2
    config._select_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="EAGLE3 with pipeline parallelism"):
        config._select_model_runner()


def test_unsupported_platform(config, monkeypatch):
    monkeypatch.setattr(current_platform, "is_cuda_alike", lambda: False)
    config._select_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="platforms"):
        config._select_model_runner()


def test_no_model(config):
    config.model_config = None
    config._select_model_runner()
    assert not config.use_v2_model_runner


def test_quant_config_excluded_from_rollout(config):
    config.quant_config = object()
    config._select_model_runner()
    assert not config.use_v2_model_runner


def test_selection_persists_in_copied_config(config, monkeypatch):
    config._select_model_runner()
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0")
    worker_config = deepcopy(config)
    assert worker_config.use_v2_model_runner


@pytest.mark.parametrize("selected", [False, True])
def test_worker_uses_resolved_runner(config, monkeypatch, selected):
    from vllm.distributed.elastic_ep import elastic_execute
    from vllm.v1.worker.gpu_worker import Worker
    from vllm.v1.worker.worker_base import WorkerBase

    config.use_v2_model_runner = selected
    config.weight_transfer_config = None
    config.profiler_config = SimpleNamespace(profiler=None)
    # A worker's environment must not override the serialized engine choice.
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "0" if selected else "1")

    def init_base(self, vllm_config, **kwargs):
        self.vllm_config = vllm_config

    monkeypatch.setattr(WorkerBase, "__init__", init_base)
    monkeypatch.setattr(
        elastic_execute, "ElasticEPScalingExecutor", lambda worker: None
    )
    worker = Worker(config, local_rank=0, rank=0, distributed_init_method="")
    assert worker.use_v2_model_runner is selected


def test_uva_required(config, monkeypatch):
    monkeypatch.setattr("vllm.utils.platform_utils.is_uva_available", lambda: False)
    config._select_model_runner()
    assert not config.use_v2_model_runner
    monkeypatch.setenv("VLLM_USE_V2_MODEL_RUNNER", "1")
    with pytest.raises(ValueError, match="unified virtual addressing"):
        config._select_model_runner()
