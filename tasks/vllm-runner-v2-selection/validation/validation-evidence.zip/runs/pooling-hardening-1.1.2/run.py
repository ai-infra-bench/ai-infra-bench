from pathlib import Path
import subprocess,json,time,concurrent.futures,hashlib
r=Path(__file__).parent;t=r/'task';a=Path('/tmp/pr56-codex-medium-a688bee-3/final-artifacts')
ci=json.loads((t/'validation/ci-cases.json').read_text())['cases']
cases=[('oracle','solution/oracle.patch',1),('base',None,0)]+[(c['name'],'validation/'+c['patch'],c['expected_reward']) for c in ci]+[(f'r{n}',f'r{n}',int(n==2)) for n in (1,2,3)]
def lane(args):
 gpu,items=args;return [run(c,gpu) for c in items]
def run(c,gpu):
 label,patch,expected=c;name='pr56-pool-final-'+label;o=r/'runs'/label;o.mkdir(parents=True,exist_ok=True);start=time.monotonic()
 subprocess.run(['docker','run','-d','--name',name,'--network','none','--gpus',f'device={gpu}','--cpus','4','--memory','16g','--shm-size','2g','--user','root','--entrypoint','sleep','-v',str(t)+':/task:ro','-v',str(t/'tests')+':/tests:ro','-v',str(a)+':/answers:ro','pr56-hardening:offline-final','infinity'],check=True,stdout=subprocess.DEVNULL)
 try:
  if label in ('r1','r2','r3'):
   path='/answers/pr56-codex-a688bee-'+label
   subprocess.run(['docker','exec','-u','agent','-w','/workspace/repo',name,'bash','-c',f'git apply {path}/tracked.patch && tar --no-same-owner -xzf {path}/untracked.tar.gz'],check=True)
  elif patch:subprocess.run(['docker','exec','-u','agent','-w','/workspace/repo',name,'git','apply','/task/'+patch],check=True)
  with (o/'verifier.log').open('w') as f:p=subprocess.run(['docker','exec',name,'bash','/tests/test.sh'],stdout=f,stderr=subprocess.STDOUT,timeout=590)
  score=subprocess.check_output(['docker','exec',name,'cat','/logs/verifier/reward.txt'],text=True).strip();subprocess.run(['docker','cp',name+':/logs/verifier/worker.log',str(o/'worker.log')],check=True,capture_output=True)
  x=dict(case=label,expected=expected,reward=int(score),exit_code=p.returncode,seconds=round(time.monotonic()-start,2));(o/'result.json').write_text(json.dumps(x,indent=2));print(json.dumps(x),flush=True);return x
 finally:subprocess.run(['docker','stop','-t','2',name],capture_output=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:results=sum(p.map(lane,[(i,cases[i::6]) for i in range(6)]),[])
(r/'results.json').write_text(json.dumps(results,indent=2));assert all(x['reward']==x['expected'] and x['exit_code']==0 for x in results)
inputs=json.loads((r/'input-hashes.json').read_text());assert all(hashlib.sha256((t/f).read_bytes()).hexdigest()==h for f,h in inputs.items())
