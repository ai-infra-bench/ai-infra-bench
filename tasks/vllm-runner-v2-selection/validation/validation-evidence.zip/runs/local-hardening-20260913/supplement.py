from pathlib import Path
import json,os,shutil,subprocess,time
root=Path('/tmp/pr56-hardening-20260913');task=Path('/tmp/ai-infra-pr56-hardening/tasks/vllm-runner-v2-selection')
tests=root/'nonroot-tests';shutil.copytree(task/'tests',tests,dirs_exist_ok=True)
for name in ('qwen3','qwen2','qwen3-fp8','qwen3-moe'):
 p=tests/'fixtures'/name/'config.json';c=json.loads(p.read_text());c.update(vocab_size=192,max_position_embeddings=2048,num_hidden_layers=3);p.write_text(json.dumps(c,indent=2)+'\n')
p=tests/'supervise_runner_consumers.py'
s=p.read_text().replace('    # Repeat an automatic startup', '    case("challenge_forced_v1_quantized", "V1", "0", model="qwen3-fp8"),\n    case("challenge_forced_v1_pooling", "V1", "0", model_options={"runner": "pooling"}),\n    # Repeat an automatic startup')
p.write_text(s)
for p in [tests,*tests.rglob('*')]: os.chown(p,1000,1000)
name='pr56-harden-nonroot-venv';start=time.monotonic()
subprocess.run(['docker','run','-d','--name',name,'--network','none','--gpus','device=4','--cpus','4','--memory','16g','--user','root','--entrypoint','sleep','-v',str(tests)+':/tests:ro','-v',str(task/'solution')+':/solution:ro','pr56-hardening:base','infinity'],check=True)
try:
 subprocess.run(['docker','exec','-u','agent','-w','/workspace/repo',name,'git','apply','/solution/oracle.patch'],check=True)
 subprocess.run(['docker','exec',name,'python3','-m','venv','--system-site-packages','--without-pip','/opt/venv'],check=True)
 with (root/'nonroot-venv.log').open('w') as f:
  subprocess.run(['docker','exec',name,'/opt/venv/bin/python','-I','-c','import sys; assert sys.prefix == "/opt/venv"; print(sys.executable, sys.prefix)'],stdout=f,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['docker','exec',name,'bash','/tests/test.sh'],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=550)
 r=subprocess.check_output(['docker','exec',name,'cat','/logs/verifier/reward.txt'],text=True).strip()
 (root/'nonroot-venv-result.json').write_text(json.dumps({'reward':r,'seconds':round(time.monotonic()-start,2),'test_mount_uid':1000,'venv':'/opt/venv','independent_input_changes':['vocab_size=192','max_position_embeddings=2048','num_hidden_layers=3']},indent=2))
 assert r=='1',r
finally: subprocess.run(['docker','stop','-t','2',name],capture_output=True)
