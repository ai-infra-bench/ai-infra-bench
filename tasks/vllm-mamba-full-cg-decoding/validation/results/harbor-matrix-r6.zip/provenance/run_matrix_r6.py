import concurrent.futures, hashlib, json, os, shutil, subprocess, time
from pathlib import Path
ROOT=Path('/data/pr64-review-20260919')
TASK=Path('/tmp/ai-infra-pr64-review-20260919/tasks/vllm-mamba-full-cg-decoding')
HARBOR='/data/ai-infra-ci/venv/bin/harbor'
GPUS=['GPU-3815a178-ad22-4b81-5669-0533760a7e6b','GPU-8380fa1c-d192-a7e4-ec39-ab836d0f4fd8','GPU-a6a45da0-8978-3ea7-4fa0-1786ea9f3329','GPU-46c9b5d9-82f9-7bca-374e-6441ff3361c6']
CASES=json.loads((TASK/'validation/ci-cases.json').read_text())['cases']
CASES=[{'name':'base','expected_reward':0},{'name':'oracle','expected_reward':1},*CASES,{'name':'oracle-repeat','expected_reward':1}]

def run(case,gpu):
 name=case['name'];dest=ROOT/'matrix-r6-tasks'/name
 if dest.exists():raise RuntimeError('snapshot exists: '+str(dest))
 shutil.copytree(TASK,dest,ignore=shutil.ignore_patterns('__pycache__'))
 agent='nop' if name=='base' else 'oracle'
 if name not in ('base','oracle','oracle-repeat'):
  shutil.rmtree(dest/'solution');(dest/'solution').mkdir()
  shutil.copy2(TASK/'validation'/case['patch'],dest/'solution/ci-case.patch')
  (dest/'solution/solve.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\ncd /workspace/repo\ngit apply --check /solution/ci-case.patch\ngit apply /solution/ci-case.patch\n')
 env={**os.environ,'DOCKER_CONFIG':str(ROOT/'docker-config'),'PYTHONPATH':str(ROOT),'PR64_GPU_UUID':gpu}
 command=[HARBOR,'run','-p',str(dest),'-a',agent,'-e','local_harbor:LocalGpuDocker','-o',str(ROOT/'matrix-r6-jobs'),'--job-name',name,'--yes']
 start=time.monotonic()
 with (ROOT/f'matrix-r6-{name}.log').open('w') as f:
  r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=1500)
 result=ROOT/'matrix-r6-jobs'/name/'result.json'
 info=json.loads(result.read_text());stats=info['stats']
 trials=list((ROOT/'matrix-r6-jobs'/name).glob('*/verifier/reward.txt'))
 rewards=[int(p.read_text()) for p in trials]
 record={'case':name,'expected_reward':case['expected_reward'],'rewards':rewards,'errors':stats['n_errored_trials'],'completed':stats['n_completed_trials'],'seconds':round(time.monotonic()-start,2),'process_exit':r.returncode,'job_result':str(result),'gpu':gpu}
 record['passed']=stats['n_errored_trials']==0 and stats['n_completed_trials']==1 and rewards==[case['expected_reward']]
 (ROOT/'matrix-r6-jobs'/name/'control-summary.json').write_text(json.dumps(record,indent=2))
 print(json.dumps(record),flush=True)
 return record

def lane(index):
 results=[]
 for case in CASES[index::len(GPUS)]:
  results.append(run(case,GPUS[index]))
 return results

if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=len(GPUS)) as pool:
  futures=[pool.submit(lane,i) for i in range(len(GPUS))]
  results=[r for future in concurrent.futures.as_completed(futures) for r in future.result()]
 (ROOT/'matrix-r6-results.json').write_text(json.dumps(results,indent=2))
 if not all(r['passed'] for r in results):raise SystemExit(1)
