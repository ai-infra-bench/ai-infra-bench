from pathlib import Path
import json,importlib.util
ROOT=Path('/logs/verifier/four-family-probes')
challenges=json.loads(Path('/opt/pr64-final-challenges.json').read_text())
s=Path('/opt/pr64-four-family-run.py').read_text().split('results=[]\nfor name,cfg in suites.items():')[0]
ns={};exec(s,ns)
factory=ns['factory'];run_one=ns['run_one'];coverage=ns['coverage']
results=[]
for name,c in challenges.items():
 model=ROOT/'models'/('final-'+name)
 if not model.exists():factory.make_model('hybrid',model,c['seeds']['hybrid'])
 req=c['request'];cfg={**req,'model':str(model),'spec':req['speculative']}
 a=run_one('final-calibration-'+name,cfg)
 results.append({'case':name,'exit_code':a['exit_code'],'coverage':coverage(a)})
 (ROOT/'final-coverage.json').write_text(json.dumps(results,indent=2)+'\n')
 print('COVERAGE',name,{k:len(v) if isinstance(v,list) else v for k,v in results[-1]['coverage'].items()},flush=True)
