from __future__ import annotations
import json,os,sys
from pathlib import Path
os.environ.update(VLLM_ENABLE_V1_MULTIPROCESSING='0',VLLM_HOST_IP='127.0.0.1',GLOO_SOCKET_IFNAME='lo')
cfg=json.loads(Path(sys.argv[1]).read_text())
sys.path.insert(0,sys.argv[3])
import torch
from vllm import LLM,SamplingParams
from vllm.v1.core.sched.scheduler import Scheduler
from vllm.v1.worker.gpu_model_runner import GPUModelRunner
trace=[]; dispatch=[]; observing=False; phase='init'; current=None
original_schedule=Scheduler.schedule
original_update=Scheduler.update_from_output
original_dispatch=GPUModelRunner._determine_batch_execution_and_padding

def schedule(self,*args,**kwargs):
 global current
 before={rid:{'computed':r.num_computed_tokens,'prompt_length':r.num_prompt_tokens,'outputs':r.num_output_tokens} for rid,r in self.requests.items()}
 out=original_schedule(self,*args,**kwargs)
 if observing:
  current={'step':len(trace),'phase':phase,'scheduled':dict(out.num_scheduled_tokens),'drafts':{r:list(v) for r,v in out.scheduled_spec_decode_tokens.items()},'before':{r:before.get(r) for r in out.num_scheduled_tokens},'new':{r.req_id:r.num_computed_tokens for r in out.scheduled_new_reqs},'generated':{}}
  trace.append(current)
 return out

def update(self,*args,**kwargs):
 out=original_update(self,*args,**kwargs)
 if observing and current is not None:
  current['generated']={r.request_id:list(r.new_token_ids) for values in out.values() for r in values.outputs}
 return out

def choose(self,*args,**kwargs):
 out=original_dispatch(self,*args,**kwargs)
 if observing:
  nr=kwargs.get('num_reqs',args[1] if len(args)>1 else None)
  desc=out[1]
  npad=desc.num_reqs if desc.num_reqs is not None else nr
  dispatch.append({'phase':phase,'step':len(trace)-1,'mode':str(out[0]),'live_rows':nr,'padded_rows':npad,'padded_tokens':desc.num_tokens,'computed':self.input_batch.num_computed_tokens_cpu_tensor[:npad].tolist(),'prompt_lengths':self.input_batch.num_prompt_tokens_cpu_tensor[:npad].tolist(),'req_ids':list(self.input_batch.req_ids)})
 return out
Scheduler.schedule=schedule;Scheduler.update_from_output=update
GPUModelRunner._determine_batch_execution_and_padding=choose
spec=cfg.get('spec',False)
args=dict(model=cfg['model'],skip_tokenizer_init=True,dtype='float32',max_model_len=cfg.get('max_model_len',128),max_num_seqs=cfg.get('max_num_seqs',2),max_num_batched_tokens=cfg.get('token_budget',16),kv_cache_memory_bytes=32*1024*1024,enable_chunked_prefill=True,async_scheduling=False,enable_prefix_caching=cfg.get('cache','none')=='all',mamba_cache_mode=cfg.get('cache','none'),enforce_eager=cfg.get('eager',False),speculative_config={'method':'ngram','prompt_lookup_max':3,'prompt_lookup_min':cfg.get('lookup_min',2),'num_speculative_tokens':2} if spec else None,compilation_config={'mode':0,'cudagraph_mode':'FULL','cudagraph_capture_sizes':cfg.get('captures',[3,6] if spec else [1,2])},max_logprobs=64,disable_log_stats=False)
if cfg.get('num_gpu_blocks') is not None:args['num_gpu_blocks_override']=cfg['num_gpu_blocks']
if cfg.get('mamba_block_size'):args['mamba_block_size']=cfg['mamba_block_size']
llm=LLM(**args)
observing=True
prof=torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]);prof.start()

def serialize(r):
 return {'request_id':r.request_id,'prompt':r.prompt_token_ids,'tokens':list(r.outputs[0].token_ids),'logprobs':[[v[t].logprob for t in range(64)] for v in r.outputs[0].logprobs],'cached_tokens':getattr(r,'num_cached_tokens',None),'finished':r.finished}

def sampling(steps):return SamplingParams(temperature=0,max_tokens=steps,ignore_eos=True,logprobs=64)

batches=[]
if cfg.get('lifecycle'):
 phase='decode_warmup';active={}
 prompts=[[3,7,5,11,8,4,9,12],[13,14,6,8,7,9,4,10,5],[19,6,7,8,4,3,17,11,12,8]]
 ids=llm.enqueue([{'prompt_token_ids':p} for p in prompts],sampling(40),use_tqdm=False)
 def advance(n):
  for _ in range(n):
   for out in llm.llm_engine.step():active[out.request_id]=serialize(out)
 advance(8)
 phase='long_prefill'
 long_id=llm.enqueue([{'prompt_token_ids':[23,24,25,26]*20}],sampling(16),use_tqdm=False)[0]
 advance(1)
 llm.llm_engine.abort_request([long_id],internal=True)
 phase='after_prefill_abort';advance(3)
 llm.llm_engine.abort_request([ids[0]],internal=True)
 phase='after_decode_abort'
 for _ in range(64):
  advance(1)
  if not llm.llm_engine.has_unfinished_requests():break
 batches=[[next(row for row in active.values() if row['prompt']==p) for p in prompts[1:]]]
 assert all(row['finished'] and len(row['tokens'])==40 for row in batches[0])
else:
 for i,batch in enumerate(cfg['batches']):
  phase=f'batch-{i}'
  out=llm.generate([{'prompt_token_ids':p} for p in batch],sampling(cfg.get('steps',16)),use_tqdm=False)
  batches.append([serialize(r) for r in out])
prof.stop()
launches=sum(e.count for e in prof.key_averages() if 'cudaGraphLaunch' in e.key or 'cuGraphLaunch' in e.key)
metrics=[]
for m in llm.get_metrics():
 if any(word in m.name for word in ['spec_decode','prefix_cache','generation_tokens']):metrics.append({'name':m.name,'value':getattr(m,'value',None)})
result={'batches':batches,'trace':trace,'dispatch':dispatch,'graph_launches':launches,'metrics':metrics}
Path(sys.argv[2]).write_text(json.dumps(result,allow_nan=False))
